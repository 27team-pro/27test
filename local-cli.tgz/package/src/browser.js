// The agent's browser: Chrome / Edge / Chromium driven over the DevTools protocol through a pipe (no WebSocket,
// no dependencies). The agent opens the app, clicks, types, reads console errors and takes screenshots; design
// mode puts an overlay on the page so the user clicks an element, writes what to change and the agent edits the
// code. The profile in ~/.klinch/browser keeps logins: the user signs in once in the visible window and the agent
// never sees the password.
import { spawn } from 'node:child_process';
import { existsSync, mkdirSync, readdirSync, writeFileSync, mkdtempSync } from 'node:fs';
import { homedir, tmpdir } from 'node:os';
import { join, delimiter, dirname } from 'node:path';

const imageBlock = (buf, mediaType) => ({ type: 'image', source: { type: 'base64', media_type: mediaType, data: buf.toString('base64') } });

const VIEW = { width: 1280, height: 800 };
const LOG_MAX = 300;

/** Chrome, Edge, Brave or Chromium on this computer (also Playwright's download); KLINCH_BROWSER wins. */
export function findBrowser(env = process.env) {
  if (env.KLINCH_BROWSER) return env.KLINCH_BROWSER;
  const home = homedir(), list = [];
  if (process.platform === 'darwin') {
    for (const base of ['/Applications', join(home, 'Applications')]) {
      list.push(`${base}/Google Chrome.app/Contents/MacOS/Google Chrome`, `${base}/Chromium.app/Contents/MacOS/Chromium`,
        `${base}/Microsoft Edge.app/Contents/MacOS/Microsoft Edge`, `${base}/Brave Browser.app/Contents/MacOS/Brave Browser`);
    }
  } else if (process.platform === 'win32') {
    for (const base of [env.LOCALAPPDATA, env.PROGRAMFILES, env['PROGRAMFILES(X86)']].filter(Boolean)) {
      list.push(join(base, 'Google/Chrome/Application/chrome.exe'), join(base, 'Microsoft/Edge/Application/msedge.exe'),
        join(base, 'BraveSoftware/Brave-Browser/Application/brave.exe'), join(base, 'Chromium/Application/chrome.exe'));
    }
  } else {
    for (const dir of String(env.PATH || '').split(delimiter).filter(Boolean)) {
      for (const n of ['google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser', 'microsoft-edge', 'microsoft-edge-stable', 'brave-browser']) list.push(join(dir, n));
    }
  }
  const pw = [env.PLAYWRIGHT_BROWSERS_PATH, join(home, '.cache/ms-playwright'), join(home, 'Library/Caches/ms-playwright'), env.LOCALAPPDATA && join(env.LOCALAPPDATA, 'ms-playwright')].filter(Boolean);
  for (const root of pw) {
    let dirs = []; try { dirs = readdirSync(root).filter((d) => /^chromium-\d+$/.test(d)).sort().reverse(); } catch { continue; }
    for (const d of dirs) {
      for (const rel of ['chrome-linux64/chrome', 'chrome-linux/chrome', 'chrome-mac-arm64/Chromium.app/Contents/MacOS/Chromium',
        'chrome-mac/Chromium.app/Contents/MacOS/Chromium', 'chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',
        'chrome-mac-x64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing', 'chrome-win64/chrome.exe', 'chrome-win/chrome.exe']) list.push(join(root, d, rel));
    }
  }
  return list.find((p) => existsSync(p)) || null;
}

/** localhost, LAN, file: and about: pages: actions there need no confirmation. */
export function isLocalUrl(u) {
  let url; try { url = new URL(u); } catch { return true; }
  if (['file:', 'about:', 'data:', 'blob:', 'chrome-error:'].includes(url.protocol)) return true;
  const h = url.hostname.replace(/^\[|\]$/g, '');
  return h === 'localhost' || h.endsWith('.localhost') || h === '::1' || h === '0.0.0.0' || /^127\./.test(h) || /^10\./.test(h) || /^192\.168\./.test(h) || /^172\.(1[6-9]|2\d|3[01])\./.test(h);
}

/** «localhost:3000» → http://localhost:3000, «example.com» → https://example.com. */
export function normalizeUrl(u) {
  const s = String(u || '').trim();
  if (!s) return 'about:blank';
  if (/^[a-z][a-z0-9+.-]*:/i.test(s) && !/^(localhost|[\w.-]+):\d+/i.test(s)) return s;
  if (/^(localhost|127\.|0\.0\.0\.0|\[::1\]|[\w-]+\.localhost)/i.test(s)) return 'http://' + s;
  if (/^[\w.-]+:\d+/.test(s)) return 'http://' + s;
  return 'https://' + s;
}

// ── DevTools protocol over the pipe: JSON messages separated by \0 ─────────────────────────────────────────────
function createCdp(write) {
  let seq = 0, buf = '';
  const pending = new Map(), listeners = new Set();
  return {
    send(method, params = {}, sessionId, timeout = 30000) {
      const id = ++seq;
      return new Promise((res, rej) => {
        const t = setTimeout(() => { pending.delete(id); rej(new Error(`Браузер не ответил на ${method}`)); }, timeout);
        pending.set(id, { res, rej, t, method });
        write(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }) + '\0');
      });
    },
    on(fn) { listeners.add(fn); return () => listeners.delete(fn); },
    feed(chunk) {
      buf += chunk;
      let i;
      while ((i = buf.indexOf('\0')) >= 0) {
        const raw = buf.slice(0, i); buf = buf.slice(i + 1);
        let m; try { m = JSON.parse(raw); } catch { continue; }
        if (m.id && pending.has(m.id)) {
          const p = pending.get(m.id); pending.delete(m.id); clearTimeout(p.t);
          if (m.error) p.rej(new Error(`${p.method}: ${m.error.message}`)); else p.res(m.result || {});
        } else if (m.method) for (const fn of listeners) { try { fn(m); } catch { /* listener bug must not kill the pipe */ } }
      }
    },
    fail(err) { for (const p of pending.values()) { clearTimeout(p.t); p.rej(err); } pending.clear(); },
  };
}

// ── Page-side helpers (stringified into Runtime.evaluate) ──────────────────────────────────────────────────────
function pageSnapshot(maxText) {
  const vis = (el) => { const r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; const s = getComputedStyle(el); return s.visibility !== 'hidden' && s.display !== 'none' && +s.opacity > 0.05; };
  document.querySelectorAll('[data-kref]').forEach((e) => e.removeAttribute('data-kref'));
  const sel = 'a[href],button,input:not([type=hidden]),textarea,select,summary,[role=button],[role=link],[role=checkbox],[role=radio],[role=tab],[role=menuitem],[role=option],[role=switch],[role=combobox],[role=textbox],[contenteditable=""],[contenteditable=true],[onclick],[tabindex]:not([tabindex="-1"])';
  const els = []; let n = 0;
  const clean = (s, k = 80) => String(s || '').trim().replace(/\s+/g, ' ').slice(0, k);
  for (const el of document.querySelectorAll(sel)) {
    if (n >= 300) { els.push('… (ещё элементы не показаны)'); break; }
    if (!vis(el)) continue;
    const ref = ++n; el.setAttribute('data-kref', ref);
    const tag = el.tagName.toLowerCase(), type = (el.getAttribute('type') || '').toLowerCase();
    let d = tag + (tag === 'input' && type ? `[${type}]` : '');
    const role = el.getAttribute('role'); if (role) d += ` role=${role}`;
    const name = clean(el.getAttribute('aria-label') || (tag === 'input' || tag === 'textarea' || tag === 'select' ? '' : el.innerText) || el.getAttribute('title') || el.getAttribute('alt') || (tag === 'input' && ['submit', 'button'].includes(type) ? el.value : ''));
    if (name) d += ` "${name}"`;
    if (el.placeholder) d += ` placeholder="${clean(el.placeholder, 60)}"`;
    if ((tag === 'input' && !['checkbox', 'radio', 'submit', 'button', 'file'].includes(type)) || tag === 'textarea' || tag === 'select') {
      if (type === 'password') d += el.value ? ' (заполнено)' : ' (пусто)';
      else if (el.value) d += ` value="${clean(el.value, 60)}"`;
    }
    if (el.checked || el.getAttribute('aria-checked') === 'true') d += ' ✓';
    if (el.disabled || el.getAttribute('aria-disabled') === 'true') d += ' (недоступен)';
    if (tag === 'a') d += ` → ${clean(el.getAttribute('href'), 80)}`;
    const r = el.getBoundingClientRect(); if (r.bottom < 0 || r.top > innerHeight) d += ' (за экраном)';
    els.push(`[${ref}] ${d}`);
  }
  const text = (document.body ? document.body.innerText : '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  return { title: document.title, url: location.href, text: text.length > maxText ? text.slice(0, maxText) + `\n… (ещё ${text.length - maxText} символов)` : text,
    els, scroll: `${Math.round(scrollY)} из ${Math.max(0, Math.round(document.documentElement.scrollHeight - innerHeight))}` };
}

function pageFind(spec) {
  const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 1 && r.height > 1 && getComputedStyle(e).visibility !== 'hidden'; };
  let el = null;
  if (spec.ref) el = document.querySelector(`[data-kref="${spec.ref}"]`);
  else if (spec.selector) el = document.querySelector(spec.selector);
  else if (spec.text) {
    const t = String(spec.text).toLowerCase().trim();
    const label = (e) => String(e.getAttribute('aria-label') || e.innerText || e.value || e.placeholder || e.getAttribute('title') || '').trim().replace(/\s+/g, ' ').toLowerCase();
    const cands = [...document.querySelectorAll('a,button,input,textarea,select,summary,label,[role],[onclick],[tabindex]')].filter(vis);
    el = cands.find((e) => label(e) === t) || cands.filter((e) => label(e).includes(t)).sort((a, b) => label(a).length - label(b).length)[0] || null;
    if (!el) {
      const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      for (let nd; (nd = w.nextNode());) if (nd.textContent.toLowerCase().includes(t) && nd.parentElement && vis(nd.parentElement)) { el = nd.parentElement; break; }
    }
  }
  if (!el) return null;
  window.__agentEl = el;
  el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'instant' });
  const r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
  const hit = document.elementFromPoint(x, y);
  const name = (e) => e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + (e.classList.length ? '.' + [...e.classList].slice(0, 2).join('.') : '');
  return { x, y, w: r.width, h: r.height, name: name(el), text: String(el.innerText || el.value || el.getAttribute('aria-label') || '').trim().replace(/\s+/g, ' ').slice(0, 60),
    covered: hit && hit !== el && !el.contains(hit) && !hit.contains(el) ? name(hit) : null };
}

function pageFocusClear(clear) {
  const el = window.__agentEl; if (!el) return false;
  el.focus();
  if (!clear) { if (el.setSelectionRange && typeof el.value === 'string') { try { el.setSelectionRange(el.value.length, el.value.length); } catch { /* number inputs */ } } return true; }
  if (typeof el.select === 'function') el.select();
  else { const r = document.createRange(); r.selectNodeContents(el); const s = getSelection(); s.removeAllRanges(); s.addRange(r); }
  return true;
}

function pageSelect(value) {
  const el = window.__agentEl;
  if (!el || el.tagName !== 'SELECT') return 'Это не выпадающий список <select>';
  const v = String(value), opt = [...el.options].find((o) => o.value === v || o.text.trim() === v) || [...el.options].find((o) => o.text.toLowerCase().includes(v.toLowerCase()));
  if (!opt) return `Нет варианта «${v}». Есть: ${[...el.options].map((o) => o.text.trim()).slice(0, 30).join(', ')}`;
  el.value = opt.value; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
  return `Выбрано: ${opt.text.trim()}`;
}

function pageWaitFor(spec) {
  if (spec.selector) return !!document.querySelector(spec.selector);
  return (document.body ? document.body.innerText : '').toLowerCase().includes(String(spec.text).toLowerCase());
}

// Design mode overlay: hover highlights, click selects, a small panel asks what to change; the answer goes to
// the CLI through the agentPick binding. Lives in a closed shadow root so the page's styles do not touch it.
function designOverlay() {
  if (window.__agentDesign) { window.__agentDesign.on(); return; }
  const start = () => {
    if (window.__agentDesign) return;
    const host = document.createElement('agent-design');
    host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none';
    const root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `<style>
      *{box-sizing:border-box;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
      .box{position:fixed;border:1px solid #fff;box-shadow:0 0 0 1px #000;pointer-events:none;display:none}
      .box.sel{border-width:2px}
      .tag{position:fixed;background:#000;color:#fff;font-size:11px;line-height:16px;padding:1px 6px;border:1px solid #333;pointer-events:none;display:none;white-space:nowrap}
      .bar{position:fixed;top:12px;right:12px;display:flex;gap:10px;align-items:center;background:#0a0a0a;color:#fff;border:1px solid #2a2a2a;padding:5px 5px 5px 12px;font-size:11px;letter-spacing:.06em;pointer-events:auto;box-shadow:0 8px 24px rgba(0,0,0,.35)}
      .bar .note{color:#999;letter-spacing:0}
      .panel{position:fixed;width:320px;background:#0a0a0a;color:#fff;border:1px solid #2a2a2a;padding:10px;pointer-events:auto;display:none;box-shadow:0 8px 24px rgba(0,0,0,.35)}
      .lbl{font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:#999;margin-bottom:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      textarea{display:block;width:100%;height:64px;resize:vertical;background:#000;color:#fff;border:1px solid #333;padding:8px;font-size:12px;outline:none}
      textarea:focus{border-color:#666}
      .row{display:flex;justify-content:flex-end;gap:6px;margin-top:8px}
      button{background:#000;color:#fff;border:1px solid #333;padding:4px 10px;font-size:11px;cursor:pointer;border-radius:4px}
      button:hover{border-color:#666}
      button.main{background:#fff;color:#000;border-color:#fff}
    </style><div class="box"></div><div class="tag"></div>
    <div class="bar">KLINCH ДИЗАЙН <span class="note">кликните элемент</span><button class="exit">Выйти</button></div>
    <div class="panel"><div class="lbl"></div><textarea placeholder="Что изменить?"></textarea><div class="row"><button class="cancel">Отмена</button><button class="main send">Отправить ↵</button></div></div>`;
    const $ = (s) => root.querySelector(s);
    const box = $('.box'), tag = $('.tag'), panel = $('.panel'), ta = $('textarea'), note = $('.note'), bar = $('.bar');
    let on = true, picked = null;
    const name = (e) => e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + (e.classList.length ? '.' + [...e.classList].slice(0, 2).join('.') : '');
    const mark = (el, sel) => {
      const r = el.getBoundingClientRect();
      Object.assign(box.style, { display: 'block', left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' });
      box.classList.toggle('sel', !!sel);
      tag.textContent = `${name(el)}  ${Math.round(r.width)}×${Math.round(r.height)}`;
      Object.assign(tag.style, { display: 'block', left: Math.max(0, r.left) + 'px', top: (r.top > 22 ? r.top - 20 : r.bottom + 2) + 'px' });
    };
    const hide = () => { box.style.display = tag.style.display = 'none'; };
    const ours = (e) => e.composedPath().includes(host);
    const cssPath = (el) => {
      const parts = [];
      while (el && el.nodeType === 1 && el !== document.documentElement) {
        let p = el.tagName.toLowerCase();
        if (el.id && /^[A-Za-z][\w-]*$/.test(el.id)) { parts.unshift(p + '#' + el.id); break; }
        const cls = [...el.classList].filter((c) => /^[A-Za-z_][\w-]*$/.test(c) && c.length < 40).slice(0, 2);
        if (cls.length) p += '.' + cls.join('.');
        const par = el.parentElement;
        if (par) { const same = [...par.children].filter((x) => x.tagName === el.tagName); if (same.length > 1) p += `:nth-of-type(${same.indexOf(el) + 1})`; }
        parts.unshift(p); el = par;
      }
      return parts.join(' > ');
    };
    const info = (el) => {
      const cs = getComputedStyle(el), r = el.getBoundingClientRect(), styles = {};
      for (const k of ['color', 'background-color', 'font-size', 'font-weight', 'font-family', 'line-height', 'padding', 'margin', 'border', 'border-radius', 'width', 'height', 'display', 'gap'])
        styles[k] = cs.getPropertyValue(k);
      const src = []; const comps = [];
      const fk = Object.keys(el).find((k) => k.startsWith('__reactFiber$'));
      for (let f = fk ? el[fk] : null, i = 0; f && i < 40; f = f.return, i++) {
        if (f._debugSource && src.length < 2) src.push(`${f._debugSource.fileName}:${f._debugSource.lineNumber}`);
        const t = f.type, n = t && (typeof t === 'function' || typeof t === 'object') && (t.displayName || t.name);
        if (n && !comps.includes(n) && comps.length < 6) comps.push(n);
      }
      for (let e = el; e && src.length < 2; e = e.parentElement) {
        const v = e.__vueParentComponent; if (v && v.type && v.type.__file) { src.push(v.type.__file); if (v.type.__name) comps.push(v.type.__name); break; }
        const s = e.__svelte_meta; if (s && s.loc) { src.push(`${s.loc.file}:${s.loc.line}`); break; }
      }
      const data = {};
      for (const a of el.attributes) if (a.name.startsWith('data-') && a.name !== 'data-kref' && Object.keys(data).length < 10) data[a.name] = a.value.slice(0, 120);
      const html = el.outerHTML;
      return { url: location.href, selector: cssPath(el), tag: el.tagName.toLowerCase(), id: el.id || null, classes: [...el.classList].join(' '),
        text: String(el.innerText || '').trim().replace(/\s+/g, ' ').slice(0, 200), html: html.length > 1500 ? html.slice(0, 1500) + '…' : html,
        styles, source: src, components: comps, data, rect: { x: r.left + scrollX, y: r.top + scrollY, w: r.width, h: r.height } };
    };
    const close = () => { picked = null; panel.style.display = 'none'; ta.value = ''; hide(); };
    const send = () => {
      const text = ta.value.trim();
      if (!picked || !text) { ta.focus(); return; }
      window.agentPick(JSON.stringify({ instruction: text, ...info(picked) }));
      close(); note.textContent = 'отправлено агенту';
      setTimeout(() => { note.textContent = 'кликните элемент'; }, 4000);
    };
    const block = (e) => { if (on && !ours(e)) { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); } };
    for (const ev of ['mousedown', 'mouseup', 'pointerdown', 'pointerup', 'dblclick', 'contextmenu', 'submit']) document.addEventListener(ev, block, true);
    document.addEventListener('mousemove', (e) => {
      if (!on || picked || ours(e)) return;
      const el = document.elementFromPoint(e.clientX, e.clientY);
      if (el && el !== host) mark(el); else hide();
    }, true);
    document.addEventListener('click', (e) => {
      if (!on || ours(e)) return;
      block(e);
      const el = document.elementFromPoint(e.clientX, e.clientY);
      if (!el || el === host) return;
      picked = el; mark(el, true);
      $('.lbl').textContent = `${name(el)}${el.innerText ? '  ' + el.innerText.trim().replace(/\s+/g, ' ').slice(0, 40) : ''}`;
      const r = el.getBoundingClientRect(), below = innerHeight - r.bottom > 150;
      Object.assign(panel.style, { display: 'block', left: Math.min(Math.max(8, r.left), innerWidth - 330) + 'px', top: (below ? r.bottom + 8 : Math.max(8, r.top - 150)) + 'px' });
      ta.focus();
    }, true);
    addEventListener('scroll', () => { if (picked) mark(picked, true); else hide(); }, true);
    ta.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
      if (e.key === 'Escape') close();
    });
    $('.send').addEventListener('click', send);
    $('.cancel').addEventListener('click', close);
    $('.exit').addEventListener('click', () => { window.__agentDesign.off(); window.agentPick(JSON.stringify({ exit: true })); });
    window.__agentDesign = {
      on() { on = true; bar.style.display = 'flex'; },
      off() { on = false; close(); bar.style.display = 'none'; },
    };
    document.documentElement.appendChild(host);
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
}

// ── The browser session ───────────────────────────────────────────────────────────────────────────────────────
let B = null;                     // { proc, cdp, session, targetId, frameId, visible, url, logs, ... }
let launching = null;
const pickListeners = new Set();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const expr = (fn, ...args) => `(${fn})(${args.map((a) => JSON.stringify(a)).join(',')})`;

const profileDir = (env) => join(env.KLINCH_HOME || join(homedir(), '.klinch'), 'browser');

function log(level, text) {
  if (!B) return;
  B.logs.push({ n: ++B.logSeq, level, text: String(text).slice(0, 2000) });
  if (B.logs.length > LOG_MAX) B.logs.splice(0, B.logs.length - LOG_MAX);
}
const argText = (a) => (a.type === 'string' ? a.value : a.unserializableValue ?? (a.value !== undefined ? JSON.stringify(a.value) : a.description || a.type));

function onEvent(m) {
  if (!B) return;
  const p = m.params || {};
  if (m.method === 'Target.targetCreated' && p.targetInfo?.type === 'page' && p.targetInfo.openerId === B.targetId) { attach(p.targetInfo.targetId, true).catch(() => {}); return; }
  if (m.method === 'Target.targetDestroyed' && p.targetId === B.targetId && B.stack.length) { const prev = B.stack.pop(); Object.assign(B, prev); log('info', 'вкладка закрылась, вернулся на прежнюю'); return; }
  if (m.method === 'Target.detachedFromTarget' && p.sessionId === B.session && B.stack.length) { Object.assign(B, B.stack.pop()); return; }
  if (m.sessionId !== B.session) return;
  switch (m.method) {
    case 'Runtime.consoleAPICalled': log(p.type === 'warning' ? 'warn' : p.type === 'error' || p.type === 'assert' ? 'error' : 'log', (p.args || []).map(argText).join(' ')); break;
    case 'Runtime.exceptionThrown': { const d = p.exceptionDetails || {}; log('error', `${d.exception?.description || d.text}${d.url ? ` (${d.url}:${d.lineNumber + 1})` : ''}`); break; }
    case 'Log.entryAdded': if (p.entry && p.entry.level !== 'verbose' && p.entry.source !== 'network') log(p.entry.level === 'warning' ? 'warn' : p.entry.level, `${p.entry.text}${p.entry.url ? ` (${p.entry.url})` : ''}`); break;
    case 'Network.requestWillBeSent': B.reqs.set(p.requestId, `${p.request.method} ${p.request.url}`); if (B.reqs.size > 2000) B.reqs.delete(B.reqs.keys().next().value); break;
    case 'Network.responseReceived':
      if (p.type === 'Document' && p.frameId === B.frameId) B.status = p.response.status;
      if (p.response.status >= 400) log('error', `HTTP ${p.response.status} ${B.reqs.get(p.requestId) || p.response.url}`);
      break;
    case 'Network.loadingFailed': if (!p.canceled) log('error', `не загрузилось: ${B.reqs.get(p.requestId) || ''} (${p.errorText})`); B.reqs.delete(p.requestId); break;
    case 'Network.loadingFinished': B.reqs.delete(p.requestId); break;
    case 'Page.frameStartedLoading': if (p.frameId === B.frameId) B.loading = true; break;
    case 'Page.frameStoppedLoading': if (p.frameId === B.frameId) { B.loading = false; B.loads++; } break;
    case 'Page.loadEventFired': B.loading = false; B.loads++; break;
    case 'Page.frameNavigated': if (!p.frame.parentId) { B.frameId = p.frame.id; B.url = p.frame.url; } break;
    case 'Page.javascriptDialogOpening':
      log('info', `диалог ${p.type}: ${p.message} (подтверждён автоматически)`);
      B.cdp.send('Page.handleJavaScriptDialog', { accept: true, promptText: p.defaultPrompt || '' }, B.session).catch(() => {});
      break;
    case 'Runtime.bindingCalled':
      if (p.name === 'agentPick') {
        let pick; try { pick = JSON.parse(p.payload); } catch { return; }
        if (pick.exit) { B.design = false; }
        if (B.waiter) { const w = B.waiter; B.waiter = null; w(pick); } else for (const fn of pickListeners) fn(pick);
      }
      break;
    default:
  }
}

async function attach(targetId, popup = false) {
  const { sessionId } = await B.cdp.send('Target.attachToTarget', { targetId, flatten: true });
  if (popup) { B.stack.push({ session: B.session, targetId: B.targetId, frameId: B.frameId, url: B.url }); log('info', 'открылась новая вкладка, работаю в ней'); }
  B.session = sessionId; B.targetId = targetId;
  const s = (m, p) => B.cdp.send(m, p, sessionId);
  await Promise.all([s('Page.enable'), s('Runtime.enable'), s('Log.enable'), s('Network.enable'), s('Page.setBypassCSP', { enabled: true })]);
  if (!B.visible) await s('Emulation.setDeviceMetricsOverride', { ...VIEW, deviceScaleFactor: 1, mobile: false }).catch(() => {});
  await s('Runtime.addBinding', { name: 'agentPick' });
  const tree = await s('Page.getFrameTree');
  B.frameId = tree.frameTree.frame.id; B.url = tree.frameTree.frame.url;
  if (B.design) await enableDesign();
}

async function launch({ visible = false, env = process.env } = {}) {
  const exe = findBrowser(env);
  if (!exe) throw new Error('Не нашёл Chrome, Edge или Chromium. Установите Google Chrome или укажите путь в переменной KLINCH_BROWSER.');
  if (visible && process.platform === 'linux' && !env.DISPLAY && !env.WAYLAND_DISPLAY) throw new Error('Нет экрана для окна браузера (нет DISPLAY). Без окна работают все действия, кроме design и visible.');
  const tryOnce = async (profile) => {
    mkdirSync(profile, { recursive: true });
    const args = [`--user-data-dir=${profile}`, '--remote-debugging-pipe', '--no-first-run', '--no-default-browser-check',
      '--hide-crash-restore-bubble', '--disable-features=Translate,MediaRouter', '--disable-search-engine-choice-screen', '--password-store=basic',
      `--window-size=${VIEW.width},${VIEW.height + 80}`];
    if (!visible) args.push('--headless=new', '--mute-audio');
    if (process.platform === 'linux' && process.getuid?.() === 0) args.push('--no-sandbox');
    args.push('about:blank');
    const proc = spawn(exe, args, { stdio: ['ignore', 'ignore', 'pipe', 'pipe', 'pipe'], windowsHide: !visible });
    let errText = '';
    proc.stderr.on('data', (d) => { errText = (errText + d).slice(-2000); });
    const cdp = createCdp((s) => { try { proc.stdio[3].write(s); } catch { /* closed */ } });
    proc.stdio[4].setEncoding('utf8');
    proc.stdio[4].on('data', (d) => cdp.feed(d));
    proc.stdio[3].on('error', () => {}); proc.stdio[4].on('error', () => {});
    const exited = new Promise((r) => proc.once('exit', (code) => r(code)));
    proc.once('error', (e) => { errText += e.message; });
    const ready = cdp.send('Target.setDiscoverTargets', { discover: true }, undefined, 20000);
    const first = await Promise.race([ready.then(() => 'ok'), exited.then(() => 'exit')]).catch((e) => e.message);
    if (first !== 'ok') { try { proc.kill(); } catch { /* gone */ } return { error: errText.trim().split('\n').slice(-3).join('\n') || String(first) }; }
    return { proc, cdp, exited };
  };
  const main = profileDir(env);
  let r = await tryOnce(main), note = '';
  if (r.error) { r = await tryOnce(mkdtempSync(join(tmpdir(), 'agent-browser-'))); note = 'профиль браузера занят другим окном Klinch, открыл временный (входы не сохранятся)'; }
  if (r.error) throw new Error(`Браузер не запустился: ${r.error}`);
  B = { proc: r.proc, cdp: r.cdp, visible, session: null, targetId: null, frameId: null, url: 'about:blank', status: null, logs: [], logSeq: 0, seen: 0,
    reqs: new Map(), loading: false, loads: 0, stack: [], design: false, designScript: null, waiter: null, note };
  const mine = B;
  r.cdp.on(onEvent);
  r.exited.then(() => { r.cdp.fail(new Error('Браузер закрыт')); if (B === mine) { if (mine.waiter) mine.waiter({ exit: true, closed: true }); for (const fn of pickListeners) fn({ exit: true, closed: true }); B = null; } });
  const { targetInfos } = await r.cdp.send('Target.getTargets');
  let page = targetInfos.find((t) => t.type === 'page');
  if (!page) page = { targetId: (await r.cdp.send('Target.createTarget', { url: 'about:blank' })).targetId };
  await attach(page.targetId);
  if (visible) await r.cdp.send('Page.bringToFront', {}, B.session).catch(() => {});
  return B;
}

/** The running browser, started (or restarted headed) as needed. */
async function ensure({ visible = false, env } = {}) {
  if (launching) await launching.catch(() => {});
  if (B && visible && !B.visible) { const url = B.url; await closeBrowser(); const b = await ensure({ visible, env }); if (url && url !== 'about:blank') await navigate(url); return b; }
  if (B) return B;
  launching = launch({ visible, env });
  try { return await launching; } finally { launching = null; }
}

const send = (method, params, timeout) => B.cdp.send(method, params, B.session, timeout);

async function evaluate(expression, { awaitPromise = true, timeout = 30000 } = {}) {
  const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise, userGesture: true }, timeout);
  if (r.exceptionDetails) throw new Error(`Ошибка в странице: ${r.exceptionDetails.exception?.description?.split('\n')[0] || r.exceptionDetails.text}`);
  return r.result?.value;
}

/** Waits for the page to finish loading after an action that may navigate; at most `ms`. */
async function settle(loadsBefore, ms = 10000) {
  await sleep(300);
  const until = Date.now() + ms;
  while (B && B.loading && Date.now() < until) await sleep(100);
  if (B && B.loads !== loadsBefore) await sleep(300);
}

async function navigate(url) {
  B.status = null;
  const before = B.loads;
  const r = await send('Page.navigate', { url });
  if (r.errorText) throw new Error(`Не открылось ${url}: ${r.errorText}`);
  const until = Date.now() + 30000;
  await sleep(100);
  while (B && B.loads === before && Date.now() < until) await sleep(100);
  await sleep(400);
}

/** New console lines since the last look. `levels`: which to include. */
function freshLogs({ levels = ['error', 'warn'], all = false } = {}) {
  const from = all ? 0 : B.seen;
  const list = B.logs.filter((l) => l.n > from && (all || levels.includes(l.level)));
  return list;
}
const fmtLogs = (list) => list.map((l) => `[${l.level}] ${l.text}`).join('\n');

async function snapshot(maxText = 6000) {
  const s = await evaluate(expr(pageSnapshot, maxText));
  return `${s.title || '(без заголовка)'} — ${s.url}${B.status ? ` (HTTP ${B.status})` : ''}\nПрокрутка: ${s.scroll}\n\nТекст страницы:\n${s.text || '(пусто)'}\n\nЭлементы (ref для click/type):\n${s.els.join('\n') || '(нет)'}`;
}

function errorsTail() {
  const errs = freshLogs({ levels: ['error'] });
  B.seen = B.logSeq;
  return errs.length ? `\n\nОшибки в консоли (${errs.length}):\n${fmtLogs(errs.slice(-15))}` : '';
}

async function find(input) {
  if (input.x != null && input.y != null) return { x: +input.x, y: +input.y, name: `точка ${input.x},${input.y}`, text: '' };
  if (!input.ref && !input.selector && !input.text) throw new Error('Укажи ref (из snapshot), selector или text');
  const f = await evaluate(expr(pageFind, { ref: input.ref, selector: input.selector, text: input.text }));
  if (!f) throw new Error(`Элемент не найден: ${input.ref ? `ref ${input.ref} (сделай snapshot заново)` : input.selector || `«${input.text}»`}`);
  return f;
}

async function mouseClick(x, y, count = 1) {
  await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y });
  for (let i = 1; i <= count; i++) {
    await send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: i });
    await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: i });
  }
}

const KEYS = { Enter: [13, '\r'], Tab: [9], Escape: [27], Backspace: [8], Delete: [46], ArrowUp: [38], ArrowDown: [40], ArrowLeft: [37], ArrowRight: [39],
  Home: [36], End: [35], PageUp: [33], PageDown: [34], Space: [32, ' '], ' ': [32, ' '] };
const ALIAS = { enter: 'Enter', return: 'Enter', tab: 'Tab', esc: 'Escape', escape: 'Escape', backspace: 'Backspace', delete: 'Delete', del: 'Delete', up: 'ArrowUp', down: 'ArrowDown', left: 'ArrowLeft', right: 'ArrowRight',
  arrowup: 'ArrowUp', arrowdown: 'ArrowDown', arrowleft: 'ArrowLeft', arrowright: 'ArrowRight', home: 'Home', end: 'End', pageup: 'PageUp', pagedown: 'PageDown', space: 'Space' };
const MODS = { alt: 1, ctrl: 2, control: 2, meta: 4, cmd: 4, command: 4, shift: 8 };

async function pressKey(combo) {
  const parts = String(combo).split('+').map((x) => x.trim()).filter(Boolean);
  let mods = 0; let key = parts.pop() || '';
  for (const m of parts) mods |= MODS[m.toLowerCase()] || 0;
  key = ALIAS[key.toLowerCase()] || key;
  let vk, text, code;
  if (KEYS[key]) { [vk, text] = KEYS[key]; code = key === ' ' ? 'Space' : key; if (key === 'Space') key = ' '; }
  else if (key.length === 1) { const up = key.toUpperCase(); vk = up.charCodeAt(0); code = /[A-Z]/.test(up) ? 'Key' + up : /\d/.test(key) ? 'Digit' + key : undefined; text = mods & 6 ? undefined : key; }
  else if (/^F\d{1,2}$/.test(key)) { vk = 111 + +key.slice(1); code = key; }
  else throw new Error(`Не знаю клавишу ${key}`);
  const base = { modifiers: mods, key, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk };
  await send('Input.dispatchKeyEvent', { type: text ? 'keyDown' : 'rawKeyDown', ...base, ...(text ? { text, unmodifiedText: text } : {}) });
  await send('Input.dispatchKeyEvent', { type: 'keyUp', ...base });
}

async function screenshot({ full_page, ref, selector, text } = {}) {
  let clip;
  if (ref || selector || text) {
    const f = await find({ ref, selector, text });
    const m = await send('Page.getLayoutMetrics');
    const sx = m.cssVisualViewport?.pageX || 0, sy = m.cssVisualViewport?.pageY || 0;
    clip = { x: Math.max(0, f.x - f.w / 2 - 8 + sx), y: Math.max(0, f.y - f.h / 2 - 8 + sy), width: Math.min(f.w + 16, 4000), height: Math.min(f.h + 16, 4000), scale: 1 };
  } else if (full_page) {
    const m = await send('Page.getLayoutMetrics');
    const size = m.cssContentSize || m.contentSize;
    clip = { x: 0, y: 0, width: Math.min(size.width, 1600), height: Math.min(size.height, 8000), scale: 1 };
  }
  let r = await send('Page.captureScreenshot', { format: 'jpeg', quality: 80, ...(clip ? { clip, captureBeyondViewport: true } : {}) });
  if (r.data.length > 6_500_000) r = await send('Page.captureScreenshot', { format: 'jpeg', quality: 45, ...(clip ? { clip, captureBeyondViewport: true } : {}) });
  return Buffer.from(r.data, 'base64');
}

async function enableDesign() {
  if (!B.designScript) B.designScript = (await send('Page.addScriptToEvaluateOnNewDocument', { source: expr(designOverlay) })).identifier;
  await evaluate(expr(designOverlay)).catch(() => {});
  B.design = true;
}

async function disableDesign() {
  if (!B) return;
  B.design = false;
  if (B.designScript) { await send('Page.removeScriptToEvaluateOnNewDocument', { identifier: B.designScript }).catch(() => {}); B.designScript = null; }
  await evaluate('window.__agentDesign && window.__agentDesign.off()').catch(() => {});
}

/** Starts design mode in a visible window (opening `url` if given). Picks go to onPick listeners or the waiting tool. */
export async function startDesign({ url, env } = {}) {
  await ensure({ visible: true, env });
  if (url) await navigate(normalizeUrl(url));
  await enableDesign();
  await send('Page.bringToFront').catch(() => {});
  return B.url;
}
export const stopDesign = () => disableDesign();
export const designActive = () => !!B?.design;
/** The page the browser shows now (null when it is not running). */
export const browserUrl = () => B?.url ?? null;
export function onPick(fn) { pickListeners.add(fn); return () => pickListeners.delete(fn); }

/** Element screenshot for a design pick (null if it fails). */
async function pickImage(pick) {
  if (!B || !pick.rect || pick.rect.w < 2 || pick.rect.h < 2) return null;
  try {
    await evaluate('window.__agentDesign && window.__agentDesign.off()');
    const pad = 24, r = pick.rect;
    const shot = await send('Page.captureScreenshot', { format: 'jpeg', quality: 80, captureBeyondViewport: true,
      clip: { x: Math.max(0, r.x - pad), y: Math.max(0, r.y - pad), width: Math.min(r.w + pad * 2, 1600), height: Math.min(r.h + pad * 2, 1600), scale: 1 } });
    return imageBlock(Buffer.from(shot.data, 'base64'), 'image/jpeg');
  } catch { return null; } finally { if (B?.design) await evaluate('window.__agentDesign && window.__agentDesign.on()').catch(() => {}); }
}

/** A design pick as message content for the agent: what the user clicked, where it lives in the code, and the task. */
export async function pickToContent(pick) {
  const st = Object.entries(pick.styles || {}).filter(([, v]) => v && v !== 'none' && v !== 'normal' && v !== '0px').map(([k, v]) => `${k}: ${v}`).join('; ');
  const lines = [
    `Правка из браузера (режим дизайна). Страница: ${pick.url}`,
    `Элемент: ${pick.selector}`,
    pick.text && `Текст: «${pick.text}»`,
    pick.source?.length && `Исходник: ${pick.source.join(', ')}`,
    pick.components?.length && `Компоненты: ${pick.components.join(' < ')}`,
    Object.keys(pick.data || {}).length && `Атрибуты: ${Object.entries(pick.data).map(([k, v]) => `${k}="${v}"`).join(' ')}`,
    st && `Стили сейчас: ${st}`,
    `HTML:\n${pick.html}`,
    '',
    `Что сделать: ${pick.instruction}`,
    '',
    'Найди этот элемент в коде проекта (по исходнику, классам, тексту), внеси правку, потом browser reload и browser screenshot, чтобы проверить результат.',
  ].filter((x) => typeof x === 'string');
  const img = await pickImage(pick);
  return img ? [{ type: 'text', text: lines.join('\n') }, img] : lines.join('\n');
}

export async function closeBrowser() {
  if (!B) return false;
  const b = B; B = null;
  try { await b.cdp.send('Browser.close', {}, undefined, 3000); } catch { /* already gone */ }
  setTimeout(() => { try { b.proc.kill(); } catch { /* gone */ } }, 1500).unref();
  return true;
}
process.once('exit', () => { try { B?.proc.kill(); } catch { /* gone */ } });

const ACTIONS = ['open', 'snapshot', 'screenshot', 'click', 'type', 'press', 'select', 'hover', 'scroll', 'wait', 'console', 'eval', 'back', 'forward', 'reload', 'design', 'close'];
const CHANGES = new Set(['click', 'type', 'press', 'select', 'eval']);

/** The `browser` tool for the agent. */
export const BROWSER_TOOL = {
  name: 'browser',
  description: 'Браузер (Chrome/Edge) для проверки сайта или приложения: открыть страницу, прочитать её, кликать, вводить текст, смотреть ошибки консоли и скриншоты. '
    + 'action: open (url; visible: true = окно на экране, иначе без окна), snapshot (текст страницы и элементы с ref), screenshot (картинка экрана; full_page, или ref/selector = один элемент; path = сохранить PNG в проект), '
    + 'click (ref | selector | text | x,y; double), type (ref | selector, text; clear по умолчанию true; submit = Enter), press (key: Enter, Escape, Tab, ArrowDown, Ctrl+A…), select (ref, value для <select>), hover, '
    + 'scroll (dy пикселей, или ref = докрутить до элемента), wait (text или selector, sec), console (новые сообщения консоли и сетевые ошибки; all: true = все), eval (js в странице, вернёт результат), back, forward, reload, '
    + 'design (режим дизайна: окно с подсветкой, пользователь кликает элемент и пишет, что изменить; вернёт элемент, его исходник и задачу; wait_sec до 600), close. '
    + 'Порядок работы: запусти dev-сервер (shell background), open его адрес, snapshot, действуй по ref, после правок кода reload и проверь console и screenshot. '
    + 'Профиль браузера сохраняет входы. Паролей не вводи и не спрашивай: если нужен вход, open с visible: true и попроси пользователя войти самому в окне.',
  input_schema: { type: 'object', properties: {
    action: { type: 'string', enum: ACTIONS },
    url: { type: 'string' }, visible: { type: 'boolean' },
    ref: { type: 'integer', description: 'Номер элемента из последнего snapshot' }, selector: { type: 'string', description: 'CSS-селектор' }, text: { type: 'string', description: 'Для click: текст на элементе; для type: что ввести; для wait: какой текст ждать' },
    x: { type: 'number' }, y: { type: 'number' }, double: { type: 'boolean' },
    clear: { type: 'boolean' }, submit: { type: 'boolean' }, key: { type: 'string' }, value: { type: 'string' },
    dy: { type: 'integer' }, sec: { type: 'integer' }, wait_sec: { type: 'integer' }, all: { type: 'boolean' },
    full_page: { type: 'boolean' }, path: { type: 'string' }, js: { type: 'string' } }, required: ['action'] },
  // Changing things on a site off this computer (a shop, a mail box with the user's login) asks first.
  danger: (input = {}) => CHANGES.has(input.action) && !!B && !isLocalUrl(B.url),
  preview: (i = {}) => {
    const what = i.url || (i.ref ? `[${i.ref}]` : '') || i.selector || (i.action !== 'type' && i.text ? `«${i.text}»` : '') || i.key || (i.js ? i.js.slice(0, 80) : '');
    return `browser ${i.action}${what ? ' ' + what : ''}${i.action === 'type' && i.text != null ? ` ← «${String(i.text).slice(0, 60)}»` : ''}${B && !isLocalUrl(B.url) && CHANGES.has(i.action) ? `   (на ${new URL(B.url).host})` : ''}`;
  },
  async run(input, ctx = {}) {
    const a = input.action, env = ctx.env || process.env;
    if (a === 'close') return (await closeBrowser()) ? 'Браузер закрыт' : 'Браузер и так не запущен';
    if (a === 'console' && !B) return 'Браузер не запущен';
    await ensure({ visible: !!input.visible || a === 'design', env });
    const note = B.note ? `(${B.note})\n` : ''; B.note = '';
    switch (a) {
      case 'open': {
        if (!input.url) throw new Error('Нужен url');
        B.seen = B.logSeq;
        await navigate(normalizeUrl(input.url));
        return note + await snapshot() + errorsTail();
      }
      case 'snapshot': return note + await snapshot(8000) + errorsTail();
      case 'screenshot': {
        const buf = await screenshot(input);
        let saved = '';
        if (input.path) {
          const { safePath } = await import('./tools.js');
          const abs = safePath(ctx.cwd || process.cwd(), input.path, { write: true });
          mkdirSync(dirname(abs), { recursive: true });
          const png = await send('Page.captureScreenshot', { format: 'png' });
          writeFileSync(abs, Buffer.from(png.data, 'base64'));
          saved = `, сохранён в ${input.path}`;
        }
        return [{ type: 'text', text: `${note}Скриншот ${B.url}${saved}${errorsTail()}` }, imageBlock(buf, 'image/jpeg')];
      }
      case 'click': case 'hover': {
        const f = await find(input);
        if (f.covered && a === 'click') { /* still click: the page decides; tell the model what was on top */ }
        const before = B.loads, url = B.url;
        if (a === 'hover') { await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: f.x, y: f.y }); await sleep(300); return `Навёл на ${f.name}${f.text ? ` «${f.text}»` : ''}`; }
        await mouseClick(f.x, f.y, input.double ? 2 : 1);
        await settle(before);
        const moved = B.url !== url;
        return `Нажал ${f.name}${f.text ? ` «${f.text}»` : ''}${f.covered ? ` (сверху был ${f.covered}: клик мог попасть в него)` : ''}.`
          + (moved ? `\nОткрылась страница:\n${await snapshot()}` : ` Страница: ${B.url}`) + errorsTail();
      }
      case 'type': {
        if (input.text == null) throw new Error('Нужен text');
        const f = await find(input.ref || input.selector ? input : { ...input, text: undefined, selector: ':focus' });
        if (input.ref || input.selector) await mouseClick(f.x, f.y);
        await evaluate(expr(pageFocusClear, input.clear !== false));
        if (String(input.text)) await send('Input.insertText', { text: String(input.text) }); else if (input.clear !== false) await pressKey('Backspace');
        let tail = '';
        if (input.submit) { const before = B.loads, url = B.url; await pressKey('Enter'); await settle(before); if (B.url !== url) tail = `\nОткрылась страница:\n${await snapshot()}`; }
        return `Ввёл в ${f.name}${input.submit ? ' и нажал Enter' : ''}.${tail}${errorsTail()}`;
      }
      case 'press': {
        if (!input.key) throw new Error('Нужен key');
        const before = B.loads; await pressKey(input.key); await settle(before, 5000);
        return `Нажал ${input.key}. Страница: ${B.url}${errorsTail()}`;
      }
      case 'select': { await find(input); const r = await evaluate(expr(pageSelect, input.value ?? input.text ?? '')); await sleep(200); return r + errorsTail(); }
      case 'scroll': {
        if (input.ref || input.selector || input.text) { const f = await find(input); return `Докрутил до ${f.name}`; }
        await evaluate(`scrollBy(0, ${+input.dy || 600})`); await sleep(250);
        return `Прокрутил. ${await evaluate('`${Math.round(scrollY)} из ${Math.max(0, Math.round(document.documentElement.scrollHeight - innerHeight))}`')}`;
      }
      case 'wait': {
        const until = Date.now() + Math.min(Math.max(+input.sec || 10, 1), 60) * 1000;
        if (!input.text && !input.selector) { await sleep(until - Date.now()); return 'Подождал'; }
        for (;;) {
          if (await evaluate(expr(pageWaitFor, { text: input.text, selector: input.selector })).catch(() => false)) return `Появилось: ${input.selector || `«${input.text}»`}${errorsTail()}`;
          if (Date.now() > until) return `Не дождался ${input.selector || `«${input.text}»`}${errorsTail()}`;
          await sleep(250);
        }
      }
      case 'console': {
        const list = freshLogs({ all: !!input.all, levels: ['error', 'warn', 'log', 'info'] });
        B.seen = B.logSeq;
        return list.length ? fmtLogs(list.slice(-100)) : input.all ? 'Консоль пуста' : 'Новых сообщений нет';
      }
      case 'eval': {
        if (!input.js) throw new Error('Нужен js');
        const v = await evaluate(input.js);
        const s = v === undefined ? 'undefined' : typeof v === 'string' ? v : JSON.stringify(v, null, 1);
        return (s.length > 20000 ? s.slice(0, 20000) + '\n… (обрезано)' : s) + errorsTail();
      }
      case 'back': case 'forward': {
        const h = await send('Page.getNavigationHistory');
        const e = h.entries[h.currentIndex + (a === 'back' ? -1 : 1)];
        if (!e) return a === 'back' ? 'Назад некуда' : 'Вперёд некуда';
        const before = B.loads; await send('Page.navigateToHistoryEntry', { entryId: e.id }); await settle(before);
        return await snapshot() + errorsTail();
      }
      case 'reload': {
        B.seen = B.logSeq;
        const before = B.loads; await send('Page.reload', { ignoreCache: true });
        const until = Date.now() + 30000; while (B && B.loads === before && Date.now() < until) await sleep(100); await sleep(400);
        return `Перезагрузил ${B.url}${B.status ? ` (HTTP ${B.status})` : ''}${errorsTail() || '\nОшибок в консоли нет.'}`;
      }
      case 'design': {
        await startDesign({ url: input.url, env });
        const sec = Math.min(Math.max(+input.wait_sec || 300, 10), 600);
        const pick = await new Promise((res) => { B.waiter = res; setTimeout(() => { if (B?.waiter === res) { B.waiter = null; res(null); } }, sec * 1000); });
        if (!pick) return `Режим дизайна открыт на ${B?.url}, но за ${sec} с пользователь ничего не выбрал.`;
        if (pick.exit) return pick.closed ? 'Пользователь закрыл браузер.' : 'Пользователь вышел из режима дизайна.';
        return pickToContent(pick);
      }
      default: throw new Error(`Неизвестное действие ${a}. Есть: ${ACTIONS.join(', ')}`);
    }
  },
};
