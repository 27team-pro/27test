// SDK: the Klinch Code agent inside your own program, with the same tools, skills, rules, MCP servers and memory as
// the terminal chat.
//
//   import { createSession, query, run, tool } from 'klinch-code';
//
//   const s = await createSession({ cwd: '/path/to/project', permissionMode: 'acceptEdits' });
//   for await (const ev of s.stream('Почини падающий тест')) if (ev.type === 'text') process.stdout.write(ev.text);
//   const r = await s.send('Теперь добавь тест на пустой ввод');   // { text, usage, steps, toolCalls, denied }
//   await s.close();
//
//   const r2 = await run('Опиши проект в двух абзацах', { cwd: '.' });         // one task, the result
//   for await (const ev of query({ prompt: 'Обнови README', options: { cwd: '.' } })) console.log(ev);
//
// The key, the address and the model come from the options, else from ~/.klinch/config.json and KLINCH_API_KEY
// (as for the CLI: `klinch login` once is enough).
//
// Events of stream(): { type: 'text', text } (pieces of the answer), { type: 'thinking' } (the model reasons; the
// reasoning itself is not shown), { type: 'tool_call', id, name, input, preview }, { type: 'tool_result', id, name,
// content, is_error }, { type: 'note', text }, { type: 'todos', todos }, { type: 'plan', plan }, last
// { type: 'result', text, is_error, error?, usage, steps, toolCalls, denied, model, duration_ms }.
//
// Permissions (permissionMode): 'default' asks canUseTool for edits and commands (without canUseTool they are
// refused), 'acceptEdits' lets file edits through and asks for the rest, 'bypassPermissions' lets everything
// through, 'plan' only reads and returns a plan. Permission rules of the project and the user (permissions.allow /
// deny) apply in every mode.
import { loadConfig } from './config.js';
import { createClient } from './api.js';
import { withLocal } from './localmodels.js';
import { createAgent, formatTodos } from './agent.js';
import { proposedContent, killAllBackground } from './tools.js';
import { detectSandbox, sandboxSettings } from './sandbox.js';
import { startServers, connect as connectMcp, toAgentTools } from './mcp.js';
import { loadRules } from './rules.js';
import { loadSkills, loadInstructions, loadAgents, loadOutputStyles } from './skills.js';
import { loadHookConfigs, createHooks, isTrusted as hooksTrusted, noHooks } from './hooks.js';
import { loadPermissions, projectAllow } from './permissions.js';
import { createDiagnostics } from './lsp.js';
import { createCodeIndex, EMBED_MODEL, DIMS } from './codeindex.js';
import { mediaTools } from './media.js';
import { loadSoul, personaText } from './bots.js';
import { scheduleTool } from './schedule.js';
import { VERSION } from './local.js';

export { VERSION };
export const PERMISSION_MODES = ['default', 'acceptEdits', 'bypassPermissions', 'plan'];
const EDIT_TOOLS = new Set(['write_file', 'edit_file', 'notebook_edit']);

/**
 * A tool of your program for the agent: tool('weather', 'Погода в городе', { city: { type: 'string' } },
 * async ({ city }) => '…'). `schema` is either the properties of an object or a full JSON schema. The run function
 * returns a string or Anthropic content blocks. { danger: true } asks canUseTool before each call.
 */
export function tool(name, description, schema, run, { danger = false } = {}) {
  const input_schema = schema?.type === 'object' ? schema : { type: 'object', properties: schema || {}, required: Object.keys(schema || {}) };
  return { name, description, input_schema, run: (input, ctx) => run(input, ctx), danger };
}

/** A queue that a callback side fills and an async iterator side drains. */
function channel() {
  const items = []; let wake = null, done = false;
  return {
    push(x) { items.push(x); wake?.(); wake = null; },
    end() { done = true; wake?.(); wake = null; },
    async *[Symbol.asyncIterator]() {
      for (;;) {
        if (items.length) { yield items.shift(); continue; }
        if (done) return;
        await new Promise((r) => { wake = r; });
      }
    },
  };
}

const textOf = (msg) => (msg?.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('').trim();

/** MCP servers given by the program: { name: { command, args, env } | { url, headers } }, or the ACP list. */
function mcpConfigs(list) {
  if (!list) return [];
  const entries = Array.isArray(list) ? list.map((s) => [s.name, s]) : Object.entries(list);
  return entries.filter(([n, s]) => n && s).map(([name, s]) => {
    const pairs = (v) => (Array.isArray(v) ? Object.fromEntries(v.map((x) => [x.name, x.value])) : v || undefined);
    return [name, s.url ? { url: s.url, headers: pairs(s.headers) } : { command: s.command, args: s.args || [], env: pairs(s.env) }];
  });
}

/**
 * Starts an agent session in `cwd`. Options (all optional):
 *   apiKey, baseUrl, model, cwd, env            where and as whom (defaults: config of `klinch login`, process.cwd())
 *   permissionMode, canUseTool({ name, input, preview, diff, id }) → boolean | Promise<boolean>
 *   askUser(question, options) → answer          the agent's ask_user tool (without it the agent decides itself)
 *   tools: [tool(…)]                             your own tools
 *   mcpServers                                   more MCP servers ({ name: config } or a list with name)
 *   instructions                                 extra instructions added to the project's (KLINCH.md, AGENTS.md…)
 *   settingSources: ['user', 'project']          what to load from disk: skills, rules, hooks, MCP, permissions
 *   effort ('low'…'max'), sandbox (true | { network }), maxSteps, maxTokens, memory (true), diagnostics (false)
 *   fetch                                        a fetch implementation (tests, proxies)
 */
export async function createSession(options = {}) {
  const env = options.env || process.env;
  const cfg = loadConfig(env);
  const apiKey = options.apiKey || cfg.apiKey;
  const baseUrl = String(options.baseUrl || cfg.baseUrl).replace(/\/+$/, '');
  if (!apiKey && !String(options.model || '').startsWith('local:')) throw new Error('Нет ключа: передайте apiKey, задайте KLINCH_API_KEY или выполните klinch login');
  const cwd = options.cwd || process.cwd();
  const sources = new Set(options.settingSources || ['user', 'project']);
  const fromDisk = sources.size > 0;
  const client = options.client || withLocal(createClient({ baseUrl, apiKey, ...(options.fetch ? { fetchImpl: options.fetch } : {}) }), cfg);
  let mode = PERMISSION_MODES.includes(options.permissionMode) ? options.permissionMode : 'default';

  // Settings of the folder, as the CLI loads them. Project MCP servers and hooks run only when the user already
  // allowed them in the terminal chat (the SDK cannot ask), the user's own ones always.
  const skills = fromDisk ? loadSkills(cwd, env) : [];
  const instructions = [fromDisk ? loadInstructions(cwd, env) : '', options.instructions || ''].filter(Boolean).join('\n\n');
  const agents = fromDisk ? loadAgents(cwd, env) : [];
  const rules = sources.has('project') ? loadRules(cwd, env) : [];
  const styles = fromDisk ? loadOutputStyles(cwd, env) : [];
  const style = options.outputStyle ? styles.find((x) => x.name === options.outputStyle) || null : null;
  const notes = [];
  const mcp = fromDisk
    ? await startServers({ cwd, env, allow: async () => false, log: (l) => notes.push(l) })
    : { servers: [], tools: [], close() {} };
  const own = [];
  for (const [name, config] of mcpConfigs(options.mcpServers)) {
    try { const conn = await connectMcp(config, { cwd, env }); own.push(conn); mcp.tools.push(...toAgentTools(name, conn)); mcp.servers.push({ name, tools: conn.tools.length }); }
    catch (e) { notes.push(`MCP ${name}: ${e.message}`); mcp.servers.push({ name, tools: 0, error: e.message }); }
  }
  const hookConfigs = fromDisk ? loadHookConfigs(cwd, env).filter((h) => (h.source === 'user' ? sources.has('user') : sources.has('project')) && hooksTrusted(cwd, h, env)) : [];
  const hooks = hookConfigs.length ? createHooks(hookConfigs, { cwd, env, warn: (w) => notes.push(w) }) : noHooks;
  const perms = fromDisk ? loadPermissions(cwd, env, { extraAllow: options.allow || [], projectAllowed: projectAllow(cwd, env).trusted }) : { allow: options.allow || [], deny: [] };
  let sandbox = { active: false };
  if (options.sandbox ?? cfg.sandbox) {
    const st = sandboxSettings(options.sandbox === true ? true : options.sandbox ?? cfg.sandbox);
    const d = st.enabled ? detectSandbox() : {};
    sandbox = d.kind ? { active: true, kind: d.kind, network: st.network, allowWrite: st.allowWrite } : { active: false, network: st.network, allowWrite: st.allowWrite };
    if (st.enabled && !d.kind) notes.push(`песочница недоступна: ${d.reason}`);
  }
  const diagnostics = options.diagnostics ? createDiagnostics(cwd, { env }) : null;
  const codeIndex = options.codeIndex === false || cfg.codeIndex === false || env.KLINCH_INDEX === '0' || !client.embeddings ? null
    : createCodeIndex({ cwd, env, embed: (texts, signal) => client.embeddings(texts, { model: EMBED_MODEL, dimensions: DIMS, signal }) });
  const jobs = [];

  // The current stream() gets the agent's output as events.
  let sink = null;
  const emit = (e) => { sink?.push(e); try { options.onEvent?.(e); } catch { /* the program's own error */ } };
  let text = '';
  const out = {
    text: (t) => { text += t; emit({ type: 'text', text: t }); },
    endText: () => { text = ''; },
    toolStart() {},
    thinking: () => emit({ type: 'thinking' }),
    tool() {},
    sub: (task, call) => emit({ type: 'subagent', task, call: String(call).split('\n')[0] }),
    todos: () => emit({ type: 'todos', todos: agent.todos.map((t) => ({ ...t })), text: formatTodos(agent.todos) }),
    plan: (p) => emit({ type: 'plan', plan: p }),
    note: (n) => emit({ type: 'note', text: n }),
  };
  const allowed = async (preview, o = {}) => {
    if (o.plan) return options.canUseTool ? !!(await options.canUseTool({ name: 'exit_plan_mode', input: {}, preview, plan: true, id: o.id })) : mode === 'bypassPermissions';
    if (mode === 'bypassPermissions') return true;
    if (mode === 'acceptEdits' && EDIT_TOOLS.has(o.tool)) return true;
    if (!options.canUseTool) return false;
    let diff = null;
    if (o.tool === 'edit_file' || o.tool === 'write_file') { try { diff = proposedContent(agent.cwd, o.tool, o.input); } catch { /* a bad path */ } }
    return !!(await options.canUseTool({ name: o.tool, input: o.input || {}, preview, diff, id: o.id }));
  };
  const agent = createAgent({
    client, model: options.model || cfg.model, cwd, out, hooks, permissions: perms,
    persona: fromDisk ? personaText({ soul: loadSoul(cwd, env), bot: null, env }) : '',
    confirm: allowed,
    askUser: options.askUser || null,
    extraTools: [...mcp.tools, scheduleTool(jobs, () => agent.cwd, env), ...mediaTools({ client, env }), ...(options.tools || [])],
    skills, instructions, agents, rules, codeIndex, env, sandbox,
    mode: mode === 'plan' ? 'plan' : 'normal',
    effort: options.effort ?? cfg.effort, outputStyle: style?.prompt ? style : null,
    memory: options.memory ?? cfg.memory !== false,
    diagnose: diagnostics ? (abs) => diagnostics.check(abs) : null,
    maxTokens: options.maxTokens || cfg.maxTokens || 32000, maxSteps: options.maxSteps || cfg.maxSteps || 400,
    ...(cfg.compactAt ? { compactAt: cfg.compactAt, trimAt: Math.round(cfg.compactAt * 0.45) } : {}),
    onStepLimit: options.onStepLimit || null,
    events: {
      toolCall: ({ id, name, input, preview }) => emit({ type: 'tool_call', id, name, input, preview }),
      toolResult: ({ id, name, content, is_error }) => emit({ type: 'tool_result', id, name, content, is_error }),
    },
  });
  if (Array.isArray(options.messages)) agent.messages.push(...options.messages);

  let ctl = null, closed = false;
  const session = {
    /** Messages of the conversation (Anthropic format); save them to continue later with options.messages. */
    get messages() { return agent.messages; },
    get model() { return agent.model; },
    set model(m) { agent.model = m; },
    get cwd() { return agent.cwd; },
    get permissionMode() { return mode; },
    set permissionMode(m) {
      if (!PERMISSION_MODES.includes(m)) throw new Error(`permissionMode: ${PERMISSION_MODES.join(', ')}`);
      mode = m; agent.mode = m === 'plan' ? 'plan' : 'normal';
    },
    get effort() { return agent.effort; },
    set effort(e) { agent.effort = e; },
    get todos() { return agent.todos; },
    get usage() { return agent.lastUsage; },
    /** Warnings from the start (MCP servers that did not start, no sandbox), for logs. */
    notes,
    mcpServers: mcp.servers,
    tools: () => agent.tools().map((t) => t.name),

    /** Runs one message (a string or content blocks) and yields events; the last one is { type: 'result' }. */
    async *stream(prompt, { signal } = {}) {
      if (closed) throw new Error('Сессия закрыта');
      if (ctl) throw new Error('Сессия уже выполняет запрос');
      ctl = new AbortController();
      if (signal) { if (signal.aborted) ctl.abort(); else signal.addEventListener('abort', () => ctl?.abort(), { once: true }); }
      const ch = channel(); sink = ch;
      const started = Date.now();
      const job = agent.ask(prompt, { signal: ctl.signal }).then(
        (msg) => ({ msg, error: null }),
        (error) => ({ msg: null, error }),
      ).then((r) => { ch.end(); return r; });
      try {
        for await (const ev of ch) yield ev;
        const { msg, error } = await job;
        yield {
          type: 'result', is_error: !!error, ...(error ? { error: error.message, interrupted: !!error.interrupted } : {}),
          text: error ? '' : textOf(msg), stop_reason: error ? (error.interrupted ? 'cancelled' : 'error') : msg.stop_reason,
          usage: { ...agent.totalUsage }, steps: agent.steps, toolCalls: [...agent.calls], denied: [...agent.denied],
          model: agent.model, duration_ms: Date.now() - started,
        };
      } finally {
        if (sink === ch) sink = null;
        ctl = null;
      }
    },
    /** Runs one message and returns the result event (throws on errors unless { throwOnError: false }). */
    async send(prompt, { signal, throwOnError = true } = {}) {
      let res = null;
      for await (const ev of session.stream(prompt, { signal })) if (ev.type === 'result') res = ev;
      if (res.is_error && throwOnError) throw Object.assign(new Error(res.error), { result: res, interrupted: res.interrupted });
      return res;
    },
    /** Stops the current request (the result comes with stop_reason 'cancelled'). */
    interrupt() { ctl?.abort(); },
    /** Forgets the conversation; settings and tools stay. */
    reset() { agent.reset(); },
    /** Puts back files the agent changed since message n (default: the last one) and drops the conversation from it. */
    rewind(n) { return agent.rewind(n); },
    checkpoints: () => agent.checkpoints(),
    async close() {
      if (closed) return;
      closed = true; ctl?.abort();
      mcp.close(); for (const c of own) { try { c.close(); } catch { /* gone */ } }
      diagnostics?.close(); killAllBackground();
    },
    /** The agent itself, for programs that need more than this API (unstable). */
    agent,
  };
  return session;
}

/** One task: yields the events of createSession().stream() and closes the session. */
export async function* query({ prompt, options = {} } = {}) {
  const s = await createSession(options);
  try { yield* s.stream(prompt, { signal: options.signal }); } finally { await s.close(); }
}

/** One task, the result: { text, usage, steps, toolCalls, denied, … }. */
export async function run(prompt, options = {}) {
  const s = await createSession(options);
  try { return await s.send(prompt, { signal: options.signal, throwOnError: options.throwOnError ?? true }); } finally { await s.close(); }
}
