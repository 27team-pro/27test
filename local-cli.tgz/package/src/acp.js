// `klinch acp`: the agent over the Agent Client Protocol (agentclientprotocol.com), so editors that speak it run it
// in their own agent panel: Zed, JetBrains IDEs (AI Assistant → agents, ~/.jetbrains/acp.json), Neovim plugins and
// others. JSON-RPC 2.0, one message per line on stdin / stdout; logs go to stderr.
//
// What the editor gets: the answer as it streams, each tool call with its kind and file (edits as a diff the editor
// shows before «Разрешить» / «Отклонить»), the agent's task list as the plan, modes (ask, edits without questions,
// plan, everything without questions), the model list, saved sessions (session/load) and cancel.
import { createInterface } from 'node:readline';
import { randomBytes } from 'node:crypto';
import { isAbsolute, resolve } from 'node:path';
import { createSession, VERSION } from './sdk.js';
import { loadConfig } from './config.js';
import { createClient } from './api.js';
import { proposedContent } from './tools.js';
import { decide, suggestRule } from './permissions.js';
import { saveSession, listSessions, withMentions } from './attach.js';

export const PROTOCOL_VERSION = 1;

export const MODES = [
  { id: 'default', name: 'Спрашивать', description: 'Правки и команды после вашего разрешения' },
  { id: 'acceptEdits', name: 'Правки без вопросов', description: 'Файлы меняются сразу, команды спрашивают' },
  { id: 'plan', name: 'План', description: 'Только читает код и предлагает план' },
  { id: 'bypassPermissions', name: 'Всё без вопросов', description: 'Правки и команды без подтверждения' },
];

const KIND = {
  read_file: 'read', list_files: 'search', glob: 'search', search: 'search', codebase_search: 'search', repo_map: 'search',
  edit_file: 'edit', write_file: 'edit', notebook_edit: 'edit', shell: 'execute', python: 'execute',
  web_fetch: 'fetch', web_search: 'fetch', task: 'think', todo_write: 'think',
};
export const toolKind = (name) => KIND[name] || 'other';

const firstLine = (s) => String(s || '').split('\n')[0].slice(0, 200);
const asText = (content) => (typeof content === 'string' ? content : (content || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n'));

/** ACP prompt content blocks → Anthropic content blocks. */
export function promptBlocks(prompt, cwd) {
  const out = [];
  for (const b of prompt || []) {
    if (b.type === 'text') {
      const { content } = withMentions(b.text, cwd);
      if (typeof content === 'string') out.push({ type: 'text', text: content }); else out.push(...content);
    } else if (b.type === 'image' && b.data) out.push({ type: 'image', source: { type: 'base64', media_type: b.mimeType || 'image/png', data: b.data } });
    else if (b.type === 'resource' && b.resource) {
      const r = b.resource;
      if (typeof r.text === 'string') out.push({ type: 'text', text: `<file uri="${r.uri}">\n${r.text}\n</file>` });
      else if (r.blob && /^image\//.test(r.mimeType || '')) out.push({ type: 'image', source: { type: 'base64', media_type: r.mimeType, data: r.blob } });
    } else if (b.type === 'resource_link' && b.uri) out.push({ type: 'text', text: `Файл: ${b.uri.replace(/^file:\/\//, '')}${b.name ? ` (${b.name})` : ''}` });
  }
  return out.length ? out : [{ type: 'text', text: '' }];
}

/** The ACP server. `input` / `output` are streams (stdin / stdout by default); `sessionOptions` go to createSession. */
export function startAcp({ input = process.stdin, output = process.stdout, env = process.env, log = (l) => process.stderr.write(l + '\n'), sessionOptions = {} } = {}) {
  const sessions = new Map();
  const waiting = new Map();
  let nextId = 1, clientCaps = {};
  const send = (msg) => output.write(JSON.stringify({ jsonrpc: '2.0', ...msg }) + '\n');
  const notify = (method, params) => send({ method, params });
  const request = (method, params) => new Promise((res, rej) => { const id = nextId++; waiting.set(id, { res, rej }); send({ id, method, params }); });
  const update = (sessionId, u) => notify('session/update', { sessionId, update: u });
  const rpcError = (code, message, data) => Object.assign(new Error(message), { code, data });

  const modeState = (m) => ({ currentModeId: m, availableModes: MODES });
  async function modelState(s) {
    try {
      const cfg = loadConfig(env);
      const list = await createClient({ baseUrl: cfg.baseUrl, apiKey: cfg.apiKey }).models();
      const ids = list.map((m) => m.id);
      if (!ids.includes(s.model)) ids.unshift(s.model);
      return { currentModelId: s.model, availableModels: ids.map((id) => ({ modelId: id, name: id })) };
    } catch { return { currentModelId: s.model, availableModels: [{ modelId: s.model, name: s.model }] }; }
  }

  async function open(sessionId, { cwd, mcpServers, messages }) {
    if (!cwd || !isAbsolute(cwd)) throw rpcError(-32602, 'cwd должен быть абсолютным путём');
    const st = { id: sessionId, cwd, calls: new Map(), always: new Set(), plan: '', s: null, turn: null };
    st.s = await createSession({
      ...sessionOptions, env, cwd, mcpServers, messages,
      permissionMode: sessionOptions.permissionMode || 'default',
      canUseTool: (q) => askPermission(st, q),
      onEvent: (e) => relay(st, e),
    }).catch((e) => { throw /ключ|key/i.test(e.message) ? rpcError(-32000, 'Authentication required', { reason: e.message }) : e; });
    for (const n of st.s.notes) log(n);
    sessions.set(sessionId, st);
    return st;
  }

  function relay(st, e) {
    const id = st.id;
    if (e.type === 'text') update(id, { sessionUpdate: 'agent_message_chunk', content: { type: 'text', text: e.text } });
    else if (e.type === 'note') update(id, { sessionUpdate: 'agent_thought_chunk', content: { type: 'text', text: `${e.text}\n` } });
    else if (e.type === 'plan') st.plan = e.plan;
    else if (e.type === 'todos') update(id, { sessionUpdate: 'plan', entries: e.todos.map((t) => ({ content: t.content, priority: 'medium', status: t.status === 'completed' ? 'completed' : t.status === 'in_progress' ? 'in_progress' : 'pending' })) });
    else if (e.type === 'tool_call') {
      if (e.name === 'todo_write') return;
      const c = callInfo(st, e);
      st.calls.set(e.id, c);
      update(id, { sessionUpdate: 'tool_call', toolCallId: e.id, title: c.title, kind: c.kind, status: 'pending', rawInput: e.input, ...(c.locations ? { locations: c.locations } : {}), ...(c.content ? { content: c.content } : {}) });
    } else if (e.type === 'tool_result') {
      if (e.name === 'todo_write') return;
      const c = st.calls.get(e.id);
      const text = asText(e.content);
      const content = c?.content && !e.is_error ? c.content : text ? [{ type: 'content', content: { type: 'text', text: text.length > 8000 ? text.slice(0, 8000) + '\n…' : text } }] : undefined;
      update(id, { sessionUpdate: 'tool_call_update', toolCallId: e.id, status: e.is_error ? 'failed' : 'completed', ...(content ? { content } : {}), rawOutput: { text: text.slice(0, 20000) } });
      st.calls.delete(e.id);
    }
  }

  /** Title, kind, files and (for edits) the diff of a tool call, worked out before it runs. */
  function callInfo(st, e) {
    const at = st.s.cwd, path = e.input?.path || e.input?.notebook_path;
    const abs = path ? (isAbsolute(path) ? path : resolve(at, path)) : null;
    const c = { title: firstLine(e.preview) || e.name, kind: toolKind(e.name), locations: abs ? [{ path: abs, ...(e.input?.line ? { line: e.input.line } : {}) }] : null, content: null };
    if (e.name === 'edit_file' || e.name === 'write_file') {
      try { const d = proposedContent(at, e.name, e.input); if (d) c.content = [{ type: 'diff', path: abs, oldText: d.created ? null : d.before, newText: d.after }]; } catch { /* a bad path: the tool reports it */ }
    }
    if (e.name === 'shell' && e.input?.command) c.title = firstLine(e.input.command);
    return c;
  }

  async function askPermission(st, q) {
    if (q.plan) {
      const r = await request('session/request_permission', {
        sessionId: st.id,
        toolCall: { toolCallId: q.id || `plan-${Date.now()}`, title: 'План готов. Выполнять?', kind: 'think', status: 'pending', content: [{ type: 'content', content: { type: 'text', text: st.plan || q.preview } }] },
        options: [{ optionId: 'allow', name: 'Выполнять', kind: 'allow_once' }, { optionId: 'reject', name: 'Доработать план', kind: 'reject_once' }],
      }).catch(() => null);
      return r?.outcome?.outcome === 'selected' && r.outcome.optionId === 'allow';
    }
    for (const rule of st.always) if (decide({ allow: [rule], deny: [] }, q.name, q.input, st.s.cwd) === 'allow') return true;
    const c = st.calls.get(q.id) || callInfo(st, { id: q.id, name: q.name, input: q.input, preview: q.preview });
    const rule = suggestRule(q.name, q.input);
    const r = await request('session/request_permission', {
      sessionId: st.id,
      toolCall: { toolCallId: q.id, title: c.title, kind: c.kind, status: 'pending', rawInput: q.input, ...(c.locations ? { locations: c.locations } : {}), ...(c.content ? { content: c.content } : { content: [{ type: 'content', content: { type: 'text', text: q.preview } }] }) },
      options: [
        { optionId: 'allow', name: 'Разрешить', kind: 'allow_once' },
        ...(rule ? [{ optionId: 'always', name: `Всегда в этом чате: ${rule}`, kind: 'allow_always' }] : []),
        { optionId: 'reject', name: 'Отклонить', kind: 'reject_once' },
      ],
    }).catch(() => null);
    const pick = r?.outcome?.outcome === 'selected' ? r.outcome.optionId : null;
    if (pick === 'always' && rule) st.always.add(rule);
    return pick === 'allow' || pick === 'always';
  }

  const need = (params) => {
    const st = sessions.get(params?.sessionId);
    if (!st) throw rpcError(-32602, `Нет сессии ${params?.sessionId}`);
    return st;
  };

  const methods = {
    async initialize(p) {
      clientCaps = p?.clientCapabilities || {};
      return {
        protocolVersion: PROTOCOL_VERSION,
        agentCapabilities: { loadSession: true, promptCapabilities: { image: true, audio: false, embeddedContext: true }, mcpCapabilities: { http: true, sse: false } },
        authMethods: [{ id: 'api-key', name: 'Ключ', description: 'Выполните в терминале: klinch login' }],
        agentInfo: { name: 'klinch-code', title: 'Klinch Code', version: VERSION },
      };
    },
    async authenticate() {
      if (!loadConfig(env).apiKey) throw rpcError(-32000, 'Authentication required', { reason: 'Ключ не задан: выполните в терминале klinch login' });
      return {};
    },
    async 'session/new'(p) {
      const sessionId = Date.now().toString(36) + randomBytes(3).toString('hex');
      const st = await open(sessionId, { cwd: p?.cwd, mcpServers: p?.mcpServers });
      return { sessionId, modes: modeState(st.s.permissionMode), models: await modelState(st.s) };
    },
    async 'session/load'(p) {
      const saved = listSessions(p?.cwd || '', env).find((x) => x.id === p?.sessionId);
      if (!saved) throw rpcError(-32602, `Сессии ${p?.sessionId} нет`);
      const st = await open(saved.id, { cwd: p.cwd, mcpServers: p?.mcpServers, messages: saved.messages });
      if (saved.model) st.s.model = saved.model;
      // The history, as the editor shows it: user and agent text (tool calls of past turns are not replayed).
      for (const m of saved.messages) {
        const text = asText(typeof m.content === 'string' ? m.content : m.content.filter((b) => b.type === 'text'));
        if (text.trim()) update(saved.id, { sessionUpdate: m.role === 'user' ? 'user_message_chunk' : 'agent_message_chunk', content: { type: 'text', text } });
      }
      return { modes: modeState(st.s.permissionMode), models: await modelState(st.s) };
    },
    async 'session/prompt'(p) {
      const st = need(p);
      if (st.turn) throw rpcError(-32600, 'Предыдущий запрос ещё выполняется');
      st.turn = true;
      try {
        let res = null;
        for await (const e of st.s.stream(promptBlocks(p.prompt, st.s.cwd))) if (e.type === 'result') res = e;
        try { saveSession({ id: st.id, cwd: st.cwd, model: st.s.model, messages: st.s.messages }, env); } catch (e) { log(`не сохранил сессию: ${e.message}`); }
        if (res.interrupted) return { stopReason: 'cancelled' };
        if (res.is_error) {
          if (/Слишком много шагов/.test(res.error)) return { stopReason: 'max_turn_requests' };
          throw rpcError(-32603, res.error);
        }
        return { stopReason: res.stop_reason === 'max_tokens' ? 'max_tokens' : res.stop_reason === 'refusal' ? 'refusal' : 'end_turn' };
      } finally { st.turn = null; }
    },
    async 'session/set_mode'(p) {
      const st = need(p);
      st.s.permissionMode = p.modeId;
      update(st.id, { sessionUpdate: 'current_mode_update', currentModeId: p.modeId });
      return {};
    },
    async 'session/set_model'(p) { need(p).s.model = String(p.modelId); return {}; },
  };
  const notifications = {
    'session/cancel': (p) => sessions.get(p?.sessionId)?.s.interrupt(),
  };

  const rl = createInterface({ input, crlfDelay: Infinity });
  rl.on('line', async (line) => {
    if (!line.trim()) return;
    let msg; try { msg = JSON.parse(line); } catch { return send({ id: null, error: { code: -32700, message: 'Parse error' } }); }
    if (msg.method === undefined && msg.id !== undefined) {   // an answer to our request
      const w = waiting.get(msg.id); waiting.delete(msg.id);
      if (w) (msg.error ? w.rej(Object.assign(new Error(msg.error.message), msg.error)) : w.res(msg.result));
      return;
    }
    if (msg.id === undefined) { try { await notifications[msg.method]?.(msg.params); } catch (e) { log(e.message); } return; }
    const fn = methods[msg.method];
    if (!fn) return send({ id: msg.id, error: { code: -32601, message: `Method not found: ${msg.method}` } });
    try { send({ id: msg.id, result: (await fn(msg.params)) ?? null }); }
    catch (e) { send({ id: msg.id, error: { code: e.code || -32603, message: e.message, ...(e.data ? { data: e.data } : {}) } }); }
  });
  const closed = new Promise((r) => rl.on('close', r));
  return {
    sessions,
    get clientCapabilities() { return clientCaps; },
    async close() { rl.close(); for (const st of sessions.values()) await st.s.close(); },
    closed: closed.then(async () => { for (const st of sessions.values()) await st.s.close(); }),
  };
}

/** `klinch acp`: serves stdin / stdout until the editor closes the pipe. Anything printed by mistake goes to stderr. */
export async function acpMain(env = process.env) {
  const write = process.stdout.write.bind(process.stdout);
  const output = { write: (s) => write(s) };
  console.log = console.info = (...a) => process.stderr.write(a.join(' ') + '\n');
  const server = startAcp({ output, env });
  await server.closed;
}
