// Settings live in ~/.klinch/config.json (mode 600). Environment variables override the file:
// KLINCH_API_KEY, KLINCH_BASE_URL, KLINCH_MODEL. KLINCH_HOME moves the directory (used by tests).
import { readFileSync, writeFileSync, mkdirSync, chmodSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';

export const DEFAULT_BASE_URL = 'https://klinch.cloud';
// «auto»: the gateway picks the model for each request (server/automodel.js); /model <name> pins one.
export const DEFAULT_MODEL = 'auto';

const dir = (env) => env.KLINCH_HOME || join(homedir(), '.klinch');
export const configPath = (env = process.env) => join(dir(env), 'config.json');

export function readConfigFile(env = process.env) {
  try { return JSON.parse(readFileSync(configPath(env), 'utf8')); } catch { return {}; }
}

const num = (k, v, lo, hi) => (Number.isFinite(+v) && +v > 0 ? { [k]: Math.min(Math.max(Math.round(+v), lo), hi) } : {});

export function loadConfig(env = process.env) {
  const file = readConfigFile(env);
  return {
    apiKey: env.KLINCH_API_KEY || file.apiKey || '',
    baseUrl: (env.KLINCH_BASE_URL || file.baseUrl || DEFAULT_BASE_URL).replace(/\/+$/, ''),
    model: env.KLINCH_MODEL || file.model || DEFAULT_MODEL,
    ...(typeof file.buddy === 'boolean' ? { buddy: file.buddy } : {}),
    ...(typeof file.repoMap === 'boolean' ? { repoMap: file.repoMap } : {}),
    ...(typeof file.codeIndex === 'boolean' ? { codeIndex: file.codeIndex } : {}),
    // Reasoning depth (low | medium | high | max; unset: the model's own), the sandbox, the status line, limits.
    effort: env.KLINCH_EFFORT || file.effort || null,
    sandbox: env.KLINCH_SANDBOX ? env.KLINCH_SANDBOX === '1' : file.sandbox ?? false,
    statusline: file.statusline !== false,
    ...(file.say === true ? { say: true } : {}),
    ...(file.wakeWord ? { wakeWord: String(file.wakeWord) } : {}),
    ...num('voiceThreshold', file.voiceThreshold, 50, 20000),
    // The agent saves and improves its own skills (src/selfskills.js); "selfSkills": false turns it off.
    // Skills and plugins turned on in the cabinet are installed at start (src/hub.js); "hubSync": false turns it off.
    ...(file.hubSync === false ? { hubSync: false } : {}),
    selfSkills: env.KLINCH_SELF_SKILLS ? env.KLINCH_SELF_SKILLS !== '0' : file.selfSkills !== false,
    ...(file.outputStyle ? { outputStyle: String(file.outputStyle) } : {}),
    // Several agents (src/multicli.js): the models /compare and /moa use without a list, the Agent Review model.
    ...(Array.isArray(file.compareModels) ? { compareModels: file.compareModels.map(String) } : {}),
    ...(Array.isArray(file.moaModels) ? { moaModels: file.moaModels.map(String) } : {}),
    ...(file.reviewModel ? { reviewModel: String(file.reviewModel) } : {}),
    // Local models (src/localmodels.js): an OpenAI-compatible server on this computer, default Ollama.
    ...((env.KLINCH_LOCAL_URL || file.localUrl) ? { localUrl: String(env.KLINCH_LOCAL_URL || file.localUrl) } : {}),
    ...((env.KLINCH_LOCAL_KEY || file.localKey) ? { localKey: String(env.KLINCH_LOCAL_KEY || file.localKey) } : {}),
    ...num('maxTokens', env.KLINCH_MAX_TOKENS || file.maxTokens, 1024, 128000),
    ...num('maxSteps', file.maxSteps, 10, 5000),
    ...num('compactAt', file.compactAt, 20000, 2000000),
  };
}

// Merges `patch` into the file; `undefined` values remove a setting.
export function saveConfig(patch, env = process.env) {
  const next = { ...readConfigFile(env), ...patch };
  for (const k of Object.keys(next)) if (next[k] === undefined) delete next[k];
  mkdirSync(dir(env), { recursive: true, mode: 0o700 });
  writeFileSync(configPath(env), JSON.stringify(next, null, 2) + '\n', { mode: 0o600 });
  try { chmodSync(configPath(env), 0o600); } catch { /* Windows */ }
  return next;
}

export const maskKey = (k) => (k ? k.slice(0, 8) + '…' + k.slice(-4) : '');
