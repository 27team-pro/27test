// The agent loop: send history, stream the reply, run requested tools (after confirmation for the
// dangerous ones), append results, repeat until the model stops asking for tools.
//
// On top of the file and shell tools the agent has: subagents (`task`, several run in parallel), a task list
// (`todo_write`), questions to the user (`ask_user`), skills (`skill`), the repository map (`repo_map`), plan mode
// (read-only until the user approves the plan from `exit_plan_mode`), MCP tools and context management:
//   - output up to 32K tokens per answer; an answer cut at the limit is continued, a cut tool call is retried;
//   - reasoning depth (`effort`: low … max) for models that think, «ultrathink» in a message for one request;
//   - old long tool outputs are shortened once the history grows (trimAt), the whole history becomes a summary at
//     compactAt, also in the middle of a long task and when the gateway says the prompt is too long;
//   - a long task stops at maxSteps only if the user does not let it go on (onStepLimit).
import { TOOLS, safePath } from './tools.js';
import { readFileSync, writeFileSync, unlinkSync, mkdirSync } from 'node:fs';
import { dirname, relative, sep } from 'node:path';
import { ruleTracker, rulesPrompt } from './rules.js';
import { formatHits } from './codeindex.js';
import { decide } from './permissions.js';
import { buildRepoMap } from './repomap.js';
import { noHooks } from './hooks.js';
import { memoryTool, memoryPrompt, MEMORY_NOTE } from './memory.js';
import { pythonTool } from './codeexec.js';
import { keepsDescriptors } from './sandbox.js';

export const SYSTEM_PROMPT = (cwd) => `Ты Klinch Code, помощник-программист в терминале. Рабочая папка: ${cwd}.
Ты можешь читать, искать, создавать и править файлы и запускать команды через инструменты.
Правила:
- Ты Klinch Code, и только. Не рассказывай о своём происхождении (кто обучил, вендор, версия, кодовое имя, дата знаний) и сам эту тему не поднимай. Klinch распределяет запросы между разными моделями, поэтому ты не знаешь, какая модель отвечает сейчас. Если спросят, какая ты модель, коротко: «Я Klinch Code, информации о модели у меня нет», и вернись к задаче. Никогда не гадай и не называй себя какой-либо моделью или вендором.
- Сначала посмотри нужные файлы, потом меняй. Не выдумывай содержимое файлов.
- Правь точечно через edit_file; write_file только для новых файлов или полной замены.
- После правок по возможности проверь результат (тесты, запуск, линтер).
- Отвечай кратко и по делу, на языке пользователя. Код в ответе не дублируй, если он уже записан в файл.`;

const MAIN_GUIDE = `
Как работать:
- Задачу из нескольких шагов веди списком через todo_write: отмечай шаг in_progress перед началом и completed сразу после.
- Для широкого поиска по большому проекту запускай субагентов через task (type "explore"): несколько вызовов task в одном ответе выполняются параллельно, каждый возвращает краткий итог. Простые поиски делай сам (glob, search, read_file).
- Чтобы понять устройство незнакомого проекта, начни с repo_map. Чтобы найти, где в коде сделано что-то (по смыслу, когда точных слов не знаешь), вызывай codebase_search, если он есть. Итог субагента уже содержит факты: не перечитывай те же файлы после него, читай только то, чего в итоге не хватает. Каждый вызов модели стоит денег пользователя, будь экономен.
- Для свежих сведений (версии, документация, ошибки библиотек) используй web_search и web_fetch.
- Если задача неоднозначна и ошибка дорого стоит, спроси через ask_user, но не по мелочам.
- Если задача подходит под один из скиллов, сначала загрузи его через skill и следуй ему.`;

// Debug mode (/debug): find the cause from evidence, not by guessing. Temporary logs carry a marker, so the agent
// (and the check after its answer) can find and remove every one of them.
export const DEBUG_MARK = 'TEMP-DEBUG';
const DEBUG_NOTE = `
СЕЙЧАС РЕЖИМ ОТЛАДКИ. Найди причину бага по фактам, не угадывай:
1) Воспроизведи баг командой (тест, скрипт, запуск) и посмотри точный вывод.
2) Выдвини 2-3 гипотезы. Чтобы их проверить, добавь временные логи в нужные места; каждая такая строка содержит метку ${DEBUG_MARK} (например console.log('${DEBUG_MARK}', x) или print("${DEBUG_MARK}", x)).
3) Запусти снова, прочитай логи, отбрось неверные гипотезы. Повторяй, пока причина не подтверждена выводом.
4) Исправь причину (не симптом), проверь, что воспроизведение больше не падает.
5) Удали все строки с ${DEBUG_MARK}, проверь поиском, что их не осталось. В ответе: причина, доказательство из вывода, что исправлено.`;
// With skill_manage: the agent keeps what it learned as skills (Hermes-style procedural memory).
const SELF_SKILLS = `
- Скиллы — твоя память о том, как делать задачи. Закончив непростую задачу (много шагов, нашёл неочевидный путь, исправил свою ошибку, пользователь поправил тебя), подумай, пригодится ли опыт снова. Если да — сохрани скилл через skill_manage (create) или улучши свой существующий (update): когда применять, шаги, точные команды, подводные камни. Одна задача — один скилл, коротко.
- Не сохраняй разовые мелочи, личные данные и секреты (ключи, пароли, токены). О проекте — scope "project", общий опыт — "user".
- Если твой скилл оказался неверным или устаревшим, поправь его сразу (update). Сохранив или обновив скилл, скажи об этом пользователю одной строкой.`;

const PLAN_NOTE = `
СЕЙЧАС РЕЖИМ ПЛАНА. Ничего не меняй: не пиши файлы и не запускай команды, только изучай код (read_file, search, glob, list_files, repo_map, task с type "explore", веб).
Когда разберёшься, вызови exit_plan_mode с планом: что и в каких файлах поменять, по шагам, и как проверить. Пользователь одобрит план или попросит поправить.`;

const SUB_NOTE = (type, role) => `
Ты субагент: тебе дали одну подзадачу. Выполни её сам, без вопросов пользователю, и закончи ответом-итогом: что нашёл или сделал, с путями файлов и номерами строк. Итог читает главный агент, а не человек, поэтому пиши плотно и по фактам.${type === 'explore' ? ' Ты только исследуешь: ничего не меняешь.' : ''}${role ? `\n\n# Твоя роль: ${role.name}\n${role.prompt}` : ''}`;

const COMPACT_PROMPT = `Сожми весь разговор выше в конспект, по которому можно продолжить работу без потерь. Включи:
1) исходную задачу пользователя и все его уточнения и требования;
2) что уже сделано: какие файлы прочитаны и изменены (пути), ключевые решения;
3) важные факты о коде (функции, пути, команды, ошибки и как их исправили);
4) что осталось сделать и текущий список задач.
Пиши плотно, без вступлений. Инструменты не вызывай.`;

// Shell commands inside the sandbox (src/sandbox.js): the agent should know what it can and cannot do there.
const SANDBOX_NOTE = (sb) => {
  const net = sb.network === true ? 'сеть открыта' : sb.network === false ? 'сети нет' : 'сеть только к реестрам пакетов и GitHub (npm, pip, cargo, go, git clone работают, остальные адреса закрыты)';
  const where = sb.kind === 'docker' ? `Команды shell выполняются в контейнере Docker (${sb.image || 'node:22'}), куда подключена только папка проекта; ${net}.`
    : sb.kind === 'ssh' ? `Команды shell выполняются на другом компьютере (${sb.host}) в копии проекта: перед командой проект туда отправляется, после неё изменения возвращаются. Пакеты (node_modules, .venv) ставятся там отдельно.`
    : sb.kind === 'lowil' ? `Команды shell выполняются в песочнице Windows: писать можно только в рабочую папку и временную; ${net}.`
    : `Команды shell выполняются в песочнице: писать можно только в рабочую папку и временную, секретные папки (~/.ssh и т. п.) не видны, ${net}.`;
  const more = sb.network === true || sb.kind === 'ssh' ? 'запись вне папки' : 'другая сеть (git push, curl к сайту) или запись вне папки';
  return `\n${where} Такие команды идут без подтверждения. Если команде нужна ${more}, вызови shell с unsandboxed: true: пользователь подтвердит.`;
};

export const EFFORTS = ['low', 'medium', 'high', 'max'];
/** «ultrathink» (or «подумай как следует») in a message: that one request thinks at the top depth. */
export const ULTRATHINK = /\bultrathink\b|подумай\s+(как\s+следует|хорошенько|глубже|очень\s+внимательно)/i;

const KEEP_RECENT = 6;        // messages at the end of the history that are never shortened
const TRIM_OVER = 1500;       // a tool output longer than this (characters) is shortened once it is old
const TRIM_HEAD = 500;

const todoMark = { completed: '✓', in_progress: '✱', pending: '○' };
export const formatTodos = (todos) => todos.map((t) => `${todoMark[t.status] || '○'} ${t.content}`).join('\n');

const textOf = (msg) => (msg?.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('').trim();

/** Adds user content, merging into a trailing user message so roles keep alternating. */
function pushUser(messages, content) {
  const last = messages.at(-1);
  if (last?.role === 'user') {
    const a = typeof last.content === 'string' ? [{ type: 'text', text: last.content }] : last.content;
    last.content = [...a, ...(typeof content === 'string' ? [{ type: 'text', text: content }] : content)];
  } else messages.push({ role: 'user', content });
}

export function createAgent({
  client, model, cwd, confirm, out, askUser,
  maxTokens = 32000, maxSteps = 400, effort = null, onStepLimit = null,
  extraTools = [], skills = [], instructions = '', repoMapInPrompt = false,
  mode = 'normal', subagent = null, compactAt = 140_000, trimAt = 60_000, hooks = noHooks,
  permissions = { allow: [], deny: [] }, beforeWrite = null, sandbox = null, outputStyle = null,
  agents = [], role = null, memory = false, env = process.env, diagnose = null, skillStore = null, rules = [], persona = '', codeIndex = null,
  // Programs that embed the agent (src/sdk.js, src/acp.js) follow each tool call: events.toolCall({ id, name, input,
  // preview }) before it runs (or is asked about), events.toolResult({ id, name, content, is_error }) after.
  events = null,
}) {
  const messages = [];
  // root: the project folder memory belongs to (a /worktree copy keeps the project's memory).
  const ctx = { cwd, sandbox, root: cwd, env };
  const state = { mode, todos: [], signal: null, repoMap: null, steps: 0, calls: [], denied: [], total: {}, effort: EFFORTS.includes(effort) ? effort : null, turnEffort: null, trimmedAt: -Infinity, style: outputStyle, persona };
  // Checkpoints: one per user message, with each file's content before the agent first touched it in that turn
  // (null = the file did not exist). /undo and /rewind put the files and the conversation back.
  const turns = [];
  const remember = beforeWrite || ((abs) => {
    const t = turns.at(-1);
    if (!t || t.files.has(abs)) return;
    let prev = null; try { prev = readFileSync(abs); } catch { /* new file */ }
    t.files.set(abs, prev);
  });
  // Path-scoped rules (src/rules.js): a rule for `src/**/*.ts` comes with the first such file the agent opens or changes.
  const ruleT = ruleTracker(rules);
  // Model «auto» (the gateway picks the model per request): an explore subagent asks for a quick one, the summary of
  // the history for an ordinary one; the main work is left to the gateway (an agent with tools gets a strong coder,
  // deep thinking the strongest).
  const autoHint = (kind) => (/^(?:klinch[-/])?auto$/i.test(String(model)) && kind ? { headers: { 'x-klinch-auto': kind } } : {});
  let lastUsage = null;
  const say = (k, ...a) => (out[k] ? out[k](...a) : out.tool(String(a[0]).split('\n')[0]));

  const agentTools = [
    {
      name: 'task',
      description: 'Запустить субагента для отдельной подзадачи. type "explore" (по умолчанию) только читает и ищет: годится для поиска по большому проекту, разбора модуля, сбора фактов; несколько explore-вызовов в одном ответе идут параллельно. type "general" может править файлы и запускать команды (с подтверждением пользователя). Субагент не видит этот разговор: опиши задачу полностью. Возвращает его итог.'
        + (agents.length ? `\nСпециальные субагенты пользователя (type = имя): ${agents.map((a) => `${a.name}: ${a.description}`).join('; ')}` : ''),
      input_schema: { type: 'object', properties: {
        description: { type: 'string', description: 'Коротко, 3-6 слов' },
        prompt: { type: 'string', description: 'Полная постановка подзадачи' },
        type: { type: 'string', enum: ['explore', 'general', ...agents.map((a) => a.name)] } }, required: ['description', 'prompt'] },
      parallel: (input) => { const t = input?.type || 'explore'; return t === 'explore' || !!agents.find((a) => a.name === t)?.readOnly; },
      preview: ({ description, type }) => `task [${type || 'explore'}] ${description}`,
      async run({ description, prompt, type = 'explore' }) {
        const custom = agents.find((a) => a.name === type) || null;
        const kind = custom ? (custom.readOnly ? 'explore' : 'general') : type === 'general' ? 'general' : 'explore';
        const sub = createAgent({ role: custom,
          client, model, cwd: ctx.cwd, confirm, askUser: null, extraTools, skills: [], instructions, hooks, permissions, beforeWrite: remember,
          maxTokens, rules, codeIndex, maxSteps: kind === 'general' ? 100 : 40, subagent: kind, sandbox: ctx.sandbox, effort: state.turnEffort || state.effort,
          out: { text() {}, endText() {}, toolStart() {}, tool: (p) => say('sub', description, p) },
        });
        const msg = await sub.ask(prompt, { signal: state.signal });
        return textOf(msg) || '(субагент закончил без итога)';
      },
    },
    {
      name: 'todo_write',
      description: 'Записать список задач целиком (заменяет прежний). Статусы: pending, in_progress, completed. Одновременно in_progress только одна.',
      input_schema: { type: 'object', properties: { todos: { type: 'array', items: { type: 'object', properties: {
        content: { type: 'string' }, status: { type: 'string', enum: ['pending', 'in_progress', 'completed'] } }, required: ['content', 'status'] } } }, required: ['todos'] },
      quiet: true,
      run({ todos }) {
        state.todos = (Array.isArray(todos) ? todos : []).slice(0, 50).map((t) => ({ content: String(t.content || '').slice(0, 200), status: t.status }));
        say('todos', formatTodos(state.todos));
        return 'Список задач обновлён';
      },
    },
    {
      name: 'ask_user',
      description: 'Задать пользователю вопрос и дождаться ответа. Можно дать варианты.',
      input_schema: { type: 'object', properties: { question: { type: 'string' }, options: { type: 'array', items: { type: 'string' } } }, required: ['question'] },
      quiet: true,
      async run({ question, options }) {
        if (!askUser) return 'Пользователь сейчас недоступен: реши сам разумным образом и коротко объясни выбор в ответе.';
        const a = await askUser(String(question), Array.isArray(options) ? options.map(String).slice(0, 8) : []);
        return a ? `Ответ пользователя: ${a}` : 'Пользователь не ответил: реши сам.';
      },
    },
    {
      name: 'repo_map',
      description: 'Карта проекта: главные файлы и что в них определено (функции, классы, типы с номерами строк), по важности. focus сужает к путям, содержащим эту строку.',
      input_schema: { type: 'object', properties: { focus: { type: 'string' }, budget: { type: 'integer', description: 'Размер в токенах, по умолчанию 2048' } } },
      run({ focus, budget }) { return buildRepoMap(ctx.cwd, { focus, budget: Math.min(Math.max(+budget || 2048, 256), 8192) }).text; },
    },
    ...(codeIndex ? [{
      name: 'codebase_search',
      description: 'Поиск по коду проекта по смыслу и по словам: «где проверяется ключ», «retry при 429», «как считается цена». Возвращает подходящие фрагменты (файл:строки и начало кода). Для точного текста или регулярки лучше search.',
      input_schema: { type: 'object', properties: {
        query: { type: 'string', description: 'Что ищем, своими словами или именами из кода' },
        path: { type: 'string', description: 'Искать только в этой папке' },
        limit: { type: 'integer', description: 'Сколько фрагментов, по умолчанию 8' } }, required: ['query'] },
      preview: ({ query, path }) => `codebase_search «${query}»${path ? ` в ${path}` : ''}`,
      async run({ query, path, limit }) {
        if (!String(query || '').trim()) throw new Error('Пустой запрос');
        const hits = await codeIndex.search(String(query || ''), { limit: Math.min(Math.max(+limit || 8, 1), 20), under: path || '', signal: state.signal });
        return formatHits(hits, codeIndex.note);
      },
    }] : []),
    ...(memory ? [memoryTool] : []),
    ...(diagnose ? [{
      name: 'diagnostics',
      description: 'Ошибки и предупреждения языкового сервера (LSP) или проверки синтаксиса для файла. После write_file и edit_file они приходят сами.',
      input_schema: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] },
      preview: ({ path }) => `diagnostics ${path}`,
      async run({ path }) { const lines = await diagnose(safePath(ctx.cwd, path)); return lines.length ? lines.join('\n') : 'Проблем не найдено'; },
    }] : []),
    ...(skills.length || skillStore ? [{
      name: 'skill',
      description: 'Загрузить скилл (инструкцию для типа задач) по имени из списка в системном сообщении.',
      input_schema: { type: 'object', properties: { name: { type: 'string' } }, required: ['name'] },
      preview: ({ name }) => `skill ${name}`,
      run({ name }) {
        const s = skills.find((x) => x.name === String(name).toLowerCase());
        if (!s) throw new Error(`Скилла ${name} нет. Есть: ${skills.map((x) => x.name).join(', ') || 'пока ничего'}`);
        skillStore?.used(s.name);
        return `Скилл «${s.name}» (папка ${s.dir}; файлы из неё читай через shell, если нужно):\n\n${s.body}`;
      },
    }] : []),
    // The agent's own skills (src/selfskills.js): its procedural memory, kept between sessions.
    ...(skillStore ? [{
      name: 'skill_manage',
      description: 'Свои скиллы (память о том, как делать задачи): create — сохранить новый, update — улучшить свой, delete — убрать в архив, list — список своих. '
        + 'Скилл: name (коротко, через дефис), description (одна строка: когда применять), body (Markdown: когда применять, шаги, команды проверки, подводные камни). '
        + 'scope "user" (по умолчанию) — для всех проектов, "project" — только для этого (папка .klinch/skills). Скиллы пользователя менять нельзя.',
      input_schema: { type: 'object', properties: {
        action: { type: 'string', enum: ['create', 'update', 'delete', 'list'] },
        name: { type: 'string' }, description: { type: 'string' }, body: { type: 'string' },
        scope: { type: 'string', enum: ['user', 'project'] } }, required: ['action'] },
      preview: ({ action, name }) => `skill_manage ${action}${name ? ' ' + name : ''}`,
      run(input) {
        const r = skillStore.manage(input, ctx.cwd);
        if (input.action !== 'list') {
          skills.splice(0, skills.length, ...skillStore.reload(ctx.cwd));
          say('note', r.split(' (')[0]);
        }
        return r;
      },
    }] : []),
    {
      name: 'exit_plan_mode',
      description: 'Показать пользователю готовый план и попросить разрешения начать. Только в режиме плана.',
      input_schema: { type: 'object', properties: { plan: { type: 'string', description: 'План в Markdown' } }, required: ['plan'] },
      quiet: true,
      async run({ plan }) {
        say('plan', String(plan));
        const ok = await confirm(`План готов. Выполнять?`, { plan: true });
        if (!ok) return 'Пользователь не одобрил план. Режим плана остаётся: спроси, что поменять, или доработай план.';
        state.mode = 'normal';
        say('note', 'Режим плана выключен, выполняю.');
        return 'Пользователь одобрил план. Режим плана выключен: выполняй план по шагам, веди todo_write.';
      },
    },
  ];

  const all = () => [...TOOLS, pythonTool, ...agentTools, ...extraTools];
  // A python script's calls to the agent's tools go through runTool, with every check a model's call gets.
  let pyCalls = 0;
  ctx.callTool = (name, input) => runTool({ id: `py${++pyCalls}`, name, input });
  /** Tools offered right now: plan mode and explore subagents get only the read-only ones. */
  function available() {
    const readOnly = state.mode === 'plan' || subagent === 'explore';
    return all().filter((t) => {
      if (t.name === 'exit_plan_mode') return state.mode === 'plan' && !subagent;
      if (subagent && ['task', 'todo_write', 'ask_user'].includes(t.name)) return false;
      if (t.name === 'ask_user' && !askUser) return false;
      if (t.when && !t.when()) return false;
      if (readOnly && (t.danger || t.name === 'skill_manage')) return false;
      return true;
    });
  }
  const defs = () => available().map(({ name, description, input_schema }) => ({ name, description, input_schema }));

  function system() {
    let s = SYSTEM_PROMPT(ctx.cwd) + (subagent ? SUB_NOTE(subagent, role) : MAIN_GUIDE + (skillStore ? SELF_SKILLS : ''));
    if (skills.length && !subagent) s += `\n\nСкиллы (загружай через skill):\n${skills.map((x) => `- ${x.name}: ${x.description}`).join('\n')}`;
    if (instructions) s += `\n\n${instructions}`;
    if (memory && !subagent) { const m = memoryPrompt(ctx.root, env); s += MEMORY_NOTE + (m ? `\n\n${m}` : ''); }
    if (rules.length) s += `\n\n${rulesPrompt(rules, ctx.cwd)}`;
    if (state.persona) s += `\n\n${state.persona}`;   // SOUL.md and the active bot (src/bots.js)
    if (repoMapInPrompt && !subagent) {
      state.repoMap ??= buildRepoMap(ctx.cwd).text;
      s += `\n\n# Карта проекта (главные файлы и определения)\n${state.repoMap}`;
    }
    if (ctx.sandbox?.active) s += '\n' + SANDBOX_NOTE(ctx.sandbox);
    if (state.style?.prompt && !subagent) s += `\n\n# Стиль ответов: ${state.style.name}\n${state.style.prompt}`;
    if (state.mode === 'plan' && !subagent) s += '\n' + PLAN_NOTE;
    if (state.mode === 'debug') s += '\n' + DEBUG_NOTE;
    return s;
  }

  /** The request for the next answer; `effort` only when one is chosen (the gateway drops it for models without it). */
  const request = (over = {}) => {
    const e = state.turnEffort || state.effort;
    return { model, max_tokens: maxTokens, system: system(), tools: defs(), messages, ...(e ? { output_config: { effort: e } } : {}), ...over };
  };

  async function runTool(block) {
    const tool = available().find((t) => t.name === block.name);
    if (!tool) {
      const exists = all().some((t) => t.name === block.name);
      return { content: exists ? `Инструмент ${block.name} сейчас недоступен (${state.mode === 'plan' ? 'режим плана: только чтение' : 'только чтение'})` : `Неизвестный инструмент ${block.name}`, is_error: true };
    }
    if (block.badInput) return { content: 'Некорректные аргументы инструмента (JSON не разобран)', is_error: true };
    let preview;
    try { preview = tool.preview ? tool.preview(block.input || {}, ctx) : `${block.name} ${JSON.stringify(block.input)}`; }
    catch { preview = `${block.name} ${JSON.stringify(block.input)}`; }
    if (events?.toolCall) { try { events.toolCall({ id: block.id, name: block.name, input: block.input || {}, preview }); } catch { /* the program's own error */ } }
    const res = await runChecked(block, tool, preview);
    if (events?.toolResult) { try { events.toolResult({ id: block.id, name: block.name, content: res.content, is_error: !!res.is_error }); } catch { /* the program's own error */ } }
    return res;
  }

  async function runChecked(block, tool, preview) {
    const pre = await hooks.run('PreToolUse', { tool_name: block.name, tool_input: block.input || {} });
    if (pre.block) { say('note', `хук запретил ${block.name}: ${pre.reason.split('\n')[0]}`); return { content: `Хук пользователя запретил этот вызов: ${pre.reason}`, is_error: true }; }
    const rule = decide(permissions, block.name, block.input || {}, ctx.cwd);
    if (rule === 'deny') { say('note', `правило запрещает: ${preview.split('\n')[0]}`); return { content: 'Это действие запрещено правилами пользователя (permissions.deny). Сделай по-другому или спроси пользователя.', is_error: true }; }
    // A command in the sandbox cannot change anything outside the project, so it needs no question.
    const boxed = (block.name === 'shell' || (block.name === 'python' && keepsDescriptors(ctx.sandbox))) && ctx.sandbox?.active && !block.input?.unsandboxed;
    // `danger` may depend on the call (browser: only actions on sites off this computer ask).
    const danger = typeof tool.danger === 'function' ? tool.danger(block.input || {}, ctx) : tool.danger;
    if (boxed && pre.decision !== 'ask') out.tool(preview + '   [песочница]');
    else if ((danger && pre.decision !== 'allow' && rule !== 'allow') || (!danger && pre.decision === 'ask')) {
      const ok = await confirm(preview, { tool: block.name, input: block.input || {}, id: block.id });
      if (!ok) { state.denied.push(preview.split('\n')[0]); return { content: 'Пользователь отклонил это действие. Спроси, что делать дальше.', is_error: true }; }
    } else if (!tool.quiet) out.tool(preview);
    state.calls.push(preview.split('\n')[0]);
    if (['write_file', 'edit_file', 'notebook_edit'].includes(block.name) && block.input?.path) { try { remember(safePath(ctx.cwd, block.input.path, { write: true })); } catch { /* run() reports the bad path */ } }
    let res;
    try {
      const r = await tool.run(block.input || {}, ctx);
      res = { content: Array.isArray(r) ? r : String(r ?? '') };
    } catch (e) { res = { content: `Ошибка: ${e.message}`, is_error: true }; }
    // The language server's view of the file just written: errors go back with the result.
    if (diagnose && !res.is_error && (block.name === 'write_file' || block.name === 'edit_file')) {
      try {
        const lines = await diagnose(safePath(ctx.cwd, block.input.path));
        if (lines.length) { res.content += `\n\nДиагностика после правки (исправь, если это следствие правки):\n${lines.join('\n')}`; say('note', `диагностика: ${lines.length} ${lines.length === 1 ? 'проблема' : 'проблем'} в ${block.input.path}`); }
      } catch { /* no diagnostics this time */ }
    }
    if (ruleT.count && !res.is_error && ['read_file', 'write_file', 'edit_file', 'notebook_edit'].includes(block.name) && block.input?.path) {
      let extra = '';
      try { extra = ruleT.attach(relative(ctx.cwd, safePath(ctx.cwd, block.input.path)).split(sep).join('/')); } catch { /* a bad path: nothing to attach */ }
      if (extra) {
        say('note', `правило проекта: ${extra.split('\n')[0].replace(/^# /, '')}`);
        res.content = typeof res.content === 'string' ? `${res.content}\n\n${extra}` : [...res.content, { type: 'text', text: extra }];
      }
    }
    if (hooks.count) {
      const asText = typeof res.content === 'string' ? res.content : res.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n');
      const post = await hooks.run('PostToolUse', { tool_name: block.name, tool_input: block.input || {}, tool_response: asText.slice(0, 20000), is_error: !!res.is_error });
      const extra = [post.block && `Хук пользователя после ${block.name}: ${post.reason}`, post.context].filter(Boolean).join('\n');
      if (extra) res.content = typeof res.content === 'string' ? `${res.content}\n\n${extra}` : [...res.content, { type: 'text', text: extra }];
    }
    return res;
  }

  /** Read-only calls (and explore subagents) run together; anything that may ask the user runs one by one. */
  const canParallel = (b) => {
    const t = available().find((x) => x.name === b.name);
    return t && !t.danger && !t.quiet && (!t.parallel || t.parallel(b.input));
  };

  /**
   * Shortens long tool outputs outside the last few messages (they were read and acted upon; the agent can read the
   * file again). Done in one go and then not again for a while, so the prompt cache is rebuilt rarely.
   * Returns the number of characters saved.
   */
  function trimOld({ keep = KEEP_RECENT, force = false } = {}) {
    if (!force && messages.length - state.trimmedAt < 20) return 0;
    let saved = 0;
    for (let i = 0; i < messages.length - keep; i++) {
      const m = messages[i];
      if (m.role !== 'user' || !Array.isArray(m.content)) continue;
      for (const b of m.content) {
        if (b.type !== 'tool_result') continue;
        const text = typeof b.content === 'string' ? b.content : Array.isArray(b.content) ? b.content.map((x) => (x.type === 'text' ? x.text : x.type === 'image' ? '[картинка]' : '')).join('\n') : '';
        if (text.length <= TRIM_OVER && typeof b.content === 'string') continue;
        if (text.length <= TRIM_OVER) { b.content = text; continue; }
        b.content = `${text.slice(0, TRIM_HEAD)}\n… (старый вывод сокращён: было ${text.length} символов; если нужно, получи его заново)`;
        saved += text.length - b.content.length;
      }
    }
    if (saved) state.trimmedAt = messages.length;
    return saved;
  }

  async function compact(signal) {
    if (messages.length < 2) return false;
    trimOld({ keep: 2, force: true });   // the summary request itself must fit
    const req = messages.map((m) => ({ ...m }));
    pushUser(req, COMPACT_PROMPT);
    const msg = await client.stream({ model, max_tokens: 8192, system: SYSTEM_PROMPT(ctx.cwd), tools: defs(), messages: req }, { signal, ...autoHint('general') });
    const summary = textOf(msg);
    if (!summary) throw new Error('Не удалось сжать историю');
    messages.length = 0;
    ruleT.reset();   // the summary does not keep the rules' text: they come again with the next matching file
    messages.push(
      { role: 'user', content: `Это продолжение длинного разговора. Конспект предыдущей части:\n\n${summary}${state.todos.length ? `\n\nСписок задач:\n${formatTodos(state.todos)}` : ''}` },
      { role: 'assistant', content: [{ type: 'text', text: 'Понял, продолжаю с этого места.' }] },
    );
    lastUsage = null;
    for (const t of turns) { t.index = messages.length; t.prevLast = messages.at(-1).content; } // files can still be restored
    return true;
  }

  /**
   * Keeps the history within budget before a model call: past trimAt old tool outputs are shortened, past compactAt
   * the history becomes a summary. `midTask`: called between steps of one request (the last message is then the
   * tool results, and after a summary the agent is told to go on).
   */
  async function fitContext(signal, midTask = false) {
    const used = inputTokens(lastUsage);
    if (compactAt && used > compactAt) {
      say('note', `История длинная (${Math.round(used / 1000)}K токенов), сжимаю в конспект…`);
      try {
        await compact(signal);
        if (midTask) pushUser(messages, 'Продолжай задачу с того места, где остановился: конспект выше.');
      } catch (e) { say('note', `Сжать не удалось: ${e.message}`); }
    } else if (trimAt && used > trimAt) {
      const saved = trimOld();
      if (saved) say('note', `старые выводы инструментов сокращены (−${Math.round(saved / 4000)}K токенов)`);
    }
  }

  const inputTokens = (u) => (u ? (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0) : 0);

  return {
    messages,
    get model() { return model; },
    set model(m) { model = m; },
    get cwd() { return ctx.cwd; },
    set cwd(d) { ctx.cwd = d; state.repoMap = null; },
    get mode() { return state.mode; },
    set mode(m) { state.mode = m; },
    get effort() { return state.effort; },
    set effort(e) { state.effort = EFFORTS.includes(e) ? e : null; },
    get sandbox() { return ctx.sandbox; },
    set sandbox(s) { ctx.sandbox = s; },
    get outputStyle() { return state.style; },
    set outputStyle(s) { state.style = s; },
    get persona() { return state.persona; },
    set persona(p) { state.persona = p || ''; },
    get compactAt() { return compactAt; },
    trimOld,
    get todos() { return state.todos; },
    get lastUsage() { return lastUsage; },
    get contextTokens() { return inputTokens(lastUsage) + (lastUsage?.output_tokens || 0); },
    tools: () => available(),
    system,
    compact,

    /** `content` is a string or Anthropic content blocks (text, images). */
    async ask(content, { signal } = {}) {
      state.signal = signal;
      await fitContext(signal);
      if (!subagent && hooks.count) {
        const text = typeof content === 'string' ? content : content.filter((b) => b.type === 'text').map((b) => b.text).join('\n');
        const h = await hooks.run('UserPromptSubmit', { prompt: text });
        if (h.block) throw Object.assign(new Error(`Хук не пропустил сообщение: ${h.reason}`), { blocked: true });
        if (h.context) content = [...(typeof content === 'string' ? [{ type: 'text', text: content }] : content), { type: 'text', text: `<hook-context>\n${h.context}\n</hook-context>` }];
      }
      const before = messages.length, prevLast = messages.at(-1)?.content;
      if (!subagent) turns.push({ index: before, prevLast, prompt: typeof content === 'string' ? content : content.filter((b) => b.type === 'text').map((b) => b.text).pop() || '', files: new Map() });
      pushUser(messages, content);
      let stops = 0, cuts = 0, tooLong = false, limit = maxSteps;
      state.steps = 0; state.calls = []; state.denied = []; state.total = {};
      state.turnEffort = ULTRATHINK.test(typeof content === 'string' ? content : content.filter((b) => b.type === 'text').map((b) => b.text).join('\n')) ? 'max' : null;
      if (state.turnEffort && !subagent) say('note', 'ultrathink: этот запрос думает на максимуме');
      for (let step = 0; ; step++) {
        if (step >= limit) {
          if (onStepLimit && !subagent && await onStepLimit(step)) { limit += maxSteps; } else throw new Error(`Слишком много шагов подряд (${step}), остановлено`);
        }
        state.steps = step + 1;
        if (step) await fitContext(signal, true);
        let msg;
        try {
          msg = await client.stream(request(), {
            onText: out.text, onToolStart: (b) => out.toolStart(b.name), onThinking: () => out.thinking?.(), signal,
            onRetry: (n, ms) => say('note', `шлюз занят, повтор ${n} через ${Math.round(ms / 1000)} с`),
            ...autoHint(subagent === 'explore' ? 'fast' : null),
          });
        } catch (e) {
          // The history outgrew the model's window: shorten and summarise it, then ask once more.
          if (e.tooLong && !tooLong && messages.length > 2) {
            tooLong = true; say('note', 'История не помещается в контекст модели, сжимаю…');
            await compact(signal);
            if (messages.at(-1).role === 'assistant') pushUser(messages, 'Продолжай задачу с того места, где остановился.');
            step--; continue;
          }
          throw e;
        }
        out.endText();
        lastUsage = msg.usage;
        for (const [k, v] of Object.entries(msg.usage || {})) if (typeof v === 'number') state.total[k] = (state.total[k] || 0) + v;
        if (msg.stop_reason === 'interrupted') {
          if (step === 0) { messages.length = before; if (before) messages[before - 1].content = prevLast; if (!subagent && !turns.at(-1)?.files.size) turns.pop(); }
          throw Object.assign(new Error('Ответ прерван'), { interrupted: true });
        }
        // Cut at the output limit. A cut tool call has broken arguments: drop it and ask for smaller pieces. A cut text
        // is continued from where it stopped (up to 3 times).
        if (msg.stop_reason === 'max_tokens' && cuts < 3) {
          cuts++;
          const cutTool = msg.content.at(-1)?.type === 'tool_use';
          const kept = cutTool ? msg.content.slice(0, -1) : msg.content;
          messages.push({ role: 'assistant', content: kept.length ? kept : [{ type: 'text', text: '…' }] });
          say('note', cutTool ? 'вызов инструмента оборвался на лимите ответа, прошу разбить на части' : 'ответ упёрся в лимит длины, продолжаю');
          pushUser(messages, cutTool
            ? 'Твой ответ оборвался на лимите длины посреди вызова инструмента, вызов не выполнен. Сделай то же меньшими частями: большой файл пиши по кускам (write_file с началом, затем edit_file), правки дели на несколько edit_file.'
            : 'Твой ответ оборвался на лимите длины. Продолжи ровно с места обрыва, без повторов и вступлений.');
          continue;
        }
        messages.push({ role: 'assistant', content: msg.content.length ? msg.content : [{ type: 'text', text: '' }] });
        const calls = msg.content.filter((b) => b.type === 'tool_use');
        if (!calls.length || msg.stop_reason !== 'tool_use') {
          // Debug mode ends only when no temporary log is left in the project.
          if (state.mode === 'debug' && !subagent && stops < 3) {
            let left = '';
            try { left = await TOOLS.find((t) => t.name === 'search').run({ pattern: DEBUG_MARK }, ctx); } catch { /* nothing to search */ }
            if (left && left !== 'Ничего не найдено') { stops++; say('note', 'в коде остались временные логи отладки, прошу убрать'); pushUser(messages, `В проекте остались временные строки с ${DEBUG_MARK}, удали их:\n${left.split('\n').slice(0, 30).join('\n')}`); continue; }
          }
          if (!subagent && hooks.count && stops < 3) {
            const h = await hooks.run('Stop', { last_assistant_message: textOf(msg), stop_hook_active: stops > 0 });
            if (h.block) { stops++; say('note', `хук просит продолжить: ${h.reason.split('\n')[0]}`); pushUser(messages, `Хук пользователя не дал закончить: ${h.reason}`); continue; }
          }
          return msg;
        }
        const results = new Array(calls.length);
        const batch = [];
        const flush = async () => {
          const rs = await Promise.all(batch.map(({ c }) => runTool(c)));
          batch.forEach(({ i }, k) => { results[i] = rs[k]; });
          batch.length = 0;
        };
        for (let i = 0; i < calls.length; i++) {
          if (canParallel(calls[i])) { batch.push({ c: calls[i], i }); continue; }
          await flush();
          results[i] = await runTool(calls[i]);
        }
        await flush();
        messages.push({ role: 'user', content: calls.map((c, i) => ({ type: 'tool_result', tool_use_id: c.id, content: results[i].content, ...(results[i].is_error ? { is_error: true } : {}) })) });
        if (signal?.aborted) throw Object.assign(new Error('Ответ прерван'), { interrupted: true });
      }
    },
    reset() { ruleT.reset(); messages.length = 0; state.todos = []; lastUsage = null; turns.length = 0; },
    get steps() { return state.steps; },
    get calls() { return state.calls; },
    get denied() { return state.denied; },
    /** Usage summed over every model call of the last request (lastUsage is only the final call). */
    get totalUsage() { return state.total; },
    /** Checkpoints, oldest first: [{ n, prompt, files: [paths] }]. */
    checkpoints: () => turns.map((t, i) => ({ n: i + 1, prompt: t.prompt, files: [...t.files.keys()] })),
    /**
     * Puts files back as they were before message `n` (1-based; default: the last one) and drops the conversation
     * from that message on. Returns the restored paths. Changes made by shell commands are not tracked.
     */
    rewind(n = turns.length) {
      if (!turns.length || n < 1 || n > turns.length) throw new Error('Откатывать нечего');
      const restored = [];
      for (let i = turns.length - 1; i >= n - 1; i--) {
        for (const [abs, prev] of turns[i].files) {
          try {
            if (prev === null) unlinkSync(abs);
            else { mkdirSync(dirname(abs), { recursive: true }); writeFileSync(abs, prev); }
            if (!restored.includes(abs)) restored.push(abs);
          } catch (e) { if (prev !== null || e.code !== 'ENOENT') throw e; }
        }
      }
      const t = turns[n - 1];
      messages.length = t.index;
      if (t.index) messages[t.index - 1].content = t.prevLast;
      turns.length = n - 1;
      lastUsage = null;
      return restored;
    },
  };
}
