// Text out of documents for read_file: PDF, Word (.docx), Excel (.xlsx), PowerPoint (.pptx) and OpenDocument
// (.odt, .ods, .odp). No dependencies: Office files are zip archives of XML, read with zlib; PDF text comes from
// pdftotext (poppler) when it is installed, otherwise from the page streams directly (enough for most PDFs made
// from text; scans have no text at all).
import { readFileSync } from 'node:fs';
import { inflateRawSync, inflateSync } from 'node:zlib';
import { execFileSync } from 'node:child_process';
import { extname } from 'node:path';

export const DOC_EXT = /\.(pdf|docx|xlsx|pptx|odt|ods|odp)$/i;

/** Files of a zip archive: Map name → () => Buffer (stored and deflated entries). */
export function unzip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('Это не zip-архив (файл повреждён?)');
  const n = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  const files = new Map();
  for (let k = 0; k < n; k++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) break;
    const method = buf.readUInt16LE(p + 10), size = buf.readUInt32LE(p + 20);
    const nameLen = buf.readUInt16LE(p + 28), extra = buf.readUInt16LE(p + 30), comment = buf.readUInt16LE(p + 32), at = buf.readUInt32LE(p + 42);
    const name = buf.subarray(p + 46, p + 46 + nameLen).toString('utf8');
    files.set(name, () => {
      const start = at + 30 + buf.readUInt16LE(at + 26) + buf.readUInt16LE(at + 28), data = buf.subarray(start, start + size);
      return method === 8 ? inflateRawSync(data) : data;
    });
    p += 46 + nameLen + extra + comment;
  }
  return files;
}

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
const decode = (s) => s.replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, e) => (e[0] === '#' ? String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : +e.slice(1)) : ENT[e] ?? m));
const strip = (xml) => decode(xml.replace(/<[^>]+>/g, ''));
const tidy = (s) => s.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();

function docx(files) {
  const xml = files.get('word/document.xml')?.().toString('utf8') || '';
  return tidy(strip(xml.replace(/<w:tab\/>/g, '\t').replace(/<w:br\/>/g, '\n').replace(/<\/w:tc>/g, ' | ').replace(/<\/w:tr>/g, '\n').replace(/<\/w:p>/g, '\n')));
}

const colIndex = (ref) => { let n = 0; for (const ch of /^[A-Z]+/.exec(ref)?.[0] || 'A') n = n * 26 + ch.charCodeAt(0) - 64; return n - 1; };
function xlsx(files, { maxRows = 500 } = {}) {
  const text = (n) => files.get(n)?.().toString('utf8') || '';
  const shared = [...text('xl/sharedStrings.xml').matchAll(/<si>([\s\S]*?)<\/si>/g)].map((m) => strip(m[1].replace(/<rPh[\s\S]*?<\/rPh>/g, '')));
  const rels = Object.fromEntries([...text('xl/_rels/workbook.xml.rels').matchAll(/<Relationship\b[^>]*>/g)].map((m) => [/Id="([^"]+)"/.exec(m[0])?.[1], /Target="([^"]+)"/.exec(m[0])?.[1]]));
  const sheets = [...text('xl/workbook.xml').matchAll(/<sheet\b[^>]*>/g)].map((m) => ({ name: decode(/name="([^"]*)"/.exec(m[0])?.[1] || ''), target: rels[/r:id="([^"]+)"/.exec(m[0])?.[1]] }));
  const out = [];
  for (const s of sheets) {
    const path = s.target ? (s.target.startsWith('/') ? s.target.slice(1) : 'xl/' + s.target.replace(/^\.\//, '')) : null;
    const xml = path ? text(path) : '';
    const rows = [...xml.matchAll(/<row\b[^>]*>([\s\S]*?)<\/row>/g)];
    out.push(`## Лист «${s.name}»${rows.length > maxRows ? ` (первые ${maxRows} строк из ${rows.length})` : ''}`);
    for (const r of rows.slice(0, maxRows)) {
      const cells = [];
      for (const c of r[1].matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
        const attrs = c[1], body = c[2] || '', t = /t="(\w+)"/.exec(attrs)?.[1], ref = /r="([A-Z]+)\d+"/.exec(attrs)?.[1];
        const v = /<v>([\s\S]*?)<\/v>/.exec(body)?.[1];
        const val = t === 's' ? shared[+v] ?? '' : t === 'inlineStr' ? strip(/<is>([\s\S]*?)<\/is>/.exec(body)?.[1] || '') : v != null ? decode(v) : '';
        cells[ref ? colIndex(ref) : cells.length] = val;
      }
      out.push(Array.from(cells, (x) => x ?? '').join('\t'));
    }
  }
  return tidy(out.join('\n'));
}

function pptx(files) {
  const slides = [...files.keys()].filter((n) => /^ppt\/slides\/slide\d+\.xml$/.test(n)).sort((a, b) => +/(\d+)\.xml/.exec(a)[1] - +/(\d+)\.xml/.exec(b)[1]);
  return tidy(slides.map((n, i) => {
    const xml = files.get(n)().toString('utf8');
    const notes = files.get(n.replace('slides/slide', 'notesSlides/notesSlide'))?.().toString('utf8');
    const t = (x) => tidy(strip(x.replace(/<\/a:p>/g, '\n').replace(/<a:br\/>/g, '\n')));
    return `## Слайд ${i + 1}\n${t(xml)}${notes ? `\n(заметки: ${t(notes).replace(/\n+/g, ' ').replace(/^\d+$/, '')})` : ''}`;
  }).join('\n\n'));
}

function odf(files) {
  const xml = files.get('content.xml')?.().toString('utf8') || '';
  return tidy(strip(xml.replace(/<text:tab\/>/g, '\t').replace(/<text:line-break\/>/g, '\n').replace(/<\/table:table-cell>/g, '\t').replace(/<\/table:table-row>/g, '\n').replace(/<\/text:(p|h)>/g, '\n')));
}

/* ---------------- PDF ---------------- */

/** Bytes of a PDF literal string «(…)» starting after the «(», and where it ends. */
function pdfString(s, i) {
  let out = '', depth = 1;
  for (; i < s.length; i++) {
    const ch = s[i];
    if (ch === '\\') {
      const n = s[++i];
      if (/[0-7]/.test(n)) { let o = n; while (o.length < 3 && /[0-7]/.test(s[i + 1])) o += s[++i]; out += String.fromCharCode(parseInt(o, 8)); }
      else out += { n: '\n', r: '\r', t: '\t', b: '\b', f: '\f', '\n': '', '\r': '' }[n] ?? n;
    } else if (ch === '(') { depth++; out += ch; } else if (ch === ')') { if (--depth === 0) return [out, i + 1]; out += ch; } else out += ch;
  }
  return [out, i];
}
/** Bytes (latin1) → text: UTF-16 when it has a BOM or looks like 2-byte codes, else as is. */
const pdfText = (b) => {
  if (b.startsWith('\xfe\xff') || (b.length >= 4 && b.length % 2 === 0 && /^(?:\x00[\x20-\x7e]|[\x04][\x00-\xff])+$/.test(b))) {
    const x = b.startsWith('\xfe\xff') ? b.slice(2) : b;
    let o = ''; for (let i = 0; i + 1 < x.length; i += 2) o += String.fromCharCode((x.charCodeAt(i) << 8) | x.charCodeAt(i + 1));
    return o;
  }
  return b;
};

/** Text from the content streams' Tj / TJ / ' / " operators, with line breaks on Td, TD, T*, Tm and BT. */
export function pdfStreamText(content) {
  let out = '', i = 0;
  const s = content;
  while (i < s.length) {
    const ch = s[i];
    if (ch === '(') { const [str, j] = pdfString(s, i + 1); out += pdfText(str); i = j; continue; }
    if (ch === '<' && s[i + 1] !== '<') {
      const j = s.indexOf('>', i); const hex = s.slice(i + 1, j).replace(/\s+/g, '');
      let b = ''; for (let k = 0; k + 1 < hex.length; k += 2) b += String.fromCharCode(parseInt(hex.slice(k, k + 2), 16));
      out += pdfText(b); i = j + 1; continue;
    }
    if (ch === '[') { i++; continue; }
    if (ch === ']') { i++; continue; }
    const m = /^(-?\d*\.?\d+)\s*/.exec(s.slice(i, i + 20));
    if (m && s[i - 1] !== '/' ) {
      // A big negative kerning inside TJ is a word gap.
      if (+m[1] < -200 && /\[[^\]]*$/.test(s.slice(Math.max(0, i - 200), i))) out += ' ';
      i += m[0].length; continue;
    }
    const op = /^(T\*|Td|TD|Tm|BT|ET|'|")(?=[\s\[(<\/]|$)/.exec(s.slice(i, i + 3));
    if (op) { if (op[1] !== 'ET' && !out.endsWith('\n')) out += '\n'; i += op[1].length; continue; }
    i++;
  }
  return out;
}

function pdfJs(buf) {
  const raw = buf.toString('latin1'), texts = [];
  const re = /<<([\s\S]*?)>>\s*stream\r?\n/g;
  let m;
  while ((m = re.exec(raw))) {
    const dict = m[1], start = m.index + m[0].length, end = raw.indexOf('endstream', start);
    if (end < 0) break;
    if (/\/(Subtype\s*\/Image|Type\s*\/(XObject|XRef|ObjStm|Metadata)|Length1|FontFile)/.test(dict)) { re.lastIndex = end; continue; }
    let data = buf.subarray(start, end);
    if (/\/FlateDecode/.test(dict)) { try { data = inflateSync(data); } catch { try { data = inflateSync(data.subarray(0, data.length - 1)); } catch { re.lastIndex = end; continue; } } }
    else if (/\/Filter/.test(dict)) { re.lastIndex = end; continue; }   // other encodings: not text we can read
    const c = data.toString('latin1');
    if (/\b(Tj|TJ)\b/.test(c)) texts.push(pdfStreamText(c));
    re.lastIndex = end;
  }
  return tidy(texts.join('\n\n').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, ''));
}

function pdf(abs, buf, env) {
  try {
    const t = execFileSync('pdftotext', ['-layout', '-enc', 'UTF-8', abs, '-'], { encoding: 'utf8', timeout: 30000, maxBuffer: 50e6, stdio: ['ignore', 'pipe', 'ignore'], env });
    if (t.trim()) return tidy(t.replace(/\f/g, '\n\n'));
  } catch { /* not installed or failed: our own reader */ }
  const t = pdfJs(buf);
  if (!/[\p{L}\p{N}]/u.test(t)) return '(Текст из PDF извлечь не удалось: это скан или шрифты без таблицы символов. Поможет pdftotext: sudo apt install poppler-utils / brew install poppler.)';
  return t;
}

/** The document's text, or null when it is not a document type. */
export function readDocument(abs, env = process.env) {
  const ext = extname(abs).toLowerCase();
  if (!DOC_EXT.test(ext)) return null;
  const buf = readFileSync(abs);
  if (ext === '.pdf') return pdf(abs, buf, env);
  const files = unzip(buf);
  const text = ext === '.docx' ? docx(files) : ext === '.xlsx' ? xlsx(files) : ext === '.pptx' ? pptx(files) : odf(files);
  return text || '(документ пустой)';
}
