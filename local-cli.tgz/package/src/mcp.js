// MCP (Model Context Protocol) client: connects external tool servers to the agent, the same format Claude Code
// uses. A server is either a local command spoken to over stdio (one JSON-RPC message per line) or an HTTP
// address (Streamable HTTP: POST JSON-RPC, answer as JSON or as an SSE stream).
//
// Config ({ "mcpServers": { name: { command, args, env } | { url, headers } } }) is read from
//   ~/.klinch/mcp.json            your own servers (klinch mcp add …)
//   <project>/.mcp.json           the project's servers (Claude Code format)
//   <project>/.klinch/mcp.json    the project's servers for Klinch only
// A project file can start programs on this computer, so its servers run only after the user allowed them once
// (remembered in ~/.klinch/mcp-trust.json by folder and config hash).
import { spawn } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, chmodSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { pluginServers } from './plugins.js';

const PROTOCOL = '2025-06-18';
const CLIENT = { name: 'klinch-code', version: '0.6.2' };
const OUT_MAX = 30000;

const dir = (env) => env.KLINCH_HOME || join(homedir(), '.klinch');
export const userMcpPath = (env = process.env) => join(dir(env), 'mcp.json');
const trustPath = (env) => join(dir(env), 'mcp-trust.json');

const readJson = (p) => { try { return JSON.parse(readFileSync(p, 'utf8')); } catch { return null; } };
function writeJson(p, v, env) {
  mkdirSync(dir(env), { recursive: true, mode: 0o700 });
  writeFileSync(p, JSON.stringify(v, null, 2) + '\n', { mode: 0o600 });
  try { chmodSync(p, 0o600); } catch { /* Windows */ }
}

/** `${VAR}` and `${VAR:-default}` in config strings come from the environment (keeps tokens out of the file). */
export function expandEnv(v, env = process.env) {
  if (typeof v === 'string') return v.replace(/\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}/g, (_, k, d) => env[k] ?? d ?? '');
  if (Array.isArray(v)) return v.map((x) => expandEnv(x, env));
  if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, expandEnv(x, env)]));
  return v;
}

export function readUserServers(env = process.env) { return readJson(userMcpPath(env))?.mcpServers || {}; }
export function saveUserServers(servers, env = process.env) { writeJson(userMcpPath(env), { mcpServers: servers }, env); }

/** All configured servers: [{ name, config, source: 'user' | 'project', file }]. A project entry wins on a name clash. */
export function loadServerConfigs(cwd, env = process.env) {
  const out = new Map();
  for (const s of pluginServers(env)) out.set(s.name, s);   // installed plugins' servers (src/plugins.js)
  for (const [name, config] of Object.entries(readUserServers(env))) out.set(name, { name, config, source: 'user', file: userMcpPath(env) });
  for (const file of [join(cwd, '.mcp.json'), join(cwd, '.klinch', 'mcp.json')]) {
    for (const [name, config] of Object.entries(readJson(file)?.mcpServers || {})) out.set(name, { name, config, source: 'project', file });
  }
  return [...out.values()].filter((s) => s.config && typeof s.config === 'object' && !s.config.disabled && (s.config.command || s.config.url));
}

const trustKey = (cwd, s) => cwd + '\0' + s.name + '\0' + createHash('sha256').update(JSON.stringify(s.config)).digest('hex');
export const isTrusted = (cwd, s, env = process.env) => s.source === 'user' || !!readJson(trustPath(env))?.[trustKey(cwd, s)];
export function trust(cwd, s, env = process.env) {
  const t = readJson(trustPath(env)) || {};
  t[trustKey(cwd, s)] = Date.now();
  writeJson(trustPath(env), t, env);
}

/* ---------------- transports ---------------- */

function stdioTransport({ command, args = [], env: extra = {}, cwd }, env) {
  const child = spawn(command, args, {
    cwd, env: { ...env, ...extra }, stdio: ['pipe', 'pipe', 'pipe'],
    shell: process.platform === 'win32', windowsHide: true,
  });
  let onMessage = () => {}, onClose = () => {}, buf = '', errTail = '';
  child.stdout.setEncoding('utf8');
  child.stdout.on('data', (d) => {
    buf += d;
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
      if (!line) continue;
      let m; try { m = JSON.parse(line); } catch { continue; }
      onMessage(m);
    }
  });
  child.stderr.setEncoding('utf8');
  child.stderr.on('data', (d) => { errTail = (errTail + d).slice(-2000); });
  child.on('error', (e) => onClose(e));
  child.on('close', (code) => onClose(new Error(`сервер завершился (код ${code})${errTail.trim() ? ': ' + errTail.trim().split('\n').slice(-3).join(' ') : ''}`)));
  return {
    send: async (m) => { child.stdin.write(JSON.stringify(m) + '\n'); },
    set onMessage(f) { onMessage = f; },
    set onClose(f) { onClose = f; },
    close: () => { try { child.stdin.end(); child.kill(); } catch { /* gone */ } },
  };
}

/** Pulls JSON-RPC messages out of an SSE body. */
async function* sseMessages(body) {
  const dec = new TextDecoder();
  let buf = '', data = [];
  for await (const chunk of body) {
    buf += dec.decode(chunk, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).replace(/\r$/, ''); buf = buf.slice(i + 1);
      if (line.startsWith('data:')) data.push(line.slice(5).trimStart());
      else if (!line && data.length) { try { yield JSON.parse(data.join('\n')); } catch { /* skip */ } data = []; }
    }
  }
  if (data.length) { try { yield JSON.parse(data.join('\n')); } catch { /* skip */ } }
}

function httpTransport({ url, headers = {} }, { fetchImpl = fetch, timeoutMs = 60000 } = {}) {
  let onMessage = () => {}, session = null;
  return {
    async send(m) {
      const r = await fetchImpl(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json', accept: 'application/json, text/event-stream', 'mcp-protocol-version': PROTOCOL, ...(session ? { 'mcp-session-id': session } : {}), ...headers },
        body: JSON.stringify(m), signal: AbortSignal.timeout(timeoutMs),
      });
      session = r.headers.get('mcp-session-id') || session;
      if (r.status === 202 || m.id === undefined) { try { await r.body?.cancel(); } catch { /* fine */ } return; }
      if (!r.ok) throw new Error(`HTTP ${r.status}${r.status === 401 ? ' (нужна авторизация: добавьте заголовок с токеном)' : ''}`);
      if ((r.headers.get('content-type') || '').includes('text/event-stream')) { for await (const x of sseMessages(r.body)) onMessage(x); }
      else onMessage(await r.json());
    },
    set onMessage(f) { onMessage = f; },
    set onClose(_) {},
    close() {
      if (session) fetchImpl(url, { method: 'DELETE', headers: { 'mcp-session-id': session, ...headers } }).catch(() => {});
    },
  };
}

/* ---------------- client ---------------- */

/** Connects to one server, runs the initialize handshake. Returns { tools, callTool(name, args), close() }. */
export async function connect(config, { cwd = process.cwd(), env = process.env, fetchImpl, timeoutMs = 30000 } = {}) {
  const cfg = expandEnv(config, env);
  const t = cfg.url ? httpTransport(cfg, { fetchImpl, timeoutMs: Math.max(timeoutMs, 60000) }) : stdioTransport({ ...cfg, cwd }, env);
  const pending = new Map();
  let nextId = 1, closed = null;
  t.onMessage = (m) => {
    if (m?.id !== undefined && pending.has(m.id)) {
      const p = pending.get(m.id); pending.delete(m.id);
      if (m.error) p.reject(new Error(m.error.message || 'ошибка MCP')); else p.resolve(m.result);
    } else if (m?.method && m.id !== undefined) {
      // A request from the server (sampling, roots…): not supported, answer so it does not hang.
      t.send({ jsonrpc: '2.0', id: m.id, ...(m.method === 'ping' ? { result: {} } : { error: { code: -32601, message: 'not supported' } }) }).catch(() => {});
    }
  };
  t.onClose = (e) => { closed = e; for (const p of pending.values()) p.reject(e); pending.clear(); };
  const request = (method, params, ms = timeoutMs) => new Promise((resolve, reject) => {
    if (closed) return reject(closed);
    const id = nextId++;
    const timer = setTimeout(() => { pending.delete(id); reject(new Error(`MCP: нет ответа на ${method} за ${ms / 1000} с`)); }, ms);
    pending.set(id, { resolve: (v) => { clearTimeout(timer); resolve(v); }, reject: (e) => { clearTimeout(timer); reject(e); } });
    t.send({ jsonrpc: '2.0', id, method, ...(params ? { params } : {}) }).catch((e) => { const p = pending.get(id); if (p) { pending.delete(id); p.reject(e); } });
  });
  try {
    const init = await request('initialize', { protocolVersion: PROTOCOL, capabilities: {}, clientInfo: CLIENT });
    await t.send({ jsonrpc: '2.0', method: 'notifications/initialized' });
    const tools = [];
    let cursor;
    do {
      const r = await request('tools/list', cursor ? { cursor } : {});
      tools.push(...(r?.tools || []));
      cursor = r?.nextCursor;
    } while (cursor && tools.length < 500);
    return {
      serverInfo: init?.serverInfo, instructions: init?.instructions, tools,
      callTool: (name, args, ms = 300000) => request('tools/call', { name, arguments: args || {} }, ms),
      close: () => t.close(),
    };
  } catch (e) { t.close(); throw e; }
}

/** An MCP tool result → text, or Anthropic content blocks when the server returned images. */
export function resultToContent(r) {
  const parts = [], images = [];
  for (const c of r?.content || []) {
    if (c.type === 'text') parts.push(c.text);
    else if (c.type === 'image' && c.data) images.push({ type: 'image', source: { type: 'base64', media_type: c.mimeType || 'image/png', data: c.data } });
    else if (c.type === 'resource') parts.push(c.resource?.text ?? `[ресурс ${c.resource?.uri || ''}]`);
    else if (c.type === 'resource_link') parts.push(`[ссылка ${c.uri}]`);
    else parts.push(`[${c.type}]`);
  }
  if (!parts.length && r?.structuredContent) parts.push(JSON.stringify(r.structuredContent, null, 2));
  let text = parts.join('\n');
  if (text.length > OUT_MAX) text = text.slice(0, OUT_MAX) + `\n… (обрезано, всего ${text.length} символов)`;
  if (r?.isError) throw new Error(text || 'инструмент MCP вернул ошибку');
  return images.length ? [{ type: 'text', text: text || '(изображение)' }, ...images] : text;
}

export const mcpToolName = (server, tool) => `mcp__${server}__${tool}`.replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 64);

/** Agent tool objects for a connected server. Only tools the server marks read-only run without confirmation. */
export function toAgentTools(name, conn) {
  return conn.tools.map((t) => {
    const full = mcpToolName(name, t.name);
    return {
      name: full,
      description: `[MCP ${name}] ${String(t.description || t.name).replace(/\s+/g, ' ').trim().slice(0, 1000)}`,
      input_schema: t.inputSchema && typeof t.inputSchema === 'object' ? t.inputSchema : { type: 'object', properties: {} },
      danger: t.annotations?.readOnlyHint !== true,
      mcp: name,
      preview: (input) => `${name} · ${t.name} ${JSON.stringify(input).slice(0, 300)}`,
      run: async (input) => resultToContent(await conn.callTool(t.name, input)),
    };
  });
}

/**
 * Connects every configured server in parallel. `allow(server)` decides about untrusted project servers.
 * Returns { tools, servers: [{ name, source, tools: n, error? }], close() }.
 */
export async function startServers({ cwd, env = process.env, allow = async () => false, log = () => {}, timeoutMs = 30000 } = {}) {
  const configs = loadServerConfigs(cwd, env);
  const conns = [];
  const servers = await Promise.all(configs.map(async (s) => {
    if (!isTrusted(cwd, s, env)) {
      if (!(await allow(s))) return { name: s.name, source: s.source, tools: 0, error: 'не разрешён' };
      trust(cwd, s, env);
    }
    try {
      const c = await connect(s.config, { cwd, env, timeoutMs });
      conns.push({ name: s.name, conn: c });
      return { name: s.name, source: s.source, tools: c.tools.length, instructions: c.instructions };
    } catch (e) {
      log(`MCP ${s.name}: ${e.message}`);
      return { name: s.name, source: s.source, tools: 0, error: e.message };
    }
  }));
  return {
    servers,
    tools: conns.flatMap(({ name, conn }) => toAgentTools(name, conn)),
    close: () => { for (const { conn } of conns) conn.close(); },
  };
}

/**
 * `klinch mcp add <name> [-e K=V]… [--] <command> [args…]`, `klinch mcp add <name> --url <url> [-H "K: V"]…`,
 * `klinch mcp remove <name>`, `klinch mcp list`. Returns lines to print.
 */
export function mcpCommand(argv, env = process.env, cwd = process.cwd()) {
  const [sub, name, ...rest] = argv;
  const servers = readUserServers(env);
  if (!sub || sub === 'list' || sub === 'ls') {
    const all = loadServerConfigs(cwd, env);
    if (!all.length) return ['MCP-серверов нет. Добавить: klinch mcp add <имя> -- <команда> [аргументы]  или  klinch mcp add <имя> --url <адрес>'];
    return all.map((s) => `${s.name.padEnd(18)} ${s.config.url || [s.config.command, ...(s.config.args || [])].join(' ')}  (${s.source === 'user' ? 'ваш' : 'из проекта'})`);
  }
  if (sub === 'remove' || sub === 'rm') {
    if (!servers[name]) throw new Error(`Сервера ${name} нет в ${userMcpPath(env)}`);
    delete servers[name]; saveUserServers(servers, env);
    return [`Удалён: ${name}`];
  }
  if (sub === 'add') {
    if (!name || !/^[A-Za-z0-9_-]{1,40}$/.test(name)) throw new Error('Имя сервера: латиница, цифры, - и _, до 40 символов');
    const cfg = {}, extraEnv = {}, headers = {};
    let i = 0;
    for (; i < rest.length; i++) {
      const a = rest[i];
      if (a === '-e' || a === '--env') { const [k, ...v] = String(rest[++i] || '').split('='); if (k) extraEnv[k] = v.join('='); }
      else if (a === '-H' || a === '--header') { const m = /^([^:]+):\s*(.*)$/.exec(rest[++i] || ''); if (m) headers[m[1].trim()] = m[2]; }
      else if (a === '--url') cfg.url = rest[++i];
      else if (a === '--') { i++; break; }
      else break;
    }
    const cmd = rest.slice(i);
    if (cfg.url) { if (!/^https?:\/\//.test(cfg.url)) throw new Error('--url должен начинаться с https://'); if (Object.keys(headers).length) cfg.headers = headers; }
    else {
      if (!cmd.length) throw new Error('Укажите команду сервера: klinch mcp add <имя> -- npx -y <пакет>');
      cfg.command = cmd[0]; cfg.args = cmd.slice(1);
      if (Object.keys(extraEnv).length) cfg.env = extraEnv;
    }
    servers[name] = cfg; saveUserServers(servers, env);
    return [`Добавлен MCP-сервер ${name}. Он подключится при следующем запуске klinch.`];
  }
  throw new Error('Команды: klinch mcp list | add | remove');
}
