// Semantic code index (like Cursor's codebase indexing): `codebase_search` finds code by meaning («где проверяется
// ключ», «retry on 429») as well as by words.
//
// The project is cut into chunks of ~60 lines (at blank lines and definitions where possible). Each chunk is found
// two ways and the two rankings are fused (reciprocal rank):
//   - words: BM25 over identifiers split into parts (camelCase, snake_case) and ordinary words, always, free, local;
//   - meaning: embeddings from the Klinch gateway (/v1/embeddings, multilingual qwen3-embedding, 256 dimensions,
//     billed like any request: about a hundred balance tokens for a mid-size project). Vectors are kept per chunk
//     text in ~/.klinch/index/<folder hash>.json, so only new or changed code is embedded again.
// When embeddings are not available (no balance, offline, the service busy) the search works by words alone.
// The index is built on the first search, refreshed (changed files only) on each next one.
import { readdirSync, readFileSync, statSync, writeFileSync, mkdirSync, renameSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { join, relative, sep, extname } from 'node:path';

const SKIP = new Set(['node_modules', '.git', 'dist', 'build', '.next', '.vercel', 'coverage', 'vendor', 'target', '__pycache__', '.venv', 'venv', 'Pods', '.build', 'out', '.turbo', '.cache']);
const EXT = new Set(['.js', '.mjs', '.cjs', '.jsx', '.ts', '.tsx', '.py', '.go', '.rs', '.java', '.kt', '.swift', '.rb', '.php', '.cs', '.c', '.h', '.cpp', '.hpp', '.vue', '.svelte', '.dart', '.scala',
  '.sql', '.sh', '.md', '.mdx', '.html', '.css', '.scss', '.yaml', '.yml', '.toml', '.graphql', '.proto', '.lua', '.ex', '.exs', '.erl', '.hs', '.ml', '.clj', '.zig', '.sol']);
const NAMES = new Set(['Dockerfile', 'Makefile', 'Rakefile', 'Gemfile']);
const MAX_FILES = 5000, MAX_FILE = 300_000, CHUNK = 60, MIN_CHUNK = 15;
export const EMBED_MODEL = 'qwen3-embedding-0.6b';
export const DIMS = 256;
// Chunks embedded per project at most (the rest is found by words): keeps a huge monorepo from costing much or taking
// a big share of the gateway's daily embedding capacity.
export const MAX_EMBED = 4000;
const BATCH = 96, EMBED_CHARS = 1800, RETRY_MS = 10 * 60_000;

const sha = (s) => createHash('sha1').update(s).digest('hex').slice(0, 16);
const indexFile = (cwd, env) => join(env.KLINCH_HOME || join(homedir(), '.klinch'), 'index', sha(cwd) + '.json');

/** The project's files worth indexing: git's list when it is a repository (honours .gitignore), else a walk. */
export function projectFiles(cwd) {
  let list = null;
  try {
    const out = execFileSync('git', ['ls-files', '-co', '--exclude-standard', '-z'], { cwd, stdio: ['ignore', 'pipe', 'ignore'], maxBuffer: 64 << 20, timeout: 10_000 }).toString();
    list = out.split('\0').filter(Boolean);
  } catch { /* not a git repository */ }
  if (!list) {
    list = [];
    const walk = (abs) => {
      let entries; try { entries = readdirSync(abs, { withFileTypes: true }); } catch { return; }
      for (const e of entries.sort((a, b) => a.name.localeCompare(b.name))) {
        if (list.length >= MAX_FILES * 2) return;
        if (e.name.startsWith('.')) continue;
        const p = join(abs, e.name);
        if (e.isDirectory()) { if (!SKIP.has(e.name)) walk(p); } else if (e.isFile()) list.push(relative(cwd, p).split(sep).join('/'));
      }
    };
    walk(cwd);
  }
  return list.filter((f) => {
    const parts = f.split('/');
    if (parts.some((x) => SKIP.has(x))) return false;
    const name = parts.at(-1);
    if (/\.(min|bundle)\.js$|\.d\.ts$|\.map$|-lock\.|\.lock$|^package-lock\.json$/.test(name)) return false;
    return EXT.has(extname(name).toLowerCase()) || NAMES.has(name);
  }).slice(0, MAX_FILES);
}

const DEF = /^\s*(?:export\s+|pub(?:\([^)]*\))?\s+|public\s+|private\s+|protected\s+|static\s+|async\s+|default\s+)*(?:function|class|def|fn|func|interface|type|enum|struct|trait|impl|module|const\s+\w+\s*=\s*(?:async\s*)?\(|#{1,3}\s)/;

/** Cuts a file into chunks of about CHUNK lines, preferring to start a chunk at a definition or after a blank line. */
export function chunkFile(text) {
  const lines = text.split('\n');
  const out = [];
  let start = 0;
  while (start < lines.length) {
    let end = Math.min(lines.length, start + CHUNK);
    if (end < lines.length) {
      // Look back from the limit for a good place to cut (a definition starts, or a blank line), not too short.
      for (let i = end; i > start + MIN_CHUNK; i--) {
        if (DEF.test(lines[i] || '') || (!lines[i - 1]?.trim() && lines[i]?.trim())) { end = i; break; }
      }
    }
    let last = end;
    while (last > start && !lines[last - 1].trim()) last--;   // trailing blank lines are not part of it
    if (last > start) out.push({ start: start + 1, end: last, text: lines.slice(start, last).join('\n') });
    start = end;
  }
  return out;
}

// ---------- Words (BM25) ----------

/** Words of a text: identifiers split into parts too (getUserKey → get, user, key, getuserkey), lowercase. */
export function words(text) {
  const out = [];
  for (const w of String(text).match(/[\p{L}_$][\p{L}\p{N}_$]*/gu) || []) {
    if (w.length > 40) continue;
    const low = w.toLowerCase();
    out.push(low);
    const parts = w.replace(/([a-zа-яё0-9])([A-ZА-ЯЁ])/g, '$1 $2').replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2').split(/[\s_$]+/).filter((x) => x.length > 1);
    if (parts.length > 1) for (const p of parts) out.push(p.toLowerCase());
  }
  // Russian and other inflected words: also the first 5 letters, so «ключа» meets «ключ», «ключи».
  return out.flatMap((w) => (/[а-яё]/.test(w) && w.length > 5 ? [w, w.slice(0, 5)] : [w]));
}

function bm25(chunks, query) {
  const q = [...new Set(words(query))];
  if (!q.length) return chunks.map(() => 0);
  const N = chunks.length, avg = chunks.reduce((a, c) => a + c.len, 0) / (N || 1);
  const df = new Map(q.map((w) => [w, 0]));
  for (const c of chunks) for (const w of q) if (c.tf.has(w)) df.set(w, df.get(w) + 1);
  return chunks.map((c) => {
    let s = 0;
    for (const w of q) {
      const f = c.tf.get(w);
      if (!f) continue;
      const idf = Math.log(1 + (N - df.get(w) + 0.5) / (df.get(w) + 0.5));
      s += idf * (f * 2.2) / (f + 1.2 * (0.25 + 0.75 * c.len / avg));
    }
    // A word of the query in the file's path counts too (searching «auth» finds auth.js).
    for (const w of q) if (w.length > 2 && c.file.toLowerCase().includes(w)) s += 0.5;
    return s;
  });
}

// ---------- Meaning (vectors) ----------

/** A vector as 256 signed bytes (scaled to its largest value) in base64: ~350 characters per chunk on disk. */
export function packVec(v) {
  const m = Math.max(...v.map(Math.abs)) || 1;
  return Buffer.from(Int8Array.from(v, (x) => Math.round((x / m) * 127)).buffer).toString('base64');
}
export function unpackVec(s) {
  const b = Buffer.from(s, 'base64'), v = new Float32Array(b.length);
  let n = 0;
  for (let i = 0; i < b.length; i++) { v[i] = (b[i] << 24) >> 24; n += v[i] * v[i]; }
  n = Math.sqrt(n) || 1;
  for (let i = 0; i < v.length; i++) v[i] /= n;
  return v;
}
const dot = (a, b) => { let s = 0; for (let i = 0; i < a.length && i < b.length; i++) s += a[i] * b[i]; return s; };
const embedText = (c) => `${c.file}\n${c.text}`.slice(0, EMBED_CHARS);

/**
 * The index of one folder. `embed(texts)` → array of vectors (the gateway), or null for words only.
 * `env.KLINCH_HOME` moves the cache (tests).
 */
export function createCodeIndex({ cwd, embed = null, env = process.env }) {
  const path = indexFile(cwd, env);
  let saved = { model: EMBED_MODEL, dims: DIMS, files: {}, vectors: {} };
  try { const v = JSON.parse(readFileSync(path, 'utf8')); if (v?.model === EMBED_MODEL && v.dims === DIMS) saved = v; } catch { /* first time */ }
  let chunks = [];            // [{ file, start, end, text, hash, tf, len }]
  let embedOff = 0;           // time embeddings last failed (words only until RETRY_MS later)
  let lastNote = '';
  const vecCache = new Map();
  let queue = Promise.resolve();

  /** Re-reads changed files; returns how many changed. */
  function refresh() {
    const list = projectFiles(cwd);
    const files = {};
    let changed = 0;
    const next = [];
    for (const f of list) {
      let st; try { st = statSync(join(cwd, f)); } catch { continue; }
      if (!st.isFile() || st.size > MAX_FILE) continue;
      const stamp = `${st.size}:${Math.round(st.mtimeMs)}`;
      const old = saved.files[f];
      let parts;
      if (old && old.stamp === stamp) parts = old.chunks;
      else {
        let text; try { text = readFileSync(join(cwd, f), 'utf8'); } catch { continue; }
        if (text.includes('\0')) continue;
        // The texts stay in memory for this session only; on disk just the line ranges and hashes.
        parts = chunkFile(text).map((c) => ({ start: c.start, end: c.end, hash: sha(f + '\n' + c.text), text: c.text }));
        changed++;
      }
      files[f] = { stamp, chunks: parts.map(({ start, end, hash }) => ({ start, end, hash })) };
      for (const p of parts) next.push({ file: f, start: p.start, end: p.end, hash: p.hash, text: p.text });
    }
    // Texts of unchanged files are read once per session (needed for words and for showing the result).
    const byFile = new Map();
    for (const c of next) if (c.text == null) (byFile.get(c.file) || byFile.set(c.file, []).get(c.file)).push(c);
    for (const [f, cs] of byFile) {
      let lines; try { lines = readFileSync(join(cwd, f), 'utf8').split('\n'); } catch { lines = []; }
      for (const c of cs) c.text = lines.slice(c.start - 1, c.end).join('\n');
    }
    const prev = new Map(chunks.map((c) => [c.hash, c]));
    chunks = next.map((c) => {
      const p = prev.get(c.hash);
      if (p) return p;
      const tf = new Map(), ws = words(c.file + ' ' + c.text);
      for (const w of ws) tf.set(w, (tf.get(w) || 0) + 1);
      return { ...c, tf, len: ws.length };
    });
    const removed = Object.keys(saved.files).filter((f) => !files[f]).length;
    saved.files = files;
    return changed + removed;
  }

  /** Embeds the chunks that have no vector yet (up to MAX_EMBED in all). */
  async function embedMissing(signal) {
    if (!embed || Date.now() - embedOff < RETRY_MS) return { added: 0, ok: false };
    const live = new Set(chunks.map((c) => c.hash));
    for (const h of Object.keys(saved.vectors)) if (!live.has(h)) { delete saved.vectors[h]; vecCache.delete(h); }
    const have = Object.keys(saved.vectors).length;
    const todo = chunks.filter((c) => !saved.vectors[c.hash]).slice(0, Math.max(0, MAX_EMBED - have));
    let added = 0;
    try {
      for (let i = 0; i < todo.length; i += BATCH) {
        if (signal?.aborted) break;
        const part = todo.slice(i, i + BATCH);
        const vecs = await embed(part.map(embedText), signal);
        part.forEach((c, j) => { if (Array.isArray(vecs[j]) && vecs[j].length) saved.vectors[c.hash] = packVec(vecs[j]); });
        added += part.length;
      }
    } catch (e) {
      embedOff = Date.now();
      lastNote = `поиск по смыслу сейчас недоступен (${String(e.message || e).slice(0, 80)}), искал по словам`;
      return { added, ok: false };
    }
    return { added, ok: true };
  }

  function save() {
    try {
      mkdirSync(join(path, '..'), { recursive: true, mode: 0o700 });
      writeFileSync(path + '.tmp', JSON.stringify(saved));
      renameSync(path + '.tmp', path);
    } catch { /* read-only home: the index lives for this session only */ }
  }
  const vec = (h) => { let v = vecCache.get(h); if (!v && saved.vectors[h]) vecCache.set(h, (v = unpackVec(saved.vectors[h]))); return v; };

  return {
    /** Builds or refreshes the index. Returns { files, chunks, vectors, changed, embedded }. */
    update(signal) {
      // One update at a time: parallel searches (explore subagents) wait for the same one instead of embedding twice.
      const run = async () => {
        const changed = refresh();
        const e = await embedMissing(signal);
        if (changed || e.added) save();
        return { files: Object.keys(saved.files).length, chunks: chunks.length, vectors: chunks.filter((c) => saved.vectors[c.hash]).length, changed, embedded: e.added };
      };
      const p = queue.then(run, run);
      queue = p.catch(() => {});
      return p;
    },
    /** The best chunks for the query: [{ file, start, end, text, score }]. `under`: only paths starting with it. */
    async search(query, { limit = 8, under = '', signal } = {}) {
      lastNote = '';
      await this.update(signal);
      const pool = under ? chunks.filter((c) => c.file.startsWith(under.replace(/^\.\//, '').replace(/\\/g, '/'))) : chunks;
      if (!pool.length) return [];
      const rank = (scores) => { const order = scores.map((s, i) => [s, i]).filter((x) => x[0] > 0).sort((a, b) => b[0] - a[0]); const r = new Map(); order.forEach(([, i], k) => r.set(i, k)); return r; };
      const byWords = rank(bm25(pool, query));
      let byMeaning = new Map();
      if (embed && Date.now() - embedOff >= RETRY_MS && pool.some((c) => saved.vectors[c.hash])) {
        try {
          const [qv] = await embed([query], signal);
          const q = Float32Array.from(qv); let n = 0; for (const x of q) n += x * x; n = Math.sqrt(n) || 1;
          for (let i = 0; i < q.length; i++) q[i] /= n;
          byMeaning = rank(pool.map((c) => { const v = vec(c.hash); return v ? dot(q, v) + 1 : 0; }));
        } catch (e) {
          embedOff = Date.now();
          lastNote = `поиск по смыслу сейчас недоступен (${String(e.message || e).slice(0, 80)}), искал по словам`;
        }
      }
      // Reciprocal rank fusion: a chunk high in either list comes up; high in both comes first.
      const K = 30, score = new Map();
      for (const [i, r] of byWords) score.set(i, (score.get(i) || 0) + 1 / (K + r));
      for (const [i, r] of byMeaning) if (r < 200) score.set(i, (score.get(i) || 0) + 1.2 / (K + r));
      return [...score].sort((a, b) => b[1] - a[1]).slice(0, limit).map(([i, s]) => ({ file: pool[i].file, start: pool[i].start, end: pool[i].end, text: pool[i].text, score: +s.toFixed(4) }));
    },
    get note() { return lastNote; },
    get semantic() { return !!embed && Date.now() - embedOff >= RETRY_MS; },
    path,
  };
}

/** The tool result: each hit with its place and the first lines of the code. */
export function formatHits(hits, note = '') {
  if (!hits.length) return 'Ничего не найдено' + (note ? ` (${note})` : '');
  const body = hits.map((h) => {
    const lines = h.text.split('\n');
    const shown = lines.slice(0, 18).map((l, i) => `${String(h.start + i).padStart(5)}| ${l.slice(0, 200)}`).join('\n');
    return `${h.file}:${h.start}-${h.end}\n${shown}${lines.length > 18 ? `\n      … ещё ${lines.length - 18} строк` : ''}`;
  }).join('\n\n');
  return (note ? `(${note})\n\n` : '') + body;
}

export const describeIndex = (s) => `${s.files} файлов, ${s.chunks} фрагментов, по смыслу: ${s.vectors}${s.embedded ? ` (добавлено ${s.embedded})` : ''}`;
