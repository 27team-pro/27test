// Chat commands for several agents (src/multi.js, src/board.js, src/bots.js):
//   /compare [m1,m2,@бот] <задача>   one task on several models in parallel, Agent Review compares, you pick one
//   /moa [m1,m2] <вопрос>            Mixture of Agents: several models answer, the current one merges the answers
//   /review [модель]                 Agent Review of the current changes before you accept them
//   /board …                         Kanban board: cards for several agents, run in parallel, review, apply
//   /bot [имя|off|new <имя>], /bots  named bots with their own role, model and memory
import { saveConfig } from './config.js';
import { fmt } from './api.js';
import {
  runJobs, repoInfo, pickModels, splitModels, applyPatch, savePatch, currentDiff, tokensOf, textOf,
  REVIEWER, reviewPrompt, compareReviewPrompt, bestOf, moaPrompt,
} from './multi.js';
import { loadBoard, saveBoard, addCard, findCard, formatBoard } from './board.js';
import { createBot, loadBots } from './bots.js';
import { readFileSync } from 'node:fs';

export const MOA_ROLE = { name: 'эксперт', prompt: 'Ответь на запрос пользователя как можно лучше: точно, полно, с конкретикой. Нужное в коде изучи сам. Твой ответ сравнят с ответами других экспертов и сведут в один, поэтому не сокращай важное.' };
const verdictOf = (t) => (/ИТОГ:\s*нужно исправить/i.test(t) ? 'ревью: нужно исправить' : /ИТОГ:\s*можно принимать/i.test(t) ? 'ревью: можно принимать' : null);

/**
 * h: { agent, spawn, client, cfg, env, c, write, line(q) → answer, busy(fn(signal)), send(content, label), mainOut,
 *      bots, getBot, setBot(bot|null) }
 */
export function multiCommands(h) {
  const { agent, spawn, client, cfg, env, c, write } = h;
  const ids = async () => (await client.models()).map((m) => m.id);
  const labelOut = (label) => ({
    text() {}, endText() {}, toolStart() {}, thinking() {}, todos() {}, plan() {},
    tool: (p) => write(c.dim(`  [${label}] ▸ ${p.split('\n')[0].slice(0, 110)}`) + '\n'),
    sub: (l, p) => write(c.dim(`  [${label}] ↳ ${l}: ${p.split('\n')[0].slice(0, 90)}`) + '\n'),
    note: (n) => write(c.dim(`  [${label}] · ${n}`) + '\n'),
  });
  const done = (r) => write((r.ok ? c.green('  ✓ ') : c.red('  ✗ ')) + `[${r.label}] ${r.ok ? `готово за ${Math.round(r.ms / 1000)} с` : r.error}${r.stat?.files ? c.dim(` · +${r.stat.plus} −${r.stat.minus} в ${r.stat.files} файл.`) : ''}\n`);
  const bot = (name) => {
    const b = h.bots.find((x) => x.name === String(name).replace(/^@/, '').toLowerCase());
    if (!b) throw new Error(`Нет бота ${name}. Список: /bots`);
    return b;
  };
  const botPersona = (b) => h.personaFor(b);

  /** Jobs for the models / @bots asked for (else saved or picked ones). */
  async function jobsFor(asked, task, savedKey) {
    const all = await ids();
    const bots = asked.filter((x) => x.startsWith('@')).map(bot);
    const models = asked.filter((x) => !x.startsWith('@'));
    const jobs = bots.map((b) => ({ label: '@' + b.name, model: b.model && all.includes(b.model) ? b.model : agent.model, persona: botPersona(b), effort: b.effort, task }));
    if (models.length || !bots.length) {
      for (const m of pickModels(all, { asked: models, saved: bots.length ? [] : (cfg[savedKey] || []), current: agent.model })) jobs.push({ label: m, model: m, task });
    }
    if (jobs.length < 2 && savedKey === 'compareModels') throw new Error('Нужно хотя бы две модели: /compare m1,m2 <задача>');
    return jobs.slice(0, 6);
  }

  async function compare(args) {
    const all = await ids();
    const { models, task } = splitModels(args, all);
    if (!task) return write(`/compare [модель1,модель2,@бот] <задача>${c.dim('  без списка: ' + (cfg.compareModels?.join(', ') || 'текущая модель и две другие') + '; сохранить список: /compare models m1,m2')}\n`);
    const jobs = await jobsFor(models, task, 'compareModels');
    const repo = repoInfo(agent.cwd);
    write(c.bold(`Запускаю ${jobs.length} агентов параллельно: ${jobs.map((j) => j.label).join(', ')}`) + '\n' + c.dim(repo ? '  каждый правит свою копию репозитория, ваши файлы не меняются, пока вы не выберете вариант\n' : '  папка не в git: агенты только читают и отвечают\n'));
    const { results, isolated, top } = await h.busy((signal) => runJobs({ jobs, spawn: (j) => spawn({ ...j, out: labelOut(j.label) }), cwd: agent.cwd, signal, onDone: done }));
    write('\n' + c.bold('Итог') + '\n');
    for (const r of results) write(`  ${r.n}. ${r.label.padEnd(22)} ${r.ok ? c.green('готово') : c.red('нет  ')} ${String(Math.round(r.ms / 1000)).padStart(4)} с  ${String(r.steps).padStart(3)} шаг.  ${fmt(tokensOf(r.usage)).padStart(9)} ток.  ${r.stat.files ? `+${r.stat.plus} −${r.stat.minus} в ${r.stat.files} файл.` : c.dim('без правок')}\n`);
    if (!results.some((r) => r.ok)) return;
    let best = null;
    if (results.filter((r) => r.ok).length > 1 || results.some((r) => r.patch)) {
      write('\n' + c.bold('Agent Review') + c.dim(' · сравнивает варианты') + '\n');
      const reviewer = spawn({ label: 'ревью', model: cfg.reviewModel || agent.model, cwd: agent.cwd, readOnly: true, role: REVIEWER, out: h.mainOut });
      try { best = bestOf(textOf(await h.busy((signal) => reviewer.ask(compareReviewPrompt(task, results), { signal })))); }
      catch (e) { write(c.red(`Ревью не удалось: ${e.message}`) + '\n'); }
      h.mainOut.endText();
    }
    const withPatch = results.filter((r) => r.patch.trim());
    if (!isolated || !withPatch.length) {
      const pick = results.find((r) => r.n === best) || results.find((r) => r.ok);
      if (pick?.answer && !isolated) write('\n' + c.bold(`Ответ варианта ${pick.n} (${pick.label})`) + '\n' + pick.answer + '\n');
      return;
    }
    const stamp = Date.now().toString(36);
    for (const r of withPatch) r.file = savePatch(r.patch, `compare-${stamp}-${r.n}`, env);
    const dflt = withPatch.some((r) => r.n === best) ? best : null;
    const v = (await h.line(c.bold(`Применить вариант? [${withPatch.map((r) => r.n).join('/')}${dflt ? `, Enter = ${dflt}` : ''}, n = ничего] `))).trim().toLowerCase();
    const n = v === '' ? dflt : /^\d+$/.test(v) ? +v : null;
    const r = withPatch.find((x) => x.n === n);
    if (!r) return write(c.dim(`Ничего не применено. Патчи: ${withPatch.map((x) => x.file).join(', ')} (git apply <файл>)\n`));
    const file = applyPatch(top, r.patch, env);
    write(c.green(`Применил вариант ${r.n} (${r.label}): ${r.stat.names.slice(0, 8).join(', ')}${r.stat.names.length > 8 ? '…' : ''}`) + '\n' + c.dim(`Отменить: git apply -R ${file}\n`));
    h.note(`[Пользователь запускал /compare «${task.slice(0, 200)}» на ${results.length} моделях и применил вариант ${r.n}: изменены ${r.stat.names.join(', ')}. Итог того агента: ${r.answer.slice(0, 1500)}]`);
  }

  async function moa(args) {
    const all = await ids();
    const { models, task } = splitModels(args, all);
    if (!task) return write(`/moa [модель1,модель2] <вопрос или задача>${c.dim('  несколько моделей отвечают параллельно, текущая сводит ответы в один; сохранить список: /moa models m1,m2')}\n`);
    const jobs = (await jobsFor(models, task, 'moaModels'));
    write(c.bold(`Mixture of Agents: ${jobs.map((j) => j.label).join(', ')} отвечают параллельно`) + '\n');
    const { results } = await h.busy((signal) => runJobs({ jobs, isolate: false, spawn: (j) => spawn({ ...j, readOnly: true, role: MOA_ROLE, out: labelOut(j.label) }), cwd: agent.cwd, signal, onDone: done }));
    if (!results.some((r) => r.ok && r.answer)) return write(c.red('Ни одна модель не ответила.\n'));
    write(c.dim(`  ${agent.model} сводит ответы…`) + '\n');
    await h.send(moaPrompt(task, results), 'сводит ответы');
  }

  async function review(args) {
    const model = (args || '').trim() || cfg.reviewModel || agent.model;
    if (model !== agent.model && !(await ids()).includes(model)) return write(c.red(`Нет модели ${model}. Список: /models\n`));
    let diff;
    try { ({ diff } = currentDiff(agent.cwd)); } catch { return write(c.red('Ревью смотрит изменения git: эта папка не в репозитории.\n')); }
    if (!diff.trim()) return write(c.dim('Изменений нет: git diff пустой.\n'));
    write(c.bold('Agent Review') + c.dim(` · ${model} проверяет изменения`) + '\n');
    const reviewer = spawn({ label: 'ревью', model, cwd: agent.cwd, readOnly: true, role: REVIEWER, out: h.mainOut });
    const text = textOf(await h.busy((signal) => reviewer.ask(reviewPrompt(diff, agent.checkpoints().at(-1)?.prompt || ''), { signal })));
    h.mainOut.endText();
    if (verdictOf(text) === 'ревью: нужно исправить') {
      const v = (await h.line(c.bold('Отдать замечания агенту на исправление? [y/N] '))).trim().toLowerCase();
      if (['y', 'д', 'yes', 'да'].includes(v)) await h.send(`Ревью нашло проблемы в текущих изменениях. Исправь их (если замечание неверное, объясни почему):\n\n${text}`, 'исправляет по ревью');
    }
  }

  // ---- Kanban ----
  let running = false;
  const board = () => {
    const b = loadBoard(h.startCwd, env);
    if (!running) for (const x of b.cards) if (x.status === 'doing') { x.status = 'todo'; x.error = 'прервано'; }
    return b;
  };
  const show = (b) => {
    if (!b.cards.length) return write(c.dim('Доска пуста. /board add <задача> [@бот] [-m модель], потом /board run — все карточки идут параллельно.\n'));
    write(formatBoard(b).map((l) => (l.startsWith('  ') ? l : c.bold(l))).join('\n') + '\n' + c.dim('/board run · /board show N · /board apply N · /board drop N · /board rm N\n'));
  };

  async function boardCmd(args) {
    const [sub = '', ...rest] = String(args || '').trim().split(/\s+/);
    const arg = rest.join(' ');
    const b = board();
    if (!sub) return show(b);
    if (sub === 'add') { const card = addCard(b, arg); if (card.bot) bot(card.bot); saveBoard(b, env); return write(`Добавил #${card.id}: ${card.title}\n`); }
    if (sub === 'rm') { const card = findCard(b, arg); b.cards = b.cards.filter((x) => x !== card); saveBoard(b, env); return write(`Удалил #${card.id}\n`); }
    if (sub === 'clear') { b.cards = b.cards.filter((x) => x.status !== 'done'); saveBoard(b, env); return write('Готовые карточки убраны.\n'); }
    if (sub === 'show') {
      const card = findCard(b, arg);
      write(`${c.bold(`#${card.id} ${card.title}`)}\n${c.dim(`статус: ${card.status}${card.bot ? ` · @${card.bot}` : ''}${card.model ? ` · ${card.model}` : ''}${card.error ? ` · ${card.error}` : ''}`)}\n`);
      if (card.answer) write(`\n${card.answer}\n`);
      if (card.review) write(`\n${c.bold('Ревью')}\n${card.review}\n`);
      if (card.patch) write(c.dim(`\nПатч: ${card.patch}${card.stat ? ` (+${card.stat.plus} −${card.stat.minus}: ${card.stat.names.join(', ')})` : ''}\n`));
      return;
    }
    if (sub === 'apply') {
      const card = findCard(b, arg);
      if (!card.patch) throw new Error(`У #${card.id} нет изменений`);
      const top = repoInfo(agent.cwd)?.top;
      if (!top) throw new Error('Папка не в git');
      const file = applyPatch(top, readFileSync(card.patch, 'utf8'), env);
      card.status = 'done'; saveBoard(b, env);
      h.note(`[С доски задач применены изменения карточки #${card.id} «${card.title.slice(0, 200)}»: ${(card.stat?.names || []).join(', ')}]`);
      return write(c.green(`Применил #${card.id}: ${(card.stat?.names || []).join(', ')}`) + '\n' + c.dim(`Отменить: git apply -R ${file}\n`));
    }
    if (sub === 'drop') { const card = findCard(b, arg); card.status = 'todo'; delete card.patch; delete card.stat; delete card.review; delete card.verdict; saveBoard(b, env); return write(`#${card.id} снова ждёт, изменения отброшены.\n`); }
    if (sub === 'run') {
      const want = arg ? arg.split(/[\s,]+/).map((x) => findCard(b, x)) : b.cards.filter((x) => x.status === 'todo');
      if (!want.length) return write(c.dim('Нет карточек, которые ждут. /board add <задача>\n'));
      const all = await ids();
      const jobs = want.map((card) => {
        const bt = card.bot ? bot(card.bot) : null;
        const model = card.model && all.includes(card.model) ? card.model : bt?.model && all.includes(bt.model) ? bt.model : agent.model;
        card.status = 'doing'; delete card.error;
        return { card, label: '#' + card.id, model, persona: bt ? botPersona(bt) : undefined, effort: bt?.effort, task: card.title };
      });
      saveBoard(b, env);
      write(c.bold(`В работе ${jobs.length}: ${jobs.map((j) => `${j.label} ${j.model}`).join(', ')}`) + '\n');
      running = true;
      let res;
      try {
        res = await h.busy((signal) => runJobs({ jobs, spawn: (j) => spawn({ ...j, out: labelOut(j.label) }), cwd: agent.cwd, signal, onDone: (r) => {
          done(r);
          const card = jobs[r.n - 1].card;
          card.answer = r.answer.slice(0, 6000); card.stat = r.stat;
          if (!r.ok) { card.status = 'todo'; card.error = r.error; }
          else if (r.patch.trim()) { card.status = 'review'; card.patch = savePatch(r.patch, `board-${card.id}-${Date.now().toString(36)}`, env); }
          else card.status = 'done';
          saveBoard(b, env);
        } }));
      } finally { running = false; for (const j of jobs) if (j.card.status === 'doing') j.card.status = 'todo'; saveBoard(b, env); }
      // Agent Review of every finished change, in parallel.
      const toReview = jobs.filter((j) => j.card.status === 'review').map((j) => ({ j, r: res.results[jobs.indexOf(j)] }));
      if (toReview.length) {
        write(c.dim(`  Agent Review: ${toReview.length} карточ.…`) + '\n');
        const rv = await h.busy((signal) => runJobs({ isolate: false, cwd: agent.cwd, signal,
          jobs: toReview.map(({ j, r }) => ({ label: `ревью ${j.label}`, model: cfg.reviewModel || agent.model, task: reviewPrompt(r.patch, j.card.title) })),
          spawn: (x) => spawn({ ...x, readOnly: true, role: REVIEWER, out: labelOut(x.label) }) }));
        rv.results.forEach((r, i) => { const card = toReview[i].j.card; card.review = r.answer.slice(0, 6000); card.verdict = verdictOf(r.answer); });
        saveBoard(b, env);
      }
      return show(b);
    }
    throw new Error('/board, /board add <задача> [@бот] [-m модель], /board run [N…], show N, apply N, drop N, rm N, clear');
  }

  async function botCmd(args) {
    const [sub = '', ...rest] = String(args || '').trim().split(/\s+/);
    if (!sub) {
      const cur = h.getBot();
      write(cur ? `Бот: ${c.bold(cur.name)} ${c.dim(cur.description)}\n` : c.dim('Бот не выбран.\n'));
      return bots();
    }
    if (sub === 'off') { h.setBot(null); return write('Бот выключен.\n'); }
    if (sub === 'new') {
      const file = createBot(rest[0] || '', { model: '' }, env);
      h.bots.splice(0, h.bots.length, ...loadBots(h.startCwd, env));
      return write(c.green(`Создан ${file}`) + c.dim('\nОпишите в нём роль и характер бота, model: и effort: в шапке по желанию, затем /bot <имя>.\n'));
    }
    const b = bot(sub);
    const ok = !b.model || (await ids()).includes(b.model);
    h.setBot(b, ok);
    if (!ok) write(c.yellow(`Модели ${b.model} нет, бот работает на ${agent.model}\n`));
    write(`Бот: ${c.bold(b.name)}${c.dim(` · ${agent.model}${b.effort ? ` · мысли ${b.effort}` : ''} · память: ${h.memoryOf(b) ? 'есть' : 'пока пусто'}`)}\n`);
  }

  function bots() {
    if (!h.bots.length) return write(c.dim('Ботов нет. Создать: /bot new <имя> (файл ~/.klinch/bots/<имя>.md: роль, характер, model, effort). Личность для всех сессий: SOUL.md в проекте или ~/.klinch/SOUL.md\n'));
    for (const x of h.bots) write(`  ${h.getBot()?.name === x.name ? c.green('● ') : '  '}${c.bold(x.name)} ${c.dim([x.model, x.description].filter(Boolean).join(' · '))}\n`);
  }

  const saveList = (key, cmd) => async (args) => {
    const [first, ...rest] = String(args || '').trim().split(/\s+/);
    if (first !== 'models') return cmd(args);
    const list = rest.join(',').split(',').map((s) => s.trim()).filter(Boolean);
    if (list.length) pickModels(await ids(), { asked: list });
    saveConfig({ [key]: list.length ? list : undefined }, env); cfg[key] = list.length ? list : undefined;
    write(list.length ? `Сохранил: ${list.join(', ')}\n` : c.dim('Список сброшен: текущая модель и две другие.\n'));
  };

  return { compare: saveList('compareModels', compare), moa: saveList('moaModels', moa), review, board: boardCmd, bot: botCmd, bots };
}
