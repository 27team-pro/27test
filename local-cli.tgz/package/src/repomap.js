// Repository map: the project's main files and the functions, classes and types they define, ranked by how much
// the rest of the code uses them (PageRank over "file A mentions a name defined in file B"). Gives the agent the
// shape of an unfamiliar project in a couple of thousand tokens instead of dozens of reads.
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative, sep, extname } from 'node:path';

const SKIP = new Set(['node_modules', '.git', 'dist', 'build', '.next', '.vercel', 'coverage', 'vendor', 'target', '__pycache__', '.venv', 'venv', 'Pods', '.build', 'out']);
const CODE = new Set(['.js', '.mjs', '.cjs', '.jsx', '.ts', '.tsx', '.py', '.go', '.rs', '.java', '.kt', '.swift', '.rb', '.php', '.cs', '.c', '.h', '.cpp', '.hpp', '.vue', '.svelte', '.dart', '.scala']);

const DEFS = [
  /^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?function\*?\s+([A-Za-z_$][\w$]*)/,
  /^\s*(?:export\s+)?(?:default\s+)?(?:abstract\s+)?class\s+([A-Za-z_$][\w$]*)/,
  /^\s*(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:function|\([^)]*\)\s*(?::[^=]+)?=>|[A-Za-z_$][\w$]*\s*=>)/,
  /^\s*(?:export\s+)?(?:interface|type|enum)\s+([A-Za-z_$][\w$]*)/,
  /^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)/,
  /^func\s+(?:\([^)]*\)\s*)?([A-Za-z_]\w*)/,
  /^type\s+([A-Za-z_]\w*)\s+(?:struct|interface)/,
  /^\s*(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?fn\s+([A-Za-z_]\w*)/,
  /^\s*(?:pub(?:\([^)]*\))?\s+)?(?:struct|enum|trait)\s+([A-Za-z_]\w*)/,
  /^\s*(?:public|private|protected|internal|open|final|static|\s)*(?:class|interface|struct|enum|protocol|object)\s+([A-Za-z_]\w*)/,
  /^\s*(?:public|private|internal|open|override|static|\s)*(?:func|fun)\s+([A-Za-z_]\w*)/,
  /^\s*(?:public\s+|private\s+|protected\s+)?(?:static\s+)?function\s+([A-Za-z_]\w*)/,
  /^\s*module\s+([A-Z]\w*)/,
];

// Short lowercase names (get, key, run, fmt) collide with ordinary words and link unrelated files.
const weak = (name) => name.length < 3 || (/^[a-z]+$/.test(name) && name.length < 6);

function collect(root, limit = 3000) {
  const files = [];
  const walk = (abs) => {
    let entries; try { entries = readdirSync(abs, { withFileTypes: true }); } catch { return; }
    for (const e of entries.sort((a, b) => a.name.localeCompare(b.name))) {
      if (files.length >= limit) return;
      if (e.name.startsWith('.') && e.name !== '.') continue;
      const p = join(abs, e.name);
      if (e.isDirectory()) { if (!SKIP.has(e.name)) walk(p); }
      else if (CODE.has(extname(e.name)) && !/\.(min|bundle)\.js$|\.d\.ts$/.test(e.name)) {
        try { if (statSync(p).size < 300_000) files.push(p); } catch { /* gone */ }
      }
    }
  };
  walk(root);
  return files;
}

/** Builds the map. Returns { text, files: n }. `budget` is in tokens (≈4 characters each). */
export function buildRepoMap(cwd, { budget = 2048, focus = '' } = {}) {
  const paths = collect(cwd);
  const files = paths.map((p) => {
    const text = readFileSync(p, 'utf8');
    const defs = [];
    text.split('\n').forEach((line, i) => {
      if (line.length > 400 || /^\s{5,}|^\t{2,}/.test(line)) return; // nested helpers are noise
      for (const re of DEFS) { const m = re.exec(line); if (m && !weak(m[1])) { defs.push({ name: m[1], line: i + 1 }); break; } }
    });
    return { rel: relative(cwd, p).split(sep).join('/'), text, defs };
  });
  // Which files define each name; names defined in many files (run, init, get…) say little and are skipped.
  const definers = new Map();
  files.forEach((f, i) => { for (const d of new Set(f.defs.map((x) => x.name))) (definers.get(d) || definers.set(d, []).get(d)).push(i); });
  for (const [k, v] of definers) if (v.length > 4) definers.delete(k);
  // Edges: file i uses a name file j defines.
  const out = files.map(() => new Map());
  const uses = new Map(); // name -> count of files using it
  files.forEach((f, i) => {
    const words = new Set(f.text.match(/[A-Za-z_$][\w$]{2,}/g) || []);
    for (const w of words) {
      const ds = definers.get(w);
      if (!ds) continue;
      for (const j of ds) if (j !== i) { out[i].set(j, (out[i].get(j) || 0) + 1); uses.set(w, (uses.get(w) || 0) + 1); }
    }
  });
  // PageRank, personalised towards files whose path matches `focus` when given.
  const n = files.length || 1, d = 0.85;
  const want = focus ? files.map((f) => (f.rel.toLowerCase().includes(focus.toLowerCase()) ? 1 : 0)) : null;
  const base = want && want.some(Boolean) ? want.map((x) => x / want.filter(Boolean).length) : files.map(() => 1 / n);
  const totals = out.map((m) => [...m.values()].reduce((a, b) => a + b, 0));
  let rank = base.slice();
  for (let it = 0; it < 25; it++) {
    const next = base.map((b) => (1 - d) * b);
    let dangling = 0;
    files.forEach((_, i) => {
      if (!totals[i]) { dangling += rank[i]; return; }
      for (const [j, w] of out[i]) next[j] += d * rank[i] * (w / totals[i]);
    });
    rank = next.map((x, j) => x + d * dangling * base[j]);
  }
  const order = files.map((f, i) => ({ f, r: rank[i] })).filter((x) => x.f.defs.length).sort((a, b) => b.r - a.r);
  const lines = [], max = budget * 4;
  let size = 0;
  for (const { f } of order) {
    const defs = f.defs.slice().sort((a, b) => (uses.get(b.name) || 0) - (uses.get(a.name) || 0)).slice(0, 12).sort((a, b) => a.line - b.line);
    const block = `${f.rel}\n` + defs.map((x) => `  ${x.line}: ${x.name}`).join('\n');
    if (size + block.length > max) break;
    lines.push(block); size += block.length + 1;
  }
  return { text: lines.join('\n') || '(код не найден)', files: files.length };
}
