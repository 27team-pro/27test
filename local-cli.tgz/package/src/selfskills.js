// Skills the agent writes itself, and the Curator that keeps them fresh.
//
// The agent saves what it learned on a task as a skill (SKILL.md, the same format as Claude Code skills) with the
// `skill_manage` tool: ~/.klinch/skills/<name> for every project, <project>/.klinch/skills/<name> for this one.
// Its skills carry `origin: agent` in the front matter; the agent may change or remove only those, never a skill
// the user wrote or one from .claude/, a plugin or the hub.
//
// Usage (how often and when each skill was loaded) is kept in ~/.klinch/skills-usage.json. The Curator moves an
// agent's skill nobody used for `days` (30 by default) to <skills>/.archive/<name>; `klinch skills restore <name>`
// brings it back. It runs by itself once a day at start, costs no tokens, and deletes nothing.
// `/curator` in the chat also asks the agent to merge overlapping skills and fix outdated ones.
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, renameSync, rmSync, statSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { frontMatter, loadSkills } from './skills.js';

const home = (env) => env.KLINCH_HOME || join(homedir(), '.klinch');
export const userSkillsDir = (env = process.env) => join(home(env), 'skills');
export const projectSkillsDir = (cwd) => join(cwd, '.klinch', 'skills');
const usagePath = (env) => join(home(env), 'skills-usage.json');
const DAY = 86_400_000;
export const MAX_BODY = 20_000;
export const STALE_DAYS = 30;

export const skillName = (s) => String(s || '').trim().toLowerCase().replace(/[^a-z0-9а-яё_-]+/gi, '-').replace(/^-+|-+$/g, '').slice(0, 64);
const oneLine = (s, n) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, n);
const isDir = (p) => { try { return statSync(p).isDirectory(); } catch { return false; } };

// A skill is read again in every later session and may be shared: keys and passwords never go into one.
const SECRET = /\b(kl_live_[\w-]{8,}|sk-[\w-]{16,}|sk-ant-[\w-]{10,}|gh[pousr]_[\w]{20,}|github_pat_\w{20,}|AKIA[0-9A-Z]{16}|xox[bpas]-[\w-]{10,}|AIza[\w-]{30,})|-----BEGIN [A-Z ]*PRIVATE KEY-----/;
export const hasSecret = (s) => SECRET.test(String(s || ''));

function readUsage(env) {
  try { const u = JSON.parse(readFileSync(usagePath(env), 'utf8')); return u && typeof u === 'object' ? u : {}; } catch { return {}; }
}
function writeUsage(u, env) {
  try { mkdirSync(home(env), { recursive: true }); writeFileSync(usagePath(env), JSON.stringify(u, null, 1) + '\n'); } catch { /* read-only home */ }
}

/** One more use of a skill (loaded by the agent or run as /name). */
export function noteUse(name, env = process.env, now = Date.now()) {
  const u = readUsage(env);
  u.skills ||= {};
  const r = (u.skills[name] ||= { uses: 0 });
  r.uses = (r.uses || 0) + 1;
  r.last = new Date(now).toISOString();
  writeUsage(u, env);
}

const text = (meta, body) => `---\n${Object.entries(meta).filter(([, v]) => v !== undefined && v !== '').map(([k, v]) => `${k}: ${v}`).join('\n')}\n---\n\n${body.trim()}\n`;

/** The skill's folder in one of the two places the agent writes to, with its parsed SKILL.md. */
function find(name, cwd, env) {
  for (const [scope, root] of [['project', projectSkillsDir(cwd)], ['user', userSkillsDir(env)]]) {
    if (!isDir(root)) continue;
    for (const d of readdirSync(root)) {
      if (d.startsWith('.')) continue;
      const file = join(root, d, 'SKILL.md');
      let t; try { t = readFileSync(file, 'utf8'); } catch { continue; }
      const { meta, body } = frontMatter(t);
      if (skillName(meta.name || d) === name) return { scope, root, dir: join(root, d), file, meta, body };
    }
  }
  return null;
}

/** Every skill the agent wrote, in both places: [{ name, scope, dir, meta, body }]. */
export function agentSkills(cwd, env = process.env) {
  const out = [];
  for (const [scope, root] of [['project', projectSkillsDir(cwd)], ['user', userSkillsDir(env)]]) {
    if (!isDir(root)) continue;
    for (const d of readdirSync(root).sort()) {
      if (d.startsWith('.')) continue;
      let t; try { t = readFileSync(join(root, d, 'SKILL.md'), 'utf8'); } catch { continue; }
      const { meta, body } = frontMatter(t);
      if (meta.origin === 'agent') out.push({ name: skillName(meta.name || d), scope, root, dir: join(root, d), meta, body });
    }
  }
  return out;
}

/**
 * create | update | delete | list for the agent's own skills. Returns a line for the model.
 * update keeps the rest of the skill when only one field is given; delete moves the skill to the archive.
 */
export function manageSkill({ action, name, description, body, scope }, { cwd, env = process.env, now = Date.now() } = {}) {
  if (action === 'list') {
    const list = agentSkills(cwd, env);
    if (!list.length) return 'Своих скиллов пока нет.';
    const usage = readUsage(env).skills || {};
    return list.map((s) => `- ${s.name} [${s.scope === 'project' ? 'проект' : 'общий'}] ${s.meta.description || ''} (использован ${usage[s.name]?.uses || 0} раз)`).join('\n');
  }
  const n = skillName(name);
  if (!n) throw new Error('Нужно имя скилла: латиница или кириллица, цифры, дефис');
  const found = find(n, cwd, env);
  // Any other skill of that name (.claude/, a plugin, the user's own) is the user's: the agent never shadows it.
  const other = loadSkills(cwd, env).find((x) => x.name === n && x.dir !== found?.dir);
  const today = new Date(now).toISOString().slice(0, 10);
  if (action === 'create' || action === 'update') {
    if ((found && found.meta.origin !== 'agent') || other) throw new Error(`Скилл ${n} написал пользователь (или он из плагина): его не меняю. Возьми другое имя.`);
    if (action === 'update' && !found) throw new Error(`Своего скилла ${n} нет. Создай его: action "create".`);
    if (action === 'create' && found) throw new Error(`Скилл ${n} уже есть. Поправь его: action "update".`);
    const desc = oneLine(description ?? found?.meta.description, 300);
    const b = String(body ?? found?.body ?? '').replace(/\r/g, '').trim();
    if (!desc) throw new Error('Нужно description: одна строка, когда применять скилл');
    if (!b) throw new Error('Нужно body: инструкция в Markdown');
    if (b.length > MAX_BODY) throw new Error(`Скилл длиннее ${MAX_BODY} символов: сократи`);
    if (hasSecret(desc + '\n' + b)) throw new Error('В скилле похоже на ключ или пароль: секреты в скиллы не сохраняются. Убери их.');
    const root = found ? found.root : (scope === 'project' ? projectSkillsDir(cwd) : userSkillsDir(env));
    const dir = found ? found.dir : join(root, n);
    mkdirSync(dir, { recursive: true });
    writeFileSync(join(dir, 'SKILL.md'), text({ name: n, description: desc, origin: 'agent', created: found?.meta.created || today, updated: today }, b));
    return `${found ? 'Обновил' : 'Сохранил'} скилл ${n} (${dir}). Он уже доступен через skill.`;
  }
  if (action === 'delete') {
    if (!found && other) throw new Error(`Скилл ${n} написал пользователь: удалить его может только он.`);
    if (!found) throw new Error(`Скилла ${n} нет`);
    if (found.meta.origin !== 'agent') throw new Error(`Скилл ${n} написал пользователь: удалить его может только он.`);
    archive(found, now);
    return `Скилл ${n} убран в архив (вернуть: klinch skills restore ${n}).`;
  }
  throw new Error('action: create, update, delete или list');
}

function archive(s, now) {
  const dest = join(s.root, '.archive', `${skillName(s.meta.name || s.dir.split(/[\\/]/).pop())}-${new Date(now).toISOString().slice(0, 10)}`);
  mkdirSync(join(s.root, '.archive'), { recursive: true });
  rmSync(dest, { recursive: true, force: true });
  renameSync(s.dir, dest);
  return dest;
}

/**
 * The Curator: the agent's skills not used for `days` go to the archive. `auto` runs at most once a day.
 * Returns the names moved.
 */
export function curate({ cwd, env = process.env, days = STALE_DAYS, now = Date.now(), auto = false } = {}) {
  const u = readUsage(env);
  if (auto && u.curated && now - Date.parse(u.curated) < DAY) return [];
  const moved = [];
  for (const s of agentSkills(cwd, env)) {
    const seen = [u.skills?.[s.name]?.last, s.meta.updated, s.meta.created].map((x) => Date.parse(x || '')).filter(Number.isFinite);
    const last = seen.length ? Math.max(...seen) : now;
    if (now - last > days * DAY) { archive(s, now); moved.push(s.name); }
  }
  u.curated = new Date(now).toISOString();
  writeUsage(u, env);
  return moved;
}

/** Archived skills of both places: [{ name, scope, dir }], newest first. */
export function archived(cwd, env = process.env) {
  const out = [];
  for (const [scope, root] of [['project', projectSkillsDir(cwd)], ['user', userSkillsDir(env)]]) {
    const a = join(root, '.archive');
    if (!isDir(a)) continue;
    for (const d of readdirSync(a)) out.push({ name: d.replace(/-\d{4}-\d{2}-\d{2}$/, ''), id: d, scope, dir: join(a, d), root });
  }
  return out.sort((x, y) => y.id.slice(-10).localeCompare(x.id.slice(-10)));
}

/** Puts an archived skill back (its use counts as today, so the Curator leaves it alone for a while). */
export function restore(name, { cwd, env = process.env, now = Date.now() } = {}) {
  const n = skillName(name);
  const a = archived(cwd, env).find((x) => x.name === n || x.id === name);
  if (!a) throw new Error(`В архиве нет скилла ${name}. Список: klinch skills archive`);
  const dest = join(a.root, a.name);
  if (existsSync(dest)) throw new Error(`Скилл ${a.name} уже есть`);
  renameSync(a.dir, dest);
  noteUse(a.name, env, now);
  return dest;
}

// The prompt of /curator: the agent reviews its own skills with skill_manage.
export const CURATOR_PROMPT = `Ты куратор своих скиллов. Вызови skill_manage с action "list", затем загрузи каждый свой скилл через skill и наведи порядок:
- скиллы, которые повторяют друг друга, объедини в один (update одного, delete остальных);
- устаревшие или неверные шаги исправь (update), проверив по проекту, если скилл о нём;
- скилл, который явно больше не нужен, удали (delete: он уйдёт в архив).
Скиллы пользователя не трогай. В конце коротко: что объединил, что поправил, что убрал.`;

/** `klinch skills [list | curate | archive | restore <name> | remove <name>]`. Returns lines to print. */
export function skillsCommand(argv, { cwd = process.cwd(), env = process.env, now = Date.now() } = {}) {
  const [sub, arg] = argv;
  if (!sub || sub === 'list' || sub === 'ls') {
    const all = loadSkills(cwd, env);
    if (!all.length) return ['Скиллов нет. Агент сохраняет их сам после непростых задач; свой скилл: .klinch/skills/<имя>/SKILL.md'];
    const mine = new Set(agentSkills(cwd, env).map((s) => s.name));
    const usage = readUsage(env).skills || {};
    return all.map((s) => `${s.name}${mine.has(s.name) ? ' [агент]' : ''}  ${s.description}${usage[s.name]?.uses ? `  (${usage[s.name].uses}×)` : ''}`);
  }
  if (sub === 'curate') {
    const moved = curate({ cwd, env, now, days: +arg > 0 ? +arg : STALE_DAYS });
    return [moved.length ? `В архив: ${moved.join(', ')}` : 'Все скиллы агента в ходу, убирать нечего.'];
  }
  if (sub === 'archive') {
    const a = archived(cwd, env);
    return a.length ? a.map((x) => `${x.name}  ${x.id.slice(-10)}  ${x.scope === 'project' ? 'проект' : 'общий'}`) : ['Архив пуст.'];
  }
  if (sub === 'restore') { if (!arg) throw new Error('klinch skills restore <имя>'); return [`Вернул скилл: ${restore(arg, { cwd, env, now })}`]; }
  if (sub === 'remove' || sub === 'rm') { if (!arg) throw new Error('klinch skills remove <имя>'); return [manageSkill({ action: 'delete', name: arg }, { cwd, env, now })]; }
  throw new Error('Команды: klinch skills list | curate [дней] | archive | restore <имя> | remove <имя>');
}
