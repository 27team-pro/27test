// Long-term memory and the standing goal, kept between sessions.
//
//   ~/.klinch/memory.md                         about you: preferences, how you like to work (every project)
//   ~/.klinch/projects/<folder id>/memory.md    about this project: commands, decisions, pitfalls
//   ~/.klinch/projects/<folder id>/goal.md      the project's standing goal (/goal)
//
// Both memories go into the system prompt. The agent adds to them itself with the `memory` tool when it learns
// something worth keeping; in the chat «# текст» saves a line to the project's memory, /memory shows them.
import { readFileSync, writeFileSync, mkdirSync, unlinkSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { join } from 'node:path';

const MAX = 12000;   // characters of one memory file that go into the prompt
const home = (env) => env.KLINCH_HOME || join(homedir(), '.klinch');
export const projectDir = (cwd, env = process.env) => join(home(env), 'projects', createHash('sha1').update(cwd).digest('hex').slice(0, 12));
export const memoryPath = (scope, cwd, env = process.env) => (scope === 'user' ? join(home(env), 'memory.md') : join(projectDir(cwd, env), 'memory.md'));
const goalPath = (cwd, env) => join(projectDir(cwd, env), 'goal.md');
const read = (p) => { try { return readFileSync(p, 'utf8'); } catch { return ''; } };
const write = (p, text) => { mkdirSync(join(p, '..'), { recursive: true, mode: 0o700 }); writeFileSync(p, text, { mode: 0o600 }); };

export const readMemory = (scope, cwd, env = process.env) => read(memoryPath(scope, cwd, env));

/** add (a line), replace (the line containing old → text), remove (the lines containing old), view. Returns a short report. */
export function editMemory({ action = 'add', scope = 'project', text = '', old = '' }, cwd, env = process.env) {
  const p = memoryPath(scope === 'user' ? 'user' : 'project', cwd, env);
  let cur = read(p);
  const line = String(text).replace(/\s+/g, ' ').trim();
  if (action === 'view') return cur.trim() || '(память пуста)';
  if (action === 'add') {
    if (!line) throw new Error('Пустой текст');
    if (cur.split('\n').some((l) => l.replace(/^- /, '').trim() === line)) return 'Уже есть в памяти';
    cur = (cur.trim() ? cur.replace(/\s*$/, '\n') : '') + `- ${line}\n`;
  } else if (action === 'replace' || action === 'remove') {
    if (!old || !cur.includes(old)) throw new Error('Такого текста в памяти нет');
    // The whole entry (line) that contains `old` is replaced or removed.
    const lines = cur.split('\n'), i = lines.findIndex((l) => l.includes(old));
    if (action === 'replace') lines[i] = `- ${line}`; else lines.splice(0, lines.length, ...lines.filter((l) => !l.includes(old)));
    cur = lines.join('\n');
  } else throw new Error('action: add, replace, remove, view');
  if (cur.length > MAX * 2) throw new Error('Память переполнена: объедини или удали старые записи (replace / remove)');
  write(p, cur);
  return `Память (${scope === 'user' ? 'о пользователе' : 'проекта'}) обновлена`;
}

export const readGoal = (cwd, env = process.env) => read(goalPath(cwd, env)).trim();
export function setGoal(cwd, text, env = process.env) {
  if (!text) { try { unlinkSync(goalPath(cwd, env)); } catch { /* none */ } return; }
  write(goalPath(cwd, env), String(text).trim() + '\n');
}

/** The memory and goal block for the system prompt ('' when there is nothing). */
export function memoryPrompt(cwd, env = process.env) {
  const user = readMemory('user', cwd, env).trim(), proj = readMemory('project', cwd, env).trim(), goal = readGoal(cwd, env);
  const parts = [];
  if (goal) parts.push(`# Постоянная цель проекта (задал пользователь, держи её в голове в каждой задаче)\n${goal}`);
  if (user) parts.push(`# Память: о пользователе\n${user.slice(-MAX)}`);
  if (proj) parts.push(`# Память: об этом проекте\n${proj.slice(-MAX)}`);
  return parts.join('\n\n');
}

export const MEMORY_NOTE = `
Память между сессиями: инструмент memory. Сохраняй туда без вопросов то, что пригодится в следующих разговорах: предпочтения пользователя (scope "user"), команды сборки и тестов, договорённости, решения и подводные камни проекта (scope "project"). Одна запись — одна короткая строка. Не сохраняй то, что видно из кода или git, временное и секреты (ключи, пароли). Устаревшую запись исправь через replace или удали через remove.`;

export const memoryTool = {
  name: 'memory',
  description: 'Долгая память между сессиями: add (добавить строку), replace (строку, где есть old, заменить на text), remove (строки с old), view. scope "project" (по умолчанию) — этот проект, "user" — о пользователе во всех проектах.',
  input_schema: { type: 'object', properties: {
    action: { type: 'string', enum: ['add', 'replace', 'remove', 'view'] }, scope: { type: 'string', enum: ['project', 'user'] },
    text: { type: 'string' }, old: { type: 'string', description: 'Для replace и remove: часть старой записи' } }, required: ['action'] },
  preview: ({ action, scope, text, old }) => `memory ${action}${scope === 'user' ? ' (о вас)' : ''}: ${String(text || old || '').slice(0, 100)}`,
  run: (input, { root, cwd, env }) => editMemory(input, root || cwd, env || process.env),
};
