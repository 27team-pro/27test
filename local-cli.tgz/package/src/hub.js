// The hub: skills and plugins installed with one command (`klinch hub install <id>`) or one click in the cabinet.
//
// Two indexes, both served by the site the key works with:
//   <site>/code/hub.json             Klinch's own skills and plugins (built from code/src/extensions/catalog.ts)
//   <site>/code/skills-library.json  ~900 open SKILL.md skills from GitHub (MIT / Apache-2.0), pinned to a commit
// A library skill's files come through <site>/v1/extensions/library/raw at that commit.
//
// Installed skills go to ~/.klinch/skills/<id>, plugins to ~/.klinch/plugins/<id> (the Claude Code plugin layout:
// .claude-plugin/plugin.json, skills/, commands/), each with a .hub.json mark: { id, from: "hub" | "cabinet" }.
// Sync: what is turned on in the cabinet (Расширения → Скиллы, Плагины) is installed at start, and what was
// installed from the cabinet and turned off there is removed. Things the user installed by hand stay.
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, rmSync, statSync, renameSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';

const home = (env) => env.KLINCH_HOME || join(homedir(), '.klinch');
const dirs = (env) => ({ skill: join(home(env), 'skills'), plugin: join(home(env), 'plugins') });
const MARK = '.hub.json';
const ID = /^[a-z0-9][a-z0-9_-]{0,63}$/;
const isDir = (p) => { try { return statSync(p).isDirectory(); } catch { return false; } };
const readJson = (p) => { try { return JSON.parse(readFileSync(p, 'utf8')); } catch { return null; } };
const oneLine = (s, n = 300) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, n);
const ru = (l) => (l && typeof l === 'object' ? l.ru || l.en || '' : String(l || ''));
const skillMd = (name, description, body) => `---\nname: ${name}\ndescription: ${oneLine(description)}\n---\n\n${String(body || '').trim()}\n`;
// A library file path inside the skill's folder: plain relative paths only.
const safeRel = (p) => typeof p === 'string' && p.length <= 300 && /^[\w.@+-]+(\/[\w.@+-]+)*$/.test(p) && !p.split('/').some((x) => x === '.' || x === '..');

export function createHub({ baseUrl, apiKey, env = process.env, fetchImpl = fetch, timeout = 15000 }) {
  const get = async (path, auth = false) => {
    const r = await fetchImpl(baseUrl + path, { headers: auth ? { authorization: 'Bearer ' + apiKey, 'x-klinch-client': 'klinch-code' } : {}, signal: AbortSignal.timeout(timeout) });
    if (!r.ok) throw new Error(r.status === 401 ? 'Ключ не принят: klinch login' : `Хаб недоступен (HTTP ${r.status})`);
    return r;
  };
  let index = null;
  /** Both indexes: { skills: [{ id, name, desc, kind, ... }], plugins: [...] }. */
  async function load() {
    if (index) return index;
    const [own, lib] = await Promise.all([get('/code/hub.json').then((r) => r.json()), get('/code/skills-library.json').then((r) => r.json()).catch(() => null)]);
    const skills = (own.skills || []).map((s) => ({ id: s.id, name: ru(s.name), desc: ru(s.desc), when: s.when, body: s.body, src: 'klinch' }));
    for (const s of lib?.skills || []) {
      const source = lib.sources?.[s.s];
      if (source) skills.push({ id: s.id, name: s.n, desc: s.d, cat: s.c, lib: { code: source.code, path: s.p, files: s.f || [] }, src: source.repo, license: source.license });
    }
    const plugins = (own.plugins || []).map((p) => ({ id: p.id, name: ru(p.name), desc: ru(p.desc), skills: p.skills || [], connectors: p.connectors || [], commands: p.commands || [] }));
    return (index = { skills, plugins });
  }

  /** Installed hub items: [{ id, kind, from, dir }]. */
  function installed() {
    const out = [];
    for (const [kind, root] of Object.entries(dirs(env))) {
      if (!isDir(root)) continue;
      for (const d of readdirSync(root)) {
        const m = readJson(join(root, d, MARK));
        if (m?.id) out.push({ id: m.id, kind, from: m.from || 'hub', dir: join(root, d) });
      }
    }
    return out;
  }

  const mark = (dir, id, from) => writeFileSync(join(dir, MARK), JSON.stringify({ id, from, at: new Date().toISOString() }) + '\n');

  async function writeSkill(dir, s) {
    mkdirSync(dir, { recursive: true });
    if (s.lib) {
      const base = s.lib.path ? s.lib.path + '/' : '';
      const raw = async (f) => (await get(`/v1/extensions/library/raw?src=${encodeURIComponent(s.lib.code)}&path=${encodeURIComponent(base + f)}`, true)).text();
      writeFileSync(join(dir, 'SKILL.md'), await raw('SKILL.md'));
      for (const f of s.lib.files.filter(safeRel).slice(0, 40)) {
        try { const t = await raw(f); mkdirSync(join(dir, ...f.split('/').slice(0, -1)), { recursive: true }); writeFileSync(join(dir, ...f.split('/')), t); } catch { /* a missing reference is not fatal */ }
      }
    } else writeFileSync(join(dir, 'SKILL.md'), skillMd(s.id, s.when ? `${s.desc} Когда: ${s.when}` : s.desc, s.body));
  }

  /** Installs a skill or plugin by id. Returns lines to print. */
  async function install(id, from = 'hub') {
    if (!ID.test(String(id || ''))) throw new Error('klinch hub install <id> (найти: klinch hub search <слово>)');
    const idx = await load();
    const plugin = idx.plugins.find((p) => p.id === id), skill = !plugin && idx.skills.find((s) => s.id === id);
    if (!plugin && !skill) throw new Error(`В хабе нет ${id}. Найти: klinch hub search <слово>`);
    const root = dirs(env)[plugin ? 'plugin' : 'skill'], dir = join(root, id);
    const prev = readJson(join(dir, MARK));
    if (existsSync(dir) && !prev) throw new Error(`${dir} уже есть и поставлен не из хаба: не трогаю`);
    const tmp = join(root, `.new-${id}-${Date.now()}`);
    try {
      if (skill) await writeSkill(tmp, skill);
      else {
        mkdirSync(join(tmp, '.claude-plugin'), { recursive: true });
        writeFileSync(join(tmp, '.claude-plugin', 'plugin.json'), JSON.stringify({ name: plugin.id, description: plugin.desc, version: 'hub' }, null, 2) + '\n');
        for (const sid of plugin.skills) { const s = idx.skills.find((x) => x.id === sid); if (s) await writeSkill(join(tmp, 'skills', sid), s); }
        if (plugin.commands.length) mkdirSync(join(tmp, 'commands'), { recursive: true });
        for (const c of plugin.commands) if (ID.test(c.name)) writeFileSync(join(tmp, 'commands', `${c.name}.md`), `---\ndescription: ${oneLine(ru(c.desc), 120)}\n---\n${String(c.prompt).split('{input}').join('$ARGUMENTS')}\n`);
      }
      mark(tmp, id, prev?.from === 'hub' ? 'hub' : from);
      rmSync(dir, { recursive: true, force: true });
      mkdirSync(root, { recursive: true });
      renameSync(tmp, dir);
    } finally { rmSync(tmp, { recursive: true, force: true }); }
    const out = [`${plugin ? 'Плагин' : 'Скилл'} ${plugin ? plugin.name : skill.name} установлен (${dir}).`];
    if (plugin?.connectors.length) out.push(`Ему пригодятся сервисы: ${plugin.connectors.join(', ')}. Подключить: klinch mcp add <имя> -- <команда> или в кабинете.`);
    if (skill?.license) out.push(`Источник: github.com/${skill.src} (${skill.license}).`);
    return out;
  }

  function remove(id) {
    const it = installed().find((x) => x.id === id);
    if (!it) throw new Error(`${id} не установлен из хаба. Список: klinch hub list`);
    rmSync(it.dir, { recursive: true, force: true });
    return [`Удалён ${id}.`];
  }

  async function search(q = '', limit = 30) {
    const idx = await load();
    const words = String(q).toLowerCase().split(/\s+/).filter(Boolean);
    const hit = (x) => words.every((w) => `${x.id} ${x.name} ${x.desc}`.toLowerCase().includes(w));
    return [...idx.plugins.filter(hit).map((p) => ({ ...p, kind: 'plugin' })), ...idx.skills.filter(hit).map((s) => ({ ...s, kind: 'skill' }))].slice(0, limit);
  }

  /** Installs what is turned on in the cabinet, removes what was installed from there and turned off. */
  async function sync() {
    const r = await (await get('/v1/code/hub', true)).json();
    const want = new Map((r.items || []).filter((x) => ID.test(String(x.id || ''))).map((x) => [x.id, x]));
    const have = installed();
    const added = [], removed = [];
    for (const it of have) if (it.from === 'cabinet' && !want.has(it.id)) { rmSync(it.dir, { recursive: true, force: true }); removed.push(it.id); }
    for (const [id, x] of want) {
      const cur = have.find((h) => h.id === id);
      if (x.custom) {
        // The user's own skill from the cabinet: its text comes with the list; rewritten when it changed.
        const dir = join(dirs(env).skill, id);
        if (existsSync(dir) && !cur) continue;
        const text = skillMd(oneLine(x.name, 60).toLowerCase().replace(/[^a-z0-9а-яё_-]+/gi, '-').replace(/^-+|-+$/g, '') || id, x.description || x.name, x.instructions);
        if (cur && readFileSync(join(dir, 'SKILL.md'), 'utf8') === text) continue;
        mkdirSync(dir, { recursive: true }); writeFileSync(join(dir, 'SKILL.md'), text); mark(dir, id, 'cabinet');
        added.push(id);
      } else if (!cur) {
        try { await install(id, 'cabinet'); added.push(id); } catch { /* not in the hub (a cabinet-only skill) */ }
      }
    }
    return { added, removed };
  }

  return { load, installed, install, remove, search, sync };
}

/** `klinch hub [search <слова> | install <id> | remove <id> | list | sync]`. Returns lines to print. */
export async function hubCommand(argv, hub) {
  const [sub, ...rest] = argv;
  const arg = rest.join(' ');
  if (sub === 'install' || sub === 'add') return hub.install(rest[0]);
  if (sub === 'remove' || sub === 'rm') return hub.remove(rest[0]);
  if (sub === 'list' || sub === 'ls') {
    const l = hub.installed();
    return l.length ? l.map((x) => `${x.id}  ${x.kind === 'plugin' ? 'плагин' : 'скилл'}${x.from === 'cabinet' ? '  (из кабинета)' : ''}`) : ['Из хаба ничего не установлено. Найти: klinch hub search <слово>'];
  }
  if (sub === 'sync') {
    const { added, removed } = await hub.sync();
    return [added.length || removed.length ? `Из кабинета: ${added.length ? 'поставлено ' + added.join(', ') : ''}${added.length && removed.length ? '; ' : ''}${removed.length ? 'убрано ' + removed.join(', ') : ''}` : 'Всё как в кабинете.'];
  }
  if (sub && sub !== 'search' && sub !== 'find') throw new Error('Команды: klinch hub search <слова> | install <id> | remove <id> | list | sync');
  const q = sub ? arg : '';
  const found = await hub.search(q, q ? 30 : 15);
  if (!found.length) return [`Ничего не нашлось по «${q}».`];
  return [...found.map((x) => `${x.id}  ${x.kind === 'plugin' ? '[плагин] ' : ''}${x.name}  ${oneLine(x.desc, 110)}`), '', 'Поставить: klinch hub install <id>. Или включите в кабинете (Расширения), и скилл придёт сам при запуске.'];
}
