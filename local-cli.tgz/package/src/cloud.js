// `klinch cloud …`: cloud agents (server/cloudagents.js). The task runs on the server with the key's balance and works
// on the GitHub repository through the API: the terminal (and the computer) can be closed, the agent opens the pull
// request by itself. Here: start, list, follow the log, stop, send a follow-up, connect GitHub, set up the webhook.
import { execFileSync } from 'node:child_process';

export const CLOUD_HELP = `Облачные агенты: задача выполняется на сервере, компьютер можно выключить, в конце агент сам открывает pull request.

  klinch cloud "задача" [--repo владелец/репо] [--base ветка] [-m модель] [--follow]
  klinch cloud list                 последние агенты
  klinch cloud log <id> [--follow]  что агент делает
  klinch cloud say <id> "текст"      ещё одно поручение тому же агенту (новый коммит в тот же PR)
  klinch cloud stop <id>            остановить
  klinch cloud github-token         передать серверу токен GitHub (из GITHUB_TOKEN или gh auth token)
  klinch cloud webhook [-m модель] [--new]  адрес и секрет вебхука: комментарий «/agent задача» в issue или PR запускает агента

Репозиторий по умолчанию: origin текущей папки. Изменения, которых нет на GitHub, агент не видит.`;

const STATUS = { queued: 'в очереди', running: 'работает', done: 'готово', failed: 'ошибка', stopped: 'остановлен' };
const ERR = {
  github_not_connected: 'GitHub не подключён: klinch cloud github-token (или «Подключить GitHub» в кабинете).',
  repo_not_found: 'Репозиторий не найден или у токена GitHub нет к нему доступа.',
  no_push: 'У токена GitHub нет права записи в этот репозиторий.',
  too_many: 'Уже работают 3 агента: дождитесь одного или остановите его.',
  invalid_repo: 'Укажите репозиторий: --repo владелец/репо.',
  prompt_required: 'Напишите задачу.',
  running: 'Агент ещё работает: дождитесь конца или остановите его.',
  not_found: 'Нет такого агента.',
  token_rejected: 'GitHub не принял токен.',
};

/** owner/name of a GitHub remote URL (https or ssh), or null. */
export function repoOf(url) {
  const m = /github\.com[:/]+([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+?)(?:\.git)?\/?$/.exec(String(url || '').trim());
  return m ? `${m[1]}/${m[2]}` : null;
}

/** Cloud-agent flags out of the arguments: { text, repo, base, model, follow }. */
export function cloudArgs(args) {
  const o = { rest: [], repo: null, base: null, model: null, follow: false };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--repo') o.repo = args[++i];
    else if (a === '--base' || a === '--branch') o.base = args[++i];
    else if (a === '-m' || a === '--model') o.model = args[++i];
    else if (a === '-f' || a === '--follow') o.follow = true;
    else o.rest.push(a);
  }
  return o;
}

const git = (args, cwd) => { try { return execFileSync('git', args, { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim(); } catch { return ''; } };

export function createCloud({ baseUrl, apiKey, fetchImpl = fetch, out = (s) => process.stdout.write(s), cwd = process.cwd(), env = process.env, sleep = (ms) => new Promise((r) => setTimeout(r, ms)) }) {
  const call = async (method, path, body) => {
    const r = await fetchImpl(baseUrl + '/api' + path, { method, headers: { authorization: 'Bearer ' + apiKey, 'content-type': 'application/json', 'x-klinch-client': 'klinch-code' }, body: body ? JSON.stringify(body) : undefined });
    let j = null; try { j = await r.json(); } catch { /* empty */ }
    if (!r.ok) throw new Error(ERR[j?.error] || j?.message || j?.error || `HTTP ${r.status}`);
    return j;
  };
  const cabinet = (id) => `${baseUrl.replace(/\/+$/, '')}/console/cloud${id ? '?agent=' + id : ''}`;
  const line = (a) => `#${a.id}  ${(STATUS[a.status] || a.status).padEnd(10)} ${a.repo}  ${a.title}${a.pr_url ? '  ' + a.pr_url : ''}`;
  const when = (t) => new Date(t).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  const show = (l) => {
    const head = l.kind === 'tool' || l.kind === 'tool-error' ? '  · ' : l.kind === 'error' ? '  ✗ ' : l.kind === 'done' ? '  ✓ ' : '  ';
    out(`${when(l.t)}${head}${l.text}${l.url ? '  ' + l.url : ''}\n`);
  };

  async function follow(id) {
    let seen = 0;
    for (;;) {
      const a = await call('GET', `/cloud-agents/${id}`);
      for (const l of a.log.slice(seen)) show(l);
      seen = a.log.length;
      if (!['queued', 'running'].includes(a.status)) { out(`${STATUS[a.status] || a.status}${a.error ? ': ' + a.error : ''}\n`); return a; }
      await sleep(5000);
    }
  }

  return {
    follow,
    async run(args, defaults = {}) {
      const [sub, ...rest] = args;
      if (!sub || sub === 'help' || sub === '--help' || sub === '-h') return out(CLOUD_HELP + '\n');
      if (sub === 'list' || sub === 'ls') {
        const r = await call('GET', '/cloud-agents');
        if (!r.agents.length) return out('Облачных агентов ещё нет: klinch cloud "задача"\n');
        for (const a of r.agents.slice(0, 20)) out(line(a) + '\n');
        return;
      }
      if (sub === 'log' || sub === 'logs') {
        const o = cloudArgs(rest);
        const id = +o.rest[0];
        if (!id) throw new Error('klinch cloud log <id>');
        if (o.follow) return void await follow(id);
        const a = await call('GET', `/cloud-agents/${id}`);
        out(line(a) + '\n'); for (const l of a.log) show(l);
        return;
      }
      if (sub === 'stop') {
        const id = +rest[0]; if (!id) throw new Error('klinch cloud stop <id>');
        await call('POST', `/cloud-agents/${id}/stop`); return out(`#${id} остановлен\n`);
      }
      if (sub === 'say' || sub === 'message') {
        const o = cloudArgs(rest);
        const id = +o.rest[0], text = o.rest.slice(1).join(' ').trim();
        if (!id || !text) throw new Error('klinch cloud say <id> "текст"');
        await call('POST', `/cloud-agents/${id}/message`, { text });
        out(`#${id} снова в работе: ${cabinet(id)}\n`);
        if (o.follow) await follow(id);
        return;
      }
      if (sub === 'github-token') {
        const token = (env.GITHUB_TOKEN || env.GH_TOKEN || '').trim() || (() => { try { return execFileSync('gh', ['auth', 'token'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim(); } catch { return ''; } })();
        if (!token) throw new Error('Нет токена: задайте GITHUB_TOKEN или войдите в gh (gh auth login).');
        const r = await call('PUT', '/github/token', { token });
        return out(`GitHub подключён: ${r.login}\n`);
      }
      if (sub === 'webhook') {
        const o = cloudArgs(rest);
        const r = await call('POST', '/cloud-agents/github-hook', { model: o.model || defaults.model, ...(o.rest.includes('--new') ? { rotate: true } : {}) });
        return out([
          'Вебхук GitHub (репозиторий → Settings → Webhooks → Add webhook):',
          `  Payload URL:   ${r.url}`,
          '  Content type:  application/json',
          `  Secret:        ${r.secret}`,
          '  Events:        Let me select individual events → Issue comments',
          `Потом комментарий «/agent задача» в issue или pull request запускает агента (модель ${r.model}). Пишут только владелец, участники и коллабораторы.`,
          'Новые адрес и секрет: klinch cloud webhook --new (старый вебхук перестанет работать).', '',
        ].join('\n'));
      }
      // Anything else is the task itself.
      const o = cloudArgs(args);
      const prompt = o.rest.join(' ').trim();
      if (!prompt) throw new Error('Напишите задачу: klinch cloud "задача"');
      const repo = o.repo || repoOf(git(['remote', 'get-url', 'origin'], cwd));
      if (!repo) throw new Error(ERR.invalid_repo);
      let base = o.base;
      // The current branch, when it is on GitHub: the agent starts from it.
      if (!base && repoOf(git(['remote', 'get-url', 'origin'], cwd)) === repo) {
        const up = git(['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}'], cwd);
        if (up.startsWith('origin/')) base = up.slice(7);
        const ahead = up ? git(['rev-list', '--count', '@{u}..HEAD'], cwd) : '';
        if (+ahead > 0) out(`Внимание: ${ahead} коммит(ов) не отправлены на GitHub, агент их не увидит.\n`);
      }
      const a = await call('POST', '/cloud-agents', { repo, prompt, model: o.model || defaults.model, ...(base ? { base } : {}), source: 'cli' });
      out(`#${a.id} в очереди: ${a.repo} (${a.base} → ${a.branch})\nСледить: klinch cloud log ${a.id} --follow, или в кабинете: ${cabinet(a.id)}\n`);
      if (o.follow) await follow(a.id);
    },
  };
}
