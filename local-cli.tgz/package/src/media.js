// The agent's results as files and pictures:
//   generate_image  draws a picture (or changes one) on the Klinch balance and saves it in the project;
//   make_file       a deliverable without dependencies: chart (SVG, or PNG/PDF through the browser), table (CSV, XLSX),
//                   document (HTML, or PDF through the browser) from Markdown;
//   canvas          a live page beside the terminal (charts, diagrams in Mermaid, tables, any HTML), updated in place.
import { writeFileSync, mkdirSync, readFileSync, existsSync, rmSync, mkdtempSync } from 'node:fs';
import { createServer } from 'node:http';
import { spawn } from 'node:child_process';
import { tmpdir } from 'node:os';
import { dirname, extname, join, relative } from 'node:path';
import { safePath } from './tools.js';
import { findBrowser } from './browser.js';
import { openBrowser } from './local.js';

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const PALETTE = ['#111111', '#888888', '#2f6fde', '#d9472b', '#2a9d6a', '#c08a00', '#7a4fd1', '#555555'];

// ---------------------------------------------------------------- charts (SVG)
const num = (v) => (Number.isFinite(+v) ? +v : 0);
const nice = (max) => { if (max <= 0) return 1; const p = 10 ** Math.floor(Math.log10(max)); return Math.ceil(max / p / (max / p > 5 ? 2 : 1)) * p * (max / p > 5 ? 2 : 1); };
const short = (n) => (Math.abs(n) >= 1e6 ? `${+(n / 1e6).toFixed(1)}M` : Math.abs(n) >= 1e3 ? `${+(n / 1e3).toFixed(1)}K` : `${+n.toFixed(2)}`);

/** { type: bar|line|pie, title, labels[], series[{ name, values[] }] } → SVG text. */
export function chartSvg(spec = {}) {
  const W = 800, H = 480, type = ['bar', 'line', 'pie'].includes(spec.type) ? spec.type : 'bar';
  const labels = (spec.labels || []).map(String).slice(0, 60);
  const series = (spec.series || []).slice(0, 8).map((s, i) => ({ name: String(s.name ?? `ряд ${i + 1}`), values: (s.values || []).map(num), color: s.color || PALETTE[i % PALETTE.length] }));
  if (!labels.length || !series.length) throw new Error('Для графика нужны labels и series (values по числу labels)');
  const head = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" font-family="Inter, -apple-system, Segoe UI, Arial, sans-serif" font-size="12"><rect width="100%" height="100%" fill="#fff"/>`
    + (spec.title ? `<text x="24" y="32" font-size="18" font-weight="600" fill="#111">${esc(spec.title)}</text>` : '');
  const legend = series.length > 1 || type === 'pie'
    ? (type === 'pie' ? labels.map((l, i) => ({ name: l, color: PALETTE[i % PALETTE.length] })) : series).slice(0, 12)
      .map((s, i) => `<rect x="${24 + i * 120}" y="${H - 22}" width="10" height="10" fill="${s.color}"/><text x="${40 + i * 120}" y="${H - 13}" fill="#444">${esc(String(s.name).slice(0, 16))}</text>`).join('')
    : '';
  if (type === 'pie') {
    const vals = series[0].values.slice(0, labels.length), total = vals.reduce((a, b) => a + Math.max(0, b), 0) || 1;
    const cx = W / 2, cy = H / 2 + 6, r = 170;
    let a = -Math.PI / 2, parts = '';
    vals.forEach((v, i) => {
      const da = (Math.max(0, v) / total) * Math.PI * 2, b = a + da;
      const [x1, y1, x2, y2] = [cx + r * Math.cos(a), cy + r * Math.sin(a), cx + r * Math.cos(b), cy + r * Math.sin(b)];
      parts += da >= Math.PI * 2 - 1e-9 ? `<circle cx="${cx}" cy="${cy}" r="${r}" fill="${PALETTE[i % PALETTE.length]}"/>`
        : `<path d="M${cx},${cy} L${x1.toFixed(1)},${y1.toFixed(1)} A${r},${r} 0 ${da > Math.PI ? 1 : 0} 1 ${x2.toFixed(1)},${y2.toFixed(1)} Z" fill="${PALETTE[i % PALETTE.length]}" stroke="#fff" stroke-width="2"/>`;
      const m = a + da / 2;
      if (da > 0.25) parts += `<text x="${(cx + r * 0.65 * Math.cos(m)).toFixed(1)}" y="${(cy + r * 0.65 * Math.sin(m)).toFixed(1)}" fill="#fff" text-anchor="middle" font-weight="600">${Math.round((v / total) * 100)}%</text>`;
      a = b;
    });
    return head + parts + legend + '</svg>';
  }
  const L = 64, R = 24, T = spec.title ? 56 : 24, B = series.length > 1 ? 70 : 48;
  const pw = W - L - R, ph = H - T - B;
  const all = series.flatMap((s) => s.values);
  const max = nice(Math.max(0, ...all)), min = Math.min(0, ...all);
  const y = (v) => T + ph - ((v - min) / (max - min || 1)) * ph;
  let g = '';
  for (let i = 0; i <= 4; i++) { const v = min + ((max - min) * i) / 4; g += `<line x1="${L}" x2="${W - R}" y1="${y(v).toFixed(1)}" y2="${y(v).toFixed(1)}" stroke="#e5e5e5"/><text x="${L - 8}" y="${(y(v) + 4).toFixed(1)}" text-anchor="end" fill="#888">${short(v)}</text>`; }
  const step = pw / labels.length, every = Math.ceil(labels.length / 16);
  labels.forEach((l, i) => { if (i % every === 0) g += `<text x="${(L + step * (i + 0.5)).toFixed(1)}" y="${T + ph + 18}" text-anchor="middle" fill="#666">${esc(l.slice(0, 12))}</text>`; });
  if (type === 'bar') {
    const bw = Math.max(2, (step * 0.75) / series.length);
    series.forEach((s, k) => s.values.slice(0, labels.length).forEach((v, i) => {
      const x = L + step * i + step * 0.125 + bw * k, top = y(Math.max(v, 0)), h = Math.abs(y(v) - y(0));
      g += `<rect x="${x.toFixed(1)}" y="${top.toFixed(1)}" width="${(bw - 1).toFixed(1)}" height="${h.toFixed(1)}" fill="${s.color}"/>`;
    }));
  } else {
    for (const s of series) {
      const pts = s.values.slice(0, labels.length).map((v, i) => `${(L + step * (i + 0.5)).toFixed(1)},${y(v).toFixed(1)}`);
      g += `<polyline points="${pts.join(' ')}" fill="none" stroke="${s.color}" stroke-width="2"/>` + pts.map((p) => `<circle cx="${p.split(',')[0]}" cy="${p.split(',')[1]}" r="3" fill="${s.color}"/>`).join('');
    }
  }
  return head + `<line x1="${L}" x2="${W - R}" y1="${y(0).toFixed(1)}" y2="${y(0).toFixed(1)}" stroke="#999"/>` + g + legend + '</svg>';
}

// ---------------------------------------------------------------- tables (CSV, XLSX)
export function toCsv(columns, rows) {
  const cell = (v) => { const s = String(v ?? ''); return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  return '﻿' + [columns, ...rows].map((r) => r.map(cell).join(',')).join('\r\n') + '\r\n';
}

const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = (b) => { let c = 0xffffffff; for (const x of b) c = CRC[(c ^ x) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };

/** A zip without compression: [{ name, data }] → Buffer (enough for XLSX, read by Excel, Numbers, Sheets). */
export function zipStore(files) {
  const parts = [], central = [];
  let off = 0;
  for (const f of files) {
    const name = Buffer.from(f.name), data = Buffer.isBuffer(f.data) ? f.data : Buffer.from(f.data), crc = crc32(data);
    const h = Buffer.alloc(30); h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt32LE(crc, 14); h.writeUInt32LE(data.length, 18); h.writeUInt32LE(data.length, 22); h.writeUInt16LE(name.length, 26);
    const c = Buffer.alloc(46); c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x0800, 8); c.writeUInt32LE(crc, 16); c.writeUInt32LE(data.length, 20); c.writeUInt32LE(data.length, 24); c.writeUInt16LE(name.length, 28); c.writeUInt32LE(off, 42);
    parts.push(h, name, data); central.push(c, name);
    off += 30 + name.length + data.length;
  }
  const cd = Buffer.concat(central), e = Buffer.alloc(22);
  e.writeUInt32LE(0x06054b50, 0); e.writeUInt16LE(files.length, 8); e.writeUInt16LE(files.length, 10); e.writeUInt32LE(cd.length, 12); e.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cd, e]);
}

const colName = (i) => { let s = ''; for (i++; i > 0; i = Math.floor((i - 1) / 26)) s = String.fromCharCode(65 + ((i - 1) % 26)) + s; return s; };
/** One-sheet XLSX: a bold header row, numbers stay numbers. */
export function toXlsx(columns, rows, sheet = 'Лист1') {
  const x = (s) => esc(s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '');
  const cell = (v, r, c, bold) => {
    const ref = colName(c) + (r + 1);
    if (typeof v === 'number' && Number.isFinite(v)) return `<c r="${ref}"><v>${v}</v></c>`;
    return `<c r="${ref}" t="inlineStr"${bold ? ' s="1"' : ''}><is><t xml:space="preserve">${x(v ?? '')}</t></is></c>`;
  };
  const data = [columns, ...rows].map((row, r) => `<row r="${r + 1}">${row.map((v, c) => cell(v, r, c, r === 0)).join('')}</row>`).join('');
  const X = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
  return zipStore([
    { name: '[Content_Types].xml', data: `${X}<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>` },
    { name: '_rels/.rels', data: `${X}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>` },
    { name: 'xl/workbook.xml', data: `${X}<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${x(String(sheet).slice(0, 31))}" sheetId="1" r:id="rId1"/></sheets></workbook>` },
    { name: 'xl/_rels/workbook.xml.rels', data: `${X}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>` },
    { name: 'xl/styles.xml', data: `${X}<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="1"><fill><patternFill patternType="none"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="2"><xf fontId="0"/><xf fontId="1" applyFont="1"/></cellXfs></styleSheet>` },
    { name: 'xl/worksheets/sheet1.xml', data: `${X}<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${data}</sheetData></worksheet>` },
  ]);
}

// ---------------------------------------------------------------- documents (Markdown → HTML / PDF)
const inline = (s) => esc(s).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/(^|[^*])\*([^*\s][^*]*)\*/g, '$1<i>$2</i>').replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, '<a href="$2">$1</a>');

/** A small Markdown subset: headings, lists, tables, code blocks, quotes, paragraphs. */
export function markdownHtml(md) {
  const lines = String(md || '').replace(/\r/g, '').split('\n'), out = [];
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (/^```/.test(l)) { const buf = []; while (++i < lines.length && !/^```/.test(lines[i])) buf.push(lines[i]); out.push(`<pre><code>${esc(buf.join('\n'))}</code></pre>`); continue; }
    if (/^#{1,4}\s/.test(l)) { const n = l.match(/^#+/)[0].length; out.push(`<h${n}>${inline(l.slice(n).trim())}</h${n}>`); continue; }
    if (/^\s*\|/.test(l) && /^\s*\|?\s*:?-{2,}/.test(lines[i + 1] || '')) {
      const row = (r) => r.trim().replace(/^\||\|$/g, '').split('|').map((x) => x.trim());
      const head = row(l); i++;
      const body = [];
      while (i + 1 < lines.length && /^\s*\|/.test(lines[i + 1])) body.push(row(lines[++i]));
      out.push(`<table><thead><tr>${head.map((h) => `<th>${inline(h)}</th>`).join('')}</tr></thead><tbody>${body.map((r) => `<tr>${r.map((c) => `<td>${inline(c)}</td>`).join('')}</tr>`).join('')}</tbody></table>`);
      continue;
    }
    if (/^\s*([-*]|\d+\.)\s/.test(l)) {
      const ordered = /^\s*\d+\./.test(l), items = [];
      for (; i < lines.length && /^\s*([-*]|\d+\.)\s/.test(lines[i]); i++) items.push(`<li>${inline(lines[i].replace(/^\s*([-*]|\d+\.)\s/, ''))}</li>`);
      i--; out.push(`<${ordered ? 'ol' : 'ul'}>${items.join('')}</${ordered ? 'ol' : 'ul'}>`); continue;
    }
    if (/^>\s?/.test(l)) { out.push(`<blockquote>${inline(l.replace(/^>\s?/, ''))}</blockquote>`); continue; }
    if (/^\s*(---|\*\*\*)\s*$/.test(l)) { out.push('<hr>'); continue; }
    if (!l.trim()) continue;
    const para = [l];
    while (i + 1 < lines.length && lines[i + 1].trim() && !/^(#{1,4}\s|```|\s*[-*]\s|\s*\d+\.\s|>|\s*\|)/.test(lines[i + 1])) para.push(lines[++i]);
    out.push(`<p>${inline(para.join(' '))}</p>`);
  }
  return out.join('\n');
}

const DOC_CSS = `body{font:15px/1.55 Inter,-apple-system,"Segoe UI",Arial,sans-serif;color:#111;max-width:760px;margin:40px auto;padding:0 24px}
h1,h2,h3,h4{line-height:1.25;margin:1.4em 0 .5em}h1{font-size:28px}h2{font-size:21px}h3{font-size:17px}
table{border-collapse:collapse;width:100%;margin:1em 0}th,td{border:1px solid #ddd;padding:6px 10px;text-align:left}th{background:#f5f5f5}
code{font:13px ui-monospace,Menlo,Consolas,monospace;background:#f3f3f3;padding:1px 4px}pre{background:#f6f6f6;padding:12px;overflow:auto}pre code{background:none;padding:0}
blockquote{margin:1em 0;padding-left:12px;border-left:3px solid #ccc;color:#555}img,svg{max-width:100%;height:auto}@page{margin:18mm}`;

export const htmlPage = (title, body, extra = '') => `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title || 'Документ')}</title><style>${DOC_CSS}</style>${extra}</head><body>${body}</body></html>`;

/** HTML → PDF or PNG with the browser on this computer (headless). Throws when there is none. */
export function renderWithBrowser(html, out, { env = process.env, png = false, size = '1280,800', timeout = 60000 } = {}) {
  const exe = findBrowser(env);
  const none = 'Для PDF и PNG нужен Chrome, Edge или Chromium на этом компьютере (или KLINCH_BROWSER). Сохраните как .html или .svg';
  if (!exe) throw new Error(none);
  const dir = mkdtempSync(join(tmpdir(), 'agent-render-')), src = join(dir, 'page.html');
  writeFileSync(src, html);
  const args = ['--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check', `--user-data-dir=${join(dir, 'profile')}`, ...(process.getuid?.() === 0 ? ['--no-sandbox'] : []),
    ...(png ? [`--screenshot=${out}`, `--window-size=${size}`, '--hide-scrollbars'] : [`--print-to-pdf=${out}`, '--no-pdf-header-footer']), 'file://' + src];
  return new Promise((resolve, reject) => {
    const p = spawn(exe, args, { stdio: ['ignore', 'ignore', 'pipe'] });
    let err = '';
    p.stderr.on('data', (d) => { err += d; if (err.length > 4000) err = err.slice(-4000); });
    const t = setTimeout(() => p.kill('SIGKILL'), timeout);
    p.on('error', (e) => { clearTimeout(t); rmSync(dir, { recursive: true, force: true }); reject(e.code === 'ENOENT' ? new Error(none) : e); });
    p.on('close', () => {
      clearTimeout(t); rmSync(dir, { recursive: true, force: true });
      existsSync(out) ? resolve(out) : reject(new Error(`Браузер не сохранил файл${err ? `: ${err.split('\n').find((l) => /error/i.test(l)) || ''}` : ''}`));
    });
  });
}

// ---------------------------------------------------------------- canvas (a live page beside the terminal)
let canvas = null;   // { server, url, version, html, clients:Set }
const CANVAS_SHELL = (url) => `<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>Canvas</title><style>html,body{margin:0;background:#fafafa}iframe{border:0;width:100vw;height:100vh;display:block}</style></head><body><iframe id="f" src="/frame"></iframe><script>const es=new EventSource('/events');es.onmessage=()=>{document.getElementById('f').src='/frame?'+Date.now()};</script></body></html>`;
const MERMAID = '<script type="module">import m from "https://cdn.jsdelivr.net/npm/mermaid@11.4.1/dist/mermaid.esm.min.mjs";m.initialize({startOnLoad:true,theme:"neutral"});</script>';

/** Starts (once) the local canvas page and shows `html` in it; returns its address. */
export async function showCanvas(html, { open = true } = {}) {
  if (!canvas) {
    const c = { version: 0, html: '', clients: new Set() };
    c.server = createServer((q, s) => {
      if (q.url === '/events') { s.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-store' }); s.write('retry: 1000\n\n'); c.clients.add(s); q.on('close', () => c.clients.delete(s)); return; }
      s.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
      s.end(q.url.startsWith('/frame') ? c.html : CANVAS_SHELL());
    });
    await new Promise((r) => c.server.listen(0, '127.0.0.1', r));
    c.server.unref();
    c.url = `http://127.0.0.1:${c.server.address().port}/`;
    canvas = c;
    canvas.html = html;
    if (open) openBrowser(c.url);
    return c.url;
  }
  canvas.html = html; canvas.version++;
  for (const s of canvas.clients) s.write(`data: ${canvas.version}\n\n`);
  return canvas.url;
}
export function closeCanvas() { if (!canvas) return; for (const s of canvas.clients) s.end(); canvas.server.close(); canvas = null; }
export const canvasUrl = () => canvas?.url || null;

/** The canvas page for one tool call: Markdown, a chart, a Mermaid diagram, or HTML as given. */
export function canvasHtml({ title, markdown, chart, mermaid, html }) {
  if (html) return /<html[\s>]/i.test(html) ? html : htmlPage(title, html);
  let body = title ? `<h1>${esc(title)}</h1>` : '';
  if (chart) body += chartSvg({ ...chart, title: chart.title || '' });
  if (mermaid) body += `<pre class="mermaid">${esc(mermaid)}</pre>`;
  if (markdown) body += markdownHtml(markdown);
  return htmlPage(title, body, mermaid ? MERMAID : '');
}

// ---------------------------------------------------------------- the tools
const rel = (cwd, abs) => relative(cwd, abs) || abs;
const ensureDir = (abs) => mkdirSync(dirname(abs), { recursive: true });
const tableOf = (input) => {
  const columns = (input.columns || []).map(String);
  const rows = (input.rows || []).map((r) => (Array.isArray(r) ? r : columns.map((c) => r?.[c])));
  if (!columns.length) throw new Error('Для таблицы нужны columns и rows');
  return { columns, rows };
};

/**
 * Tools for the agent. `client` is the gateway client (pictures are drawn there and paid from the balance),
 * `env` for the browser lookup.
 */
export function mediaTools({ client, env = process.env } = {}) {
  return [
    {
      name: 'generate_image',
      description: 'Нарисовать картинку по описанию (или изменить существующую: image = путь к ней) и сохранить в проект (png). Платно, с баланса пользователя: зови, когда картинку правда просили (иконка, иллюстрация, баннер, макет). quality "pro" — дороже и аккуратнее, по умолчанию обычное.',
      input_schema: { type: 'object', properties: {
        prompt: { type: 'string', description: 'Подробное описание: что, стиль, цвета, композиция, текст на картинке' },
        path: { type: 'string', description: 'Куда сохранить, например assets/hero.png' },
        image: { type: 'string', description: 'Путь к картинке для изменения (необязательно)' },
        size: { type: 'string', enum: ['1024x1024', '1536x1024', '1024x1536', 'auto'] },
        quality: { type: 'string', enum: ['normal', 'pro'] } }, required: ['prompt', 'path'] },
      danger: true,
      preview: ({ prompt, path, image, quality }) => `generate_image ${path}${image ? ` (из ${image})` : ''}${quality === 'pro' ? ' [pro]' : ''}: ${String(prompt).slice(0, 160)}`,
      async run({ prompt, path, image, size, quality }, ctx) {
        if (!client?.postJson) throw new Error('Картинки недоступны в этом режиме');
        const abs = safePath(ctx.cwd, path, { write: true });
        const body = { model: quality === 'pro' ? 'image-pro' : 'image', prompt: String(prompt), n: 1, ...(size && size !== 'auto' ? { size } : {}) };
        let route = '/v1/images/generations';
        if (image) {
          const src = safePath(ctx.cwd, image);
          const ext = extname(src).toLowerCase(), type = ext === '.jpg' || ext === '.jpeg' ? 'image/jpeg' : ext === '.webp' ? 'image/webp' : 'image/png';
          body.image = `data:${type};base64,${readFileSync(src).toString('base64')}`;
          route = '/v1/images/edits';
        }
        const r = await client.postJson(route, body, { signal: ctx.signal });
        const b64 = r?.data?.[0]?.b64_json || /^data:[^;]+;base64,(.+)$/.exec(r?.data?.[0]?.url || '')?.[1];
        if (!b64) throw new Error('Картинка не пришла, попробуйте ещё раз или измените описание');
        const buf = Buffer.from(b64, 'base64');
        ensureDir(abs); writeFileSync(abs, buf);
        ctx.onFile?.(abs);
        return [{ type: 'text', text: `Сохранено ${rel(ctx.cwd, abs)} (${Math.round(buf.length / 1024)} КБ). Вот она:` }, { type: 'image', source: { type: 'base64', media_type: buf[0] === 0xff ? 'image/jpeg' : 'image/png', data: b64 } }];
      },
    },
    {
      name: 'make_file',
      description: `Сделать файл-результат для пользователя без сторонних программ.
- kind "chart": график из chart {type: bar|line|pie, title, labels, series:[{name, values}]}; путь .svg (без браузера), .png или .pdf (через браузер), .html.
- kind "table": таблица из columns и rows; путь .xlsx (Excel), .csv или .html.
- kind "document": документ из markdown (заголовки, списки, таблицы, код); путь .pdf (через браузер), .html или .md. Графики можно вставить в markdown как готовый SVG.
Пиши сам файл, а в ответе коротко скажи, где он.`,
      input_schema: { type: 'object', properties: {
        kind: { type: 'string', enum: ['chart', 'table', 'document'] },
        path: { type: 'string', description: 'Куда сохранить: report.pdf, data/sales.xlsx, chart.svg…' },
        title: { type: 'string' },
        chart: { type: 'object', properties: { type: { type: 'string', enum: ['bar', 'line', 'pie'] }, title: { type: 'string' }, labels: { type: 'array', items: { type: 'string' } }, series: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, values: { type: 'array', items: { type: 'number' } } } } } } },
        columns: { type: 'array', items: { type: 'string' } },
        rows: { type: 'array', items: { type: 'array', items: {} } },
        markdown: { type: 'string' } }, required: ['kind', 'path'] },
      danger: true,
      preview: ({ kind, path }) => `make_file ${kind} → ${path}`,
      async run(input, ctx) {
        const abs = safePath(ctx.cwd, input.path, { write: true });
        const ext = extname(abs).toLowerCase();
        ensureDir(abs);
        const done = (extra = '') => { ctx.onFile?.(abs); return `Готово: ${rel(ctx.cwd, abs)}${extra}`; };
        if (input.kind === 'chart') {
          const svg = chartSvg({ ...(input.chart || {}), title: input.chart?.title || input.title });
          if (ext === '.svg') { writeFileSync(abs, svg); return done(); }
          if (ext === '.html') { writeFileSync(abs, htmlPage(input.title, svg)); return done(); }
          if (ext === '.png' || ext === '.pdf') {
            const page = `<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;background:#fff}${ext === '.pdf' ? '@page{size:800px 480px;margin:0}' : ''}</style></head><body>${svg}</body></html>`;
            await renderWithBrowser(page, abs, { env, png: ext === '.png', size: '800,480' });
            return done();
          }
          throw new Error('График: .svg, .png, .pdf или .html');
        }
        if (input.kind === 'table') {
          const { columns, rows } = tableOf(input);
          if (ext === '.xlsx') { writeFileSync(abs, toXlsx(columns, rows, input.title || 'Лист1')); return done(` (${rows.length} строк)`); }
          if (ext === '.csv') { writeFileSync(abs, toCsv(columns, rows)); return done(` (${rows.length} строк)`); }
          if (ext === '.html') { writeFileSync(abs, htmlPage(input.title, `${input.title ? `<h1>${esc(input.title)}</h1>` : ''}<table><thead><tr>${columns.map((c) => `<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((v) => `<td>${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table>`)); return done(); }
          throw new Error('Таблица: .xlsx, .csv или .html');
        }
        if (input.kind === 'document') {
          const md = String(input.markdown || '');
          if (!md.trim()) throw new Error('Для документа нужен markdown');
          if (ext === '.md') { writeFileSync(abs, md); return done(); }
          const html = htmlPage(input.title || md.match(/^#\s+(.+)/m)?.[1], markdownHtml(md));
          if (ext === '.html') { writeFileSync(abs, html); return done(); }
          if (ext === '.pdf') { await renderWithBrowser(html, abs, { env }); return done(); }
          throw new Error('Документ: .pdf, .html или .md');
        }
        throw new Error('kind: chart, table или document');
      },
    },
    {
      name: 'canvas',
      description: 'Показать пользователю живую страницу рядом с терминалом (canvas): график (chart), диаграмму Mermaid (mermaid: flowchart, sequence, gantt…), текст и таблицы в markdown или готовый html. Повторный вызов обновляет ту же страницу. Для схем архитектуры, сравнений, отчётов, прототипов интерфейса.',
      input_schema: { type: 'object', properties: {
        title: { type: 'string' }, markdown: { type: 'string' }, mermaid: { type: 'string' }, html: { type: 'string' },
        chart: { type: 'object', description: 'как в make_file' } } },
      preview: ({ title }) => `canvas ${title || ''}`.trim(),
      async run(input, ctx) {
        const url = await showCanvas(canvasHtml(input), { open: !ctx.noOpen });
        return `Canvas обновлён: ${url} (открыт в браузере)`;
      },
    },
  ];
}
