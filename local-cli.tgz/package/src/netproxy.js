// Network for sandboxed commands by an allow list (src/sandbox.js, "network": "allowlist", the default).
//
// A small HTTP proxy in this process lets through only hosts on the list: package registries (npm, PyPI, crates,
// Go, Maven, RubyGems) and GitHub out of the box, plus "allowHosts" from the config and /sandbox allow <host>.
// Everything else gets 403 and is remembered, so the agent can say which host was closed.
//
// On Linux the sandbox has no network at all except a forwarder inside it that leads to this proxy over a unix
// socket, so the list cannot be bypassed. On macOS sandbox-exec lets the command reach only the proxy port. With
// Docker and on Windows the command gets HTTP(S)_PROXY, which npm, pip, git, cargo and curl follow.
import http from 'node:http';
import net from 'node:net';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

export const DEFAULT_ALLOW = [
  // npm, yarn, pnpm, bun
  'registry.npmjs.org', '*.npmjs.org', 'registry.yarnpkg.com', 'repo.yarnpkg.com', 'nodejs.org',
  // pip, uv, poetry, conda
  'pypi.org', 'files.pythonhosted.org', 'pypi.python.org', 'conda.anaconda.org', 'repo.anaconda.com',
  // GitHub (git clone, release downloads, packages installed from git)
  'github.com', '*.github.com', '*.githubusercontent.com', 'codeload.github.com', 'ghcr.io',
  // Rust, Go, Java, Ruby, PHP, .NET, Dart
  'crates.io', '*.crates.io', 'proxy.golang.org', 'sum.golang.org', 'storage.googleapis.com',
  'repo.maven.apache.org', 'repo1.maven.org', 'services.gradle.org', 'plugins.gradle.org', 'plugins-artifacts.gradle.org',
  'rubygems.org', 'index.rubygems.org', 'repo.packagist.org', 'api.nuget.org', 'pub.dev',
];

/** Lower-case host without port and brackets; '' for junk. */
export const cleanHost = (h) => String(h || '').trim().toLowerCase().replace(/^\[|\](:\d+)?$/g, '').replace(/:\d+$/, '').replace(/\.$/, '');

/** Whether `host` is on `list`: an exact name, «*.name» or «.name» (subdomains and the name itself). */
export function hostAllowed(host, list) {
  const h = cleanHost(host);
  if (!h) return false;
  return list.some((e) => {
    const x = cleanHost(e);
    if (!x) return false;
    if (x === '*') return true;
    const base = x.replace(/^\*?\./, '');
    return h === base || (x !== base && h.endsWith('.' + base));
  });
}

/**
 * Starts the proxy. `allow()` returns the current list (read on each connection). Listens on a unix socket
 * (`socket: true`), or on TCP `host` (127.0.0.1 by default) with a free port. Returns
 * { port, host, socket, denied: [{ host, at }], close() }.
 */
export function startProxy({ allow = () => DEFAULT_ALLOW, socket = false, host = '127.0.0.1', connect = net.connect } = {}) {
  const denied = [];
  const deny = (h) => { denied.push({ host: cleanHost(h), at: Date.now() }); if (denied.length > 200) denied.shift(); };
  const server = http.createServer((req, res) => {
    // Plain http://: the request line carries the whole URL.
    let u; try { u = new URL(req.url); } catch { res.writeHead(400).end('bad proxy request'); return; }
    if (!hostAllowed(u.hostname, allow())) { deny(u.hostname); res.writeHead(403, { 'content-type': 'text/plain' }).end(`Песочница: сеть к ${u.hostname} закрыта\n`); return; }
    const up = http.request({ host: u.hostname, port: u.port || 80, method: req.method, path: u.pathname + u.search, headers: req.headers }, (r) => {
      res.writeHead(r.statusCode || 502, r.headers); r.pipe(res);
    });
    up.on('error', (e) => { if (!res.headersSent) res.writeHead(502); res.end(String(e.message)); });
    req.pipe(up);
  });
  server.on('connect', (req, client, head) => {
    // First thing: a client that drops the connection (curl after a 403) must not crash the agent.
    client.on('error', () => {});
    const [h, p] = splitHostPort(req.url);
    if (!h || !hostAllowed(h, allow())) { deny(h); client.end(`HTTP/1.1 403 Forbidden\r\ncontent-type: text/plain\r\n\r\nПесочница: сеть к ${h} закрыта\n`); return; }
    const up = connect(p || 443, h, () => { client.write('HTTP/1.1 200 Connection Established\r\n\r\n'); if (head?.length) up.write(head); up.pipe(client); client.pipe(up); });
    up.on('error', () => { try { client.end('HTTP/1.1 502 Bad Gateway\r\n\r\n'); } catch { /* gone */ } });
    client.on('error', () => up.destroy());
  });
  server.on('connection', (s) => s.on('error', () => {}));
  server.on('clientError', (_e, s) => { try { s.end('HTTP/1.1 400 Bad Request\r\n\r\n'); } catch { /* gone */ } });
  let dir = null;
  const st = { port: 0, host, socket: null, denied, server };
  const ready = new Promise((resolve, reject) => {
    server.once('error', reject);
    if (socket) { dir = mkdtempSync(join(tmpdir(), 'agent-net-')); st.socket = join(dir, 'proxy.sock'); server.listen(st.socket, resolve); }
    else server.listen(0, host, () => { st.port = server.address().port; resolve(); });
  });
  server.unref();
  st.ready = ready.then(() => st);
  st.close = () => { try { server.close(); } catch { /* closed */ } if (dir) rmSync(dir, { recursive: true, force: true }); };
  return st;
}

function splitHostPort(s) {
  const m = /^\[([^\]]+)\](?::(\d+))?$/.exec(s) || /^([^:]+)(?::(\d+))?$/.exec(s || '');
  return m ? [m[1], m[2] ? +m[2] : 0] : ['', 0];
}

/** Environment that points ordinary tools at the proxy `url` (http://host:port). */
export function proxyEnv(url) {
  return {
    HTTP_PROXY: url, HTTPS_PROXY: url, http_proxy: url, https_proxy: url,
    npm_config_proxy: url, npm_config_https_proxy: url, YARN_HTTP_PROXY: url, YARN_HTTPS_PROXY: url,
    NO_PROXY: 'localhost,127.0.0.1,::1', no_proxy: 'localhost,127.0.0.1,::1', npm_config_noproxy: 'localhost,127.0.0.1,::1',
  };
}

/** Hosts the proxy closed since `t` (ms), without repeats. */
export const deniedSince = (st, t) => [...new Set((st?.denied || []).filter((d) => d.at >= t && d.host).map((d) => d.host))];

/**
 * Source of the forwarder that runs inside the Linux sandbox: listens on 127.0.0.1:<port> in the sandbox's own
 * network, sends each connection to the proxy's unix socket, and runs the command with the proxy variables.
 * argv: <socket> <port> <env json> <program> <args...>. Extra descriptors 3 and 4 (the python tool) are passed on.
 */
export const FORWARDER = `
const net = require('net'), { spawn } = require('child_process'), fs = require('fs');
const [sock, port, envJson, bin, ...args] = process.argv.slice(1);
const srv = net.createServer((c) => { const u = net.connect(sock); c.pipe(u); u.pipe(c); u.on('error', () => c.destroy()); c.on('error', () => u.destroy()); });
srv.listen(+port, '127.0.0.1', () => {
  const stdio = [0, 1, 2]; for (const fd of [3, 4]) { try { fs.fstatSync(fd); stdio.push(fd); } catch { break; } }
  const ch = spawn(bin, args, { stdio, env: { ...process.env, ...JSON.parse(envJson) } });
  for (const s of ['SIGTERM', 'SIGINT', 'SIGHUP']) process.on(s, () => ch.kill(s));
  ch.on('error', (e) => { console.error(e.message); process.exit(127); });
  ch.on('close', (code, sig) => process.exit(code ?? (sig ? 128 : 1)));
});
srv.on('error', (e) => { console.error('sandbox network: ' + e.message); process.exit(1); });
`;
