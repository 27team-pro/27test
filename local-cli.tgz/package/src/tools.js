// Tools the model may call. Each has an Anthropic tool definition, a `danger` flag (asks for confirmation
// before running) and `run(input, ctx)` returning a string. Paths are confined to the working directory.
import { readFileSync, writeFileSync, mkdirSync, statSync, lstatSync, readdirSync, realpathSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { resolve, relative, sep, dirname, basename, join, isAbsolute } from 'node:path';
import { webSearch, webFetch } from './web.js';
import { wrapCommand, prepareSandbox, sandboxDenied, SANDBOX_HINT } from './sandbox.js';
import { readDocument, DOC_EXT } from './docs.js';
import { BROWSER_TOOL } from './browser.js';

const MAX_OUT = 30000;
const clip = (s, n = MAX_OUT) => (s.length > n ? s.slice(0, n) + `\n… (обрезано, всего ${s.length} символов)` : s);

const outside = (root, abs) => { const rel = relative(root, abs); return rel === '..' || rel.startsWith('..' + sep) || isAbsolute(rel); };
/** The real path of `abs` (symlinks resolved) as far as it exists; the missing tail (a file to create) is kept. */
function realOf(abs) {
  let head = abs, tail = '';
  for (;;) {
    try { return join(realpathSync(head), tail); } catch { /* not there yet */ }
    const up = dirname(head);
    if (up === head) return abs;
    tail = tail ? join(basename(head), tail) : basename(head);
    head = up;
  }
}
/**
 * A path inside the working folder. `..`, absolute paths and symlinks that lead out of the folder (a repository can
 * ship `docs -> ~/.ssh`) are refused. `write: true` also refuses .git/: a hook written there would run on the next
 * git command the user allows.
 */
export function safePath(cwd, p, { write = false } = {}) {
  const abs = resolve(cwd, String(p || ''));
  if (outside(cwd, abs) || resolve(abs) !== abs) throw new Error(`Путь вне рабочей папки: ${p}`);
  if (outside(realOf(cwd), realOf(abs))) throw new Error(`Путь вне рабочей папки (ссылка наружу): ${p}`);
  if (write && relative(cwd, abs).split(sep).some((x) => x.toLowerCase() === '.git')) throw new Error(`В папку .git писать нельзя: ${p}`);
  return abs;
}

const SKIP = new Set(['node_modules', '.git', 'dist', 'build', '.next', '.vercel', 'coverage']);

function listDir(cwd, p, depth, out, prefix = '') {
  const abs = safePath(cwd, p);
  let entries;
  try { entries = readdirSync(abs, { withFileTypes: true }); } catch (e) { out.push(`${prefix}(${e.message})`); return; }
  entries.sort((a, b) => a.name.localeCompare(b.name));
  for (const e of entries) {
    if (out.length > 500) { out.push('… (список обрезан)'); return; }
    if (e.isDirectory()) {
      out.push(`${prefix}${e.name}/`);
      if (depth > 1 && !SKIP.has(e.name)) listDir(cwd, resolve(abs, e.name), depth - 1, out, prefix + '  ');
    } else out.push(prefix + e.name);
  }
}

// A glob (src/**, *.{js,mjs}) → RegExp over posix relative paths. A pattern without a slash matches at any depth.
export function globToRegExp(glob) {
  let g = String(glob || '*').replace(/\\/g, '/').replace(/^\.\//, '');
  if (!g.includes('/')) g = '**/' + g;
  let re = '', i = 0;
  while (i < g.length) {
    const ch = g[i];
    if (g.startsWith('**/', i)) { re += '(?:.*/)?'; i += 3; continue; }
    if (g.startsWith('**', i)) { re += '.*'; i += 2; continue; }
    if (ch === '*') re += '[^/]*';
    else if (ch === '?') re += '[^/]';
    else if (ch === '{') { const end = g.indexOf('}', i); if (end > i) { re += '(?:' + g.slice(i + 1, end).split(',').map((x) => x.replace(/[.+^$()|[\]\\]/g, '\\$&').replace(/\*/g, '[^/]*')).join('|') + ')'; i = end + 1; continue; } re += '\\{'; }
    else re += ch.replace(/[.+^$()|[\]\\}]/g, '\\$&');
    i++;
  }
  return new RegExp('^' + re + '$');
}

// Background commands (dev servers, watchers, long builds): started by shell with background: true, read with
// shell_output, stopped with shell_kill or when klinch exits. Output keeps the last 200 KB.
export const BACKGROUND = new Map();
let bgSeq = 0;
/** sh / cmd for a command line, or the sandbox around it when `sb` is given. */
const shellArgv = (command, cwd, sb) => (sb ? wrapCommand(sb, command, cwd)
  : process.platform === 'win32' ? ['cmd.exe', ['/d', '/s', '/c', `"${command}"`]] : ['/bin/sh', ['-c', command]]);
// cmd.exe parses its own command line: the command goes in one pair of quotes (/s strips them), as Node's shell: true
// does, and Node must not escape the quotes inside it (otherwise `echo x> "a b.txt"` breaks).
const verbatim = (sh) => process.platform === 'win32' && /cmd\.exe$/i.test(sh[0]);

function startBackground(command, cwd, sb = null) {
  const id = 'bg' + ++bgSeq;
  const win = process.platform === 'win32';
  const sh = shellArgv(command, cwd, sb);
  const child = spawn(sh[0], sh[1], { cwd, env: { ...process.env, ...(sh[2] || {}) }, stdio: ['ignore', 'pipe', 'pipe'], detached: !win, windowsVerbatimArguments: verbatim(sh) });
  const job = { id, command, cwd, child, out: '', read: 0, dropped: 0, code: null, started: Date.now(), cleanup: sh.kill };
  const take = (c) => { job.out += c; if (job.out.length > 200_000) { const cut = job.out.length - 200_000; job.out = job.out.slice(cut); job.read = Math.max(0, job.read - cut); job.dropped += cut; } };
  child.stdout.on('data', take); child.stderr.on('data', take);
  child.on('error', (e) => { job.out += `\nНе удалось запустить: ${e.message}`; job.code = -1; });
  child.on('close', (code, sig) => { job.code = code ?? -1; job.signal = sig; });
  BACKGROUND.set(id, job);
  return job;
}
export function killBackground(job) {
  if (job.code !== null) return;
  try { if (process.platform !== 'win32') process.kill(-job.child.pid, 'SIGTERM'); else job.child.kill(); } catch { try { job.child.kill(); } catch { /* gone */ } }
  job.cleanup?.();
}
export const killAllBackground = () => { for (const j of BACKGROUND.values()) killBackground(j); };
const jobStatus = (j) => (j.code === null ? 'работает' : j.signal ? `остановлена (${j.signal})` : `завершилась, код ${j.code}`);

async function runShell(command, cwd, timeoutMs = 120000, sb = null) {
  if (sb) await prepareSandbox(sb, cwd);
  if (sb?.prepareError && sb.kind === 'lowil') return `Песочница Windows не готова: ${sb.prepareError}. Если команда нужна, повтори с unsandboxed: true`;
  const t0 = Date.now();
  return new Promise((done) => {
    let sh;
    try { sh = shellArgv(command, cwd, sb); } catch (e) { done(`Не удалось запустить: ${e.message}`); return; }
    const child = spawn(sh[0], sh[1], { cwd, env: { ...process.env, ...(sh[2] || {}) }, stdio: ['ignore', 'pipe', 'pipe'], windowsVerbatimArguments: verbatim(sh) });
    let out = '';
    const take = (c) => { if (out.length < MAX_OUT * 2) out += c; };
    child.stdout.on('data', take); child.stderr.on('data', take);
    const t = setTimeout(() => { child.kill('SIGKILL'); sh.kill?.(); out += `\n(прервано по таймауту ${timeoutMs / 1000}с)`; }, timeoutMs);
    child.on('error', (e) => { clearTimeout(t); done(`Не удалось запустить: ${e.message}`); });
    child.on('close', (code) => {
      clearTimeout(t);
      done(clip(out.trim()) + (code ? `\n(код выхода ${code})` : '') + (sb ? sandboxNote(sb, t0, code, out) : ''));
    });
  });
}

/** What to tell the model when the sandbox may have stopped a command: closed hosts, or the usual hint. */
export function sandboxNote(sb, t0, code, out) {
  const hosts = sandboxDenied(sb, t0);
  if (hosts.length) return `\n(песочница закрыла сеть к ${hosts.join(', ')}: открыты только реестры пакетов и GitHub. Если этот адрес нужен, повтори с unsandboxed: true, а пользователь может разрешить его командой /sandbox allow ${hosts[0]})`;
  return code && SANDBOX_HINT.test(out) ? '\n(похоже, команду остановила песочница: если ей нужна сеть или запись вне папки, повтори с unsandboxed: true)' : '';
}

export const TOOLS = [
  {
    name: 'read_file',
    description: 'Прочитать файл: текст с номерами строк (можно диапазон), Jupyter-блокнот по ячейкам, текст из PDF, Word, Excel, PowerPoint и OpenDocument.',
    input_schema: { type: 'object', properties: {
      path: { type: 'string', description: 'Путь относительно рабочей папки' },
      start: { type: 'integer', description: 'Первая строка (с 1); у блокнота .ipynb номер первой ячейки (с 0)' },
      end: { type: 'integer', description: 'Последняя строка; у блокнота номер последней ячейки' } }, required: ['path'] },
    run({ path, start, end }, { cwd }) {
      const abs = safePath(cwd, path);
      if (/\.ipynb$/i.test(abs)) return clip(renderNotebook(readFileSync(abs, 'utf8'), { from: start, to: end }));
      if (DOC_EXT.test(abs)) {
        if (statSync(abs).size > 50e6) return 'Документ больше 50 МБ.';
        const t = readDocument(abs).split('\n');
        const from = Math.max(1, start || 1), to = Math.min(t.length, end || t.length);
        return clip(`(текст документа, строк ${t.length}${from > 1 || to < t.length ? `, показаны ${from}-${to}` : ''})\n` + t.slice(from - 1, to).join('\n'));
      }
      if (statSync(abs).size > 2e6) return 'Файл больше 2 МБ, прочитайте диапазон строк или используйте shell.';
      const lines = readFileSync(abs, 'utf8').split('\n');
      const a = Math.max(1, start || 1), b = Math.min(lines.length, end || lines.length);
      return clip(lines.slice(a - 1, b).map((l, i) => `${String(a + i).padStart(5)}| ${l}`).join('\n'));
    },
  },
  {
    name: 'list_files',
    description: 'Список файлов и папок (дерево). node_modules и .git пропускаются.',
    input_schema: { type: 'object', properties: {
      path: { type: 'string', description: 'Папка, по умолчанию рабочая' },
      depth: { type: 'integer', description: 'Глубина, по умолчанию 2' } }, required: [] },
    run({ path = '.', depth = 2 }, { cwd }) { const out = []; listDir(cwd, path, Math.min(depth, 6), out); return out.join('\n') || '(пусто)'; },
  },
  {
    name: 'search',
    description: 'Найти строки, содержащие текст или регулярное выражение, во всех файлах папки. Возвращает файл:строка: текст.',
    input_schema: { type: 'object', properties: {
      pattern: { type: 'string', description: 'Регулярное выражение (JavaScript)' },
      path: { type: 'string', description: 'Папка или файл, по умолчанию рабочая папка' },
      glob: { type: 'string', description: 'Фильтр по имени файла, например *.js' } }, required: ['pattern'] },
    run({ pattern, path = '.', glob }, { cwd }) {
      const re = new RegExp(pattern, 'i');
      const g = glob ? new RegExp('^' + glob.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.') + '$') : null;
      const hits = [];
      const walk = (abs, top = false) => {
        if (hits.length >= 200) return;
        // A symlink inside the folder can lead anywhere (`docs -> ~/.ssh`): only the starting path (checked by
        // safePath) may be one, links met on the way are skipped.
        if (!top && lstatSync(abs).isSymbolicLink()) return;
        const st = statSync(abs);
        if (st.isDirectory()) {
          for (const e of readdirSync(abs)) if (!SKIP.has(e)) walk(resolve(abs, e));
          return;
        }
        if (st.size > 1e6 || (g && !g.test(abs.split(sep).pop()))) return;
        let text; try { text = readFileSync(abs, 'utf8'); } catch { return; }
        if (text.includes('\0')) return;
        text.split('\n').forEach((l, i) => { if (hits.length < 200 && re.test(l)) hits.push(`${relative(cwd, abs)}:${i + 1}: ${l.trim().slice(0, 200)}`); });
      };
      walk(safePath(cwd, path), true);
      return hits.join('\n') || 'Ничего не найдено';
    },
  },
  {
    name: 'glob',
    description: 'Найти файлы по шаблону имени (glob), например **/*.test.ts или src/**/index.{js,ts}. Свежие файлы первыми.',
    input_schema: { type: 'object', properties: {
      pattern: { type: 'string', description: 'Шаблон glob относительно папки' },
      path: { type: 'string', description: 'Папка, по умолчанию рабочая' } }, required: ['pattern'] },
    run({ pattern, path = '.' }, { cwd }) {
      const root = safePath(cwd, path), re = globToRegExp(pattern), hits = [];
      let seen = 0;
      const walk = (abs) => {
        let entries; try { entries = readdirSync(abs, { withFileTypes: true }); } catch { return; }
        for (const e of entries) {
          if (++seen > 50000) return;
          const p = join(abs, e.name);
          if (e.isDirectory()) { if (!SKIP.has(e.name)) walk(p); }
          else if (re.test(relative(root, p).split(sep).join('/'))) { let m = 0; try { m = statSync(p).mtimeMs; } catch { /* gone */ } hits.push([relative(cwd, p), m]); }
        }
      };
      walk(root);
      hits.sort((a, b) => b[1] - a[1]);
      return hits.length ? hits.slice(0, 300).map((h) => h[0]).join('\n') + (hits.length > 300 ? `\n… ещё ${hits.length - 300}` : '') : 'Ничего не найдено';
    },
  },
  {
    name: 'web_search',
    description: 'Поиск в интернете: свежая документация, версии пакетов, ошибки, новости. Возвращает заголовки, ссылки и выдержки.',
    input_schema: { type: 'object', properties: {
      query: { type: 'string' }, num_results: { type: 'integer', description: '1-10, по умолчанию 6' } }, required: ['query'] },
    preview: ({ query }) => `web_search «${query}»`,
    run: ({ query, num_results }) => webSearch(query, num_results),
  },
  {
    name: 'web_fetch',
    description: 'Прочитать веб-страницу (http/https) как текст: документацию, README, статью по ссылке.',
    input_schema: { type: 'object', properties: { url: { type: 'string' } }, required: ['url'] },
    preview: ({ url }) => `web_fetch ${url}`,
    run: ({ url }) => webFetch(url),
  },
  {
    name: 'write_file',
    description: 'Создать или полностью перезаписать файл.',
    danger: true,
    input_schema: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'content'] },
    preview: ({ path, content }, ctx) => {
      const before = ctx ? readOr(ctx.cwd, path) : null, n = String(content ?? '').split('\n').length;
      if (before == null) return `write_file ${path} (новый файл, ${n} строк)\n${diffText('', String(content ?? ''), { max: 40 })}`;
      return `write_file ${path} (перезапись, ${n} строк)\n${diffText(before, String(content ?? ''))}`;
    },
    run({ path, content }, { cwd }) {
      const abs = safePath(cwd, path, { write: true });
      mkdirSync(dirname(abs), { recursive: true });
      writeFileSync(abs, content);
      return `Записано: ${path}`;
    },
  },
  {
    name: 'edit_file',
    description: 'Заменить фрагмент файла. `old` должен встречаться в файле ровно один раз и копироваться точно, включая отступы.',
    danger: true,
    input_schema: { type: 'object', properties: {
      path: { type: 'string' }, old: { type: 'string', description: 'Что заменить' }, new: { type: 'string', description: 'На что' } }, required: ['path', 'old', 'new'] },
    preview: ({ path, old, new: nw }, ctx) => {
      const after = ctx ? proposedContent(ctx.cwd, 'edit_file', { path, old, new: nw }) : null;
      return `edit_file ${path}\n${after ? diffText(after.before, after.after) : diff(String(old ?? ''), String(nw ?? ''))}`;
    },
    run({ path, old, new: nw }, { cwd }) {
      const abs = safePath(cwd, path, { write: true });
      const text = readFileSync(abs, 'utf8');
      const n = text.split(old).length - 1;
      if (n === 0) throw new Error('Фрагмент `old` не найден в файле');
      if (n > 1) throw new Error(`Фрагмент \`old\` встречается ${n} раз, уточните его`);
      writeFileSync(abs, text.replace(old, () => nw));
      return `Изменено: ${path}`;
    },
  },
  {
    name: 'notebook_edit',
    description: 'Изменить Jupyter-блокнот (.ipynb) по ячейкам. replace заменяет весь текст ячейки, edit меняет в ней фрагмент old на new (вывод кода в обоих случаях очищается), insert вставляет новую ячейку перед cell (без cell: в конец), delete удаляет, move переносит ячейку на место to, clear_outputs очищает вывод ячейки (без cell: всех). Номера ячеек с 0, как их показывает read_file. Выполнить блокнот: shell `jupyter nbconvert --to notebook --execute --inplace <файл>`.',
    danger: true,
    input_schema: { type: 'object', properties: {
      path: { type: 'string' }, cell: { type: 'integer', description: 'Номер ячейки с 0' }, cell_id: { type: 'string', description: 'Или id ячейки' },
      action: { type: 'string', enum: ['replace', 'edit', 'insert', 'delete', 'move', 'clear_outputs'] }, source: { type: 'string', description: 'Текст ячейки (replace, insert)' },
      old: { type: 'string', description: 'edit: фрагмент, который заменить (должен встречаться в ячейке один раз)' }, new: { type: 'string', description: 'edit: на что заменить' },
      to: { type: 'integer', description: 'move: новый номер ячейки' },
      cell_type: { type: 'string', enum: ['code', 'markdown', 'raw'] } }, required: ['path', 'action'] },
    preview: ({ path, cell, cell_id, action, source, old, new: nw, to }) => `notebook_edit ${path} ${action} ячейка ${(cell_id || cell) ?? (action === 'clear_outputs' ? 'все' : 'в конец')}${action === 'move' ? ` → ${to}` : ''}`
      + (action === 'edit' ? '\n' + diff(String(old ?? ''), String(nw ?? '')) : source ? '\n' + String(source).split('\n').slice(0, 30).map((l) => '+ ' + l).join('\n') : ''),
    run({ path, cell, cell_id, action, source = '', cell_type, old, new: nw = '', to }, { cwd }) {
      const abs = safePath(cwd, path, { write: true });
      const nb = JSON.parse(readFileSync(abs, 'utf8'));
      if (!Array.isArray(nb.cells)) throw new Error('Это не блокнот Jupyter (нет cells)');
      const all = action === 'clear_outputs' && cell == null && !cell_id;
      let i = cell_id ? nb.cells.findIndex((c) => c.id === cell_id) : cell ?? (action === 'insert' ? nb.cells.length : -1);
      if (!all && (i < 0 || i > nb.cells.length || (action !== 'insert' && i >= nb.cells.length))) throw new Error(`Нет ячейки ${cell_id || cell}; всего ${nb.cells.length}`);
      const lines = (t) => String(t).split(/(?<=\n)/);
      const text = (c) => (Array.isArray(c.source) ? c.source.join('') : String(c.source ?? ''));
      const clear = (c) => { if (c.cell_type === 'code') { c.outputs = []; c.execution_count = null; } };
      const make = (type) => ({ cell_type: type, ...(nb.nbformat >= 4 && nb.nbformat_minor >= 5 ? { id: Math.random().toString(36).slice(2, 10) } : {}), metadata: {}, source: lines(source), ...(type === 'code' ? { execution_count: null, outputs: [] } : {}) });
      let done;
      if (action === 'delete') { nb.cells.splice(i, 1); done = `удалена ячейка ${i}`; }
      else if (action === 'insert') { nb.cells.splice(i, 0, make(cell_type || 'code')); done = `вставлена ячейка ${i}`; }
      else if (action === 'move') {
        const j = Math.trunc(+to);
        if (!Number.isFinite(j) || j < 0 || j >= nb.cells.length) throw new Error(`move: to должно быть от 0 до ${nb.cells.length - 1}`);
        nb.cells.splice(j, 0, nb.cells.splice(i, 1)[0]); done = `ячейка ${i} перенесена на место ${j}`;
      } else if (action === 'clear_outputs') { for (const c of all ? nb.cells : [nb.cells[i]]) clear(c); done = all ? 'очищен вывод всех ячеек' : `очищен вывод ячейки ${i}`; }
      else if (action === 'edit') {
        const c = nb.cells[i], t = text(c);
        if (typeof old !== 'string' || !old) throw new Error('edit: нужен old');
        const n = t.split(old).length - 1;
        if (n === 0) throw new Error(`Фрагмент old не найден в ячейке ${i}`);
        if (n > 1) throw new Error(`Фрагмент old встречается в ячейке ${i} ${n} раз, уточните его`);
        c.source = lines(t.replace(old, () => String(nw))); clear(c); done = `изменена ячейка ${i}`;
      } else if (action === 'replace') {
        const c = nb.cells[i];
        if (cell_type && cell_type !== c.cell_type) nb.cells[i] = { ...make(cell_type), ...(c.id ? { id: c.id } : {}) };
        else { c.source = lines(source); clear(c); }
        done = `изменена ячейка ${i}`;
      } else throw new Error(`Неизвестное действие ${action}`);
      writeFileSync(abs, JSON.stringify(nb, null, 1) + '\n');
      return `Блокнот ${path}: ${done}, всего ${nb.cells.length}`;
    },
  },
  {
    name: 'shell',
    description: 'Выполнить команду в терминале в рабочей папке (sh / cmd). Возвращает вывод. Таймаут 2 минуты, можно до 10.',
    danger: true,
    input_schema: { type: 'object', properties: {
      command: { type: 'string' },
      timeout_sec: { type: 'integer', description: 'Таймаут в секундах, до 600' },
      unsandboxed: { type: 'boolean', description: 'Только когда включена песочница: выполнить вне её (команде нужна сеть или запись вне папки). Пользователь подтвердит' },
      background: { type: 'boolean', description: 'Запустить в фоне (сервер, watch, долгая сборка) и сразу вернуть id; вывод читать через shell_output' } }, required: ['command'] },
    preview: ({ command, background, unsandboxed }) => `$ ${command}${background ? '   (в фоне)' : ''}${unsandboxed ? '   (вне песочницы)' : ''}`,
    async run({ command, timeout_sec, background, unsandboxed }, { cwd, sandbox }) {
      const sb = sandbox?.active && !unsandboxed ? sandbox : null;
      if (!background) return runShell(command, cwd, Math.min(Math.max(+timeout_sec || 120, 1), 600) * 1000, sb);
      if (sb) await prepareSandbox(sb, cwd);
      let job;
      try { job = startBackground(command, cwd, sb); } catch (e) { return `Не удалось запустить: ${e.message}`; }
      await new Promise((r) => setTimeout(r, 1500));
      const first = job.out; job.read = first.length;
      return `Запущено в фоне: ${job.id} (${jobStatus(job)}). Первый вывод:\n${clip(first.trim(), 4000) || '(пока пусто)'}\nДальше: shell_output id=${job.id}, остановить: shell_kill.`;
    },
  },
  {
    name: 'shell_output',
    description: 'Новый вывод фоновой команды (с прошлого чтения) и её состояние. Без id: список фоновых команд.',
    input_schema: { type: 'object', properties: { id: { type: 'string' }, wait_sec: { type: 'integer', description: 'Подождать вывода до N секунд (до 60)' } } },
    preview: ({ id }) => `shell_output ${id || ''}`,
    async run({ id, wait_sec }) {
      if (!id) return [...BACKGROUND.values()].map((j) => `${j.id}  ${jobStatus(j)}  $ ${j.command}`).join('\n') || 'Фоновых команд нет';
      const j = BACKGROUND.get(id);
      if (!j) throw new Error(`Нет фоновой команды ${id}`);
      const until = Date.now() + Math.min(Math.max(+wait_sec || 0, 0), 60) * 1000;
      while (Date.now() < until && j.code === null && j.out.length === j.read) await new Promise((r) => setTimeout(r, 250));
      const fresh = j.out.slice(j.read); j.read = j.out.length;
      return `${j.id}: ${jobStatus(j)}\n${clip(fresh.trim()) || '(нового вывода нет)'}`;
    },
  },
  {
    name: 'shell_kill',
    description: 'Остановить фоновую команду.',
    input_schema: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] },
    preview: ({ id }) => `shell_kill ${id}`,
    run({ id }) {
      const j = BACKGROUND.get(id);
      if (!j) throw new Error(`Нет фоновой команды ${id}`);
      killBackground(j);
      return `Остановлено: ${id}`;
    },
  },
  BROWSER_TOOL,
];

export const toolDefs = () => TOOLS.map(({ name, description, input_schema }) => ({ name, description, input_schema }));
export const toolByName = (n) => TOOLS.find((t) => t.name === n);

// Tiny line diff for confirmation prompts (when the whole file is unknown).
export function diff(a, b) {
  const A = a.split('\n'), B = b.split('\n');
  return [...A.map((l) => '- ' + l), ...B.map((l) => '+ ' + l)].slice(0, 60).join('\n');
}

/** A Jupyter notebook as text: each cell with its number, type, source and a short view of its outputs. */
// For a notebook read_file's start / end are cell numbers (from 0), so a big notebook can be read in parts.
export function renderNotebook(json, { from, to } = {}) {
  const nb = JSON.parse(json), src = (v) => (Array.isArray(v) ? v.join('') : String(v ?? ''));
  const lang = nb.metadata?.kernelspec?.language || nb.metadata?.language_info?.name || '';
  const outOf = (o) => (o.output_type === 'stream' ? src(o.text) : o.output_type === 'error' ? `${o.ename}: ${o.evalue}`
    : o.data ? (o.data['text/plain'] ? src(o.data['text/plain']) : Object.keys(o.data).some((k) => k.startsWith('image/')) ? '[картинка]' : '') : '');
  const a = Number.isInteger(from) ? from : 0, b = Number.isInteger(to) ? to : Infinity;
  return [`Блокнот Jupyter${lang ? ` (${lang})` : ''}, ячеек: ${(nb.cells || []).length}${a > 0 || b < Infinity ? `, показаны ${a}–${Math.min(b, (nb.cells || []).length - 1)}` : ''}`, ...(nb.cells || []).map((c, i) => {
    if (i < a || i > b) return null;
    const outs = (c.outputs || []).map(outOf).filter(Boolean).join('\n').trim();
    return `\n### Ячейка ${i} [${c.cell_type}]${c.id ? ` id=${c.id}` : ''}\n${src(c.source)}${outs ? `\n--- вывод:\n${outs.slice(0, 2000)}${outs.length > 2000 ? '\n…' : ''}` : ''}`;
  }).filter((x) => x !== null)].join('\n');
}

const readOr = (cwd, p) => { try { return readFileSync(safePath(cwd, p), 'utf8'); } catch { return null; } };

/** The file before and after an edit the agent proposes ({ path, before, after }), or null if it cannot apply. */
export function proposedContent(cwd, tool, input = {}) {
  const before = readOr(cwd, input.path);
  if (tool === 'write_file') return typeof input.content === 'string' ? { path: input.path, before: before ?? '', after: input.content, created: before == null } : null;
  if (tool !== 'edit_file' || before == null || typeof input.old !== 'string' || !input.old) return null;
  if (before.split(input.old).length !== 2) return null;
  return { path: input.path, before, after: before.replace(input.old, () => String(input.new ?? '')) };
}

/** Line edit script between two texts: [['=', line] | ['-', line] | ['+', line]]. LCS on the middle part. */
export function diffLines(a, b) {
  const A = a.split('\n'), B = b.split('\n');
  let s = 0; while (s < A.length && s < B.length && A[s] === B[s]) s++;
  let e = 0; while (e < A.length - s && e < B.length - s && A[A.length - 1 - e] === B[B.length - 1 - e]) e++;
  const a1 = A.slice(s, A.length - e), b1 = B.slice(s, B.length - e), mid = [];
  if (a1.length * b1.length > 4e6) { for (const l of a1) mid.push(['-', l]); for (const l of b1) mid.push(['+', l]); }
  else {
    const n = a1.length, m = b1.length, L = Array.from({ length: n + 1 }, () => new Uint32Array(m + 1));
    for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) L[i][j] = a1[i] === b1[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
    let i = 0, j = 0;
    while (i < n || j < m) {
      if (i < n && j < m && a1[i] === b1[j]) { mid.push(['=', a1[i]]); i++; j++; }
      else if (i < n && (j >= m || L[i + 1][j] >= L[i][j + 1])) mid.push(['-', a1[i++]]);
      else mid.push(['+', b1[j++]]);
    }
  }
  return [...A.slice(0, s).map((l) => ['=', l]), ...mid, ...A.slice(A.length - e).map((l) => ['=', l])];
}

/** Unified-style diff for the terminal: hunks with `context` lines around, «@@ строка N @@» headers, capped. */
export function diffText(a, b, { context = 2, max = 80 } = {}) {
  const ops = diffLines(a, b), out = [];
  let line = 0, lastShown = -1;
  const idx = ops.map((o) => (o[0] === '+' ? line : ++line));   // line in the old file each op sits at
  const changed = ops.map((o) => o[0] !== '=');
  for (let k = 0; k < ops.length; k++) {
    let near = false;
    for (let d = -context; d <= context && !near; d++) near = changed[k + d] === true;
    if (!near) continue;
    if (k !== lastShown + 1) out.push(`@@ строка ${idx[k]} @@`);
    out.push((ops[k][0] === '=' ? '  ' : ops[k][0] + ' ') + ops[k][1]);
    lastShown = k;
  }
  if (!out.length) return '(без изменений)';
  return out.length > max ? out.slice(0, max).join('\n') + `\n… ещё ${out.length - max} строк диффа` : out.join('\n');
}
process.once('exit', killAllBackground);
