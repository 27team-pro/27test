// The link to the Klinch Code extension in VS Code. The extension listens on 127.0.0.1 and puts its port and a
// one-window token into every terminal it opens (KLINCH_IDE_PORT, KLINCH_IDE_TOKEN). When the agent proposes an
// edit, the CLI sends the file before and after: VS Code shows it as a side-by-side diff with «Принять» /
// «Отклонить», and whichever answer comes first, the terminal's or the editor's, is the one used.
const TIMEOUT = 2000;

export function ideBridge(env = process.env, fetchImpl = fetch) {
  const port = +env.KLINCH_IDE_PORT, token = env.KLINCH_IDE_TOKEN;
  if (!port || !token) return null;
  const url = (p) => `http://127.0.0.1:${port}${p}`;
  const post = (p, body, signal) => fetchImpl(url(p), { method: 'POST', headers: { 'content-type': 'application/json', 'x-ide-token': token }, body: JSON.stringify(body), signal });
  let seq = 0;
  return {
    /**
     * Opens the diff in the editor. `decision` resolves with 'accept' / 'reject' when the user answers there, or
     * never (the editor is closed or the call failed: the terminal's answer then decides). close() removes it.
     */
    showDiff({ path, before, after, title }) {
      const id = `${process.pid}-${++seq}`;
      const ctl = new AbortController();
      const decision = new Promise((resolve) => {
        post('/diff', { id, path, before, after, title }, ctl.signal)
          .then((r) => (r.ok ? r.json() : null))
          .then((j) => { if (j?.decision === 'accept' || j?.decision === 'reject') resolve(j.decision); })
          .catch(() => { /* no editor: the terminal answers */ });
      });
      return {
        decision,
        close: () => {
          const t = AbortSignal.timeout ? AbortSignal.timeout(TIMEOUT) : undefined;
          post('/close', { id }, t).catch(() => {}).finally(() => ctl.abort());
        },
      };
    },
  };
}
