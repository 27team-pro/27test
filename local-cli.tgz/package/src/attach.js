// Attachments in a prompt: `@path` adds a file (text inline, PDF and Office as their text, images as image blocks), /paste takes a picture
// from the clipboard. Saved chats: ~/.klinch/sessions/<folder hash>/<id>.json, for `klinch -c` and /resume.
import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync, chmodSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { join, extname } from 'node:path';
import { safePath } from './tools.js';
import { readDocument, DOC_EXT } from './docs.js';

const IMAGE = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp' };
const MAX_IMAGE = 5 * 1024 * 1024, MAX_TEXT = 200_000;

export const imageBlock = (buf, mediaType = 'image/png') => ({ type: 'image', source: { type: 'base64', media_type: mediaType, data: buf.toString('base64') } });

/**
 * Turns `text` with `@file` mentions into message content. Mentions of files that do not exist stay plain text
 * (an e-mail or @user is not a file). Returns { content, attached: [names] }.
 */
export function withMentions(text, cwd, extra = []) {
  const blocks = [], attached = [];
  for (const m of String(text).matchAll(/(?:^|\s)@((?:[^\s"']|\\ )+|"[^"]+")/g)) {
    const full = m[1].replace(/^"|"$/g, '').replace(/\\ /g, ' ').replace(/[,.;:!?)]+$/, '');
    const rm = /^(.*?)#L(\d+)(?:-L?(\d+))?$/.exec(full);
    const raw = rm ? rm[1] : full, from = rm ? +rm[2] : 0, to = rm ? +(rm[3] || rm[2]) : 0;
    let abs; try { abs = safePath(cwd, raw); } catch { continue; }
    let st; try { st = statSync(abs); } catch { continue; }
    if (!st.isFile()) continue;
    const type = IMAGE[extname(abs).toLowerCase()];
    if (type) {
      if (st.size > MAX_IMAGE) throw new Error(`${raw}: картинка больше 5 МБ`);
      blocks.push(imageBlock(readFileSync(abs), type));
    } else {
      let body = DOC_EXT.test(abs) ? readDocument(abs) : readFileSync(abs, 'utf8');   // PDF / Office: their text
      if (body.includes('\0')) continue;
      let attrs = `path="${raw}"`;
      if (from) { body = body.split('\n').slice(from - 1, Math.max(to, from)).join('\n'); attrs += ` lines="${from}-${Math.max(to, from)}"`; }
      blocks.push({ type: 'text', text: `<file ${attrs}>\n${body.length > MAX_TEXT ? body.slice(0, MAX_TEXT) + '\n… (обрезано)' : body}\n</file>` });
    }
    attached.push(full);
  }
  blocks.push(...extra);
  if (!blocks.length) return { content: text, attached };
  return { content: [...blocks, { type: 'text', text }], attached };
}

/** A PNG from the clipboard (macOS, Windows, Linux with wl-paste or xclip), or null. */
export function clipboardImage(platform = process.platform) {
  const run = (cmd, args, opts = {}) => { try { return execFileSync(cmd, args, { stdio: ['ignore', 'pipe', 'ignore'], maxBuffer: 64 * 1024 * 1024, timeout: 10000, ...opts }); } catch { return null; } };
  if (platform === 'darwin') {
    const out = run('osascript', ['-e', 'the clipboard as «class PNGf»'], { encoding: 'utf8' });
    const hex = /«data PNGf([0-9A-Fa-f]+)»/.exec(out || '')?.[1];
    return hex ? Buffer.from(hex, 'hex') : null;
  }
  if (platform === 'win32') {
    const ps = 'Add-Type -AssemblyName System.Windows.Forms,System.Drawing; $i=[Windows.Forms.Clipboard]::GetImage(); if($i){$m=New-Object IO.MemoryStream; $i.Save($m,[Drawing.Imaging.ImageFormat]::Png); [Convert]::ToBase64String($m.ToArray())}';
    const b64 = run('powershell', ['-NoProfile', '-STA', '-Command', ps], { encoding: 'utf8' })?.trim();
    return b64 ? Buffer.from(b64, 'base64') : null;
  }
  const buf = run('wl-paste', ['--type', 'image/png']) || run('xclip', ['-selection', 'clipboard', '-t', 'image/png', '-o']);
  return buf?.length && buf.subarray(0, 4).toString('hex') === '89504e47' ? buf : null;
}

/* ---------------- saved chats ---------------- */

const sessDir = (cwd, env) => join(env.KLINCH_HOME || join(homedir(), '.klinch'), 'sessions', createHash('sha1').update(cwd).digest('hex').slice(0, 12));

export function saveSession({ id, cwd, model, messages }, env = process.env) {
  if (!messages.length) return;
  const dir = sessDir(cwd, env);
  mkdirSync(dir, { recursive: true, mode: 0o700 });
  const p = join(dir, id + '.json');
  writeFileSync(p, JSON.stringify({ id, cwd, model, updated: Date.now(), messages }), { mode: 0o600 });
  try { chmodSync(p, 0o600); } catch { /* Windows */ }
}

/** Saved chats of this folder, newest first: [{ id, updated, title }]. */
export function listSessions(cwd, env = process.env) {
  const dir = sessDir(cwd, env);
  let files; try { files = readdirSync(dir).filter((f) => f.endsWith('.json')); } catch { return []; }
  return files.map((f) => {
    try {
      const s = JSON.parse(readFileSync(join(dir, f), 'utf8'));
      const first = s.messages.find((m) => m.role === 'user');
      const t = typeof first?.content === 'string' ? first.content : (first?.content || []).filter((b) => b.type === 'text').map((b) => b.text).pop() || '';
      return { id: s.id, updated: s.updated, model: s.model, messages: s.messages, title: t.replace(/\s+/g, ' ').slice(0, 70) };
    } catch { return null; }
  }).filter(Boolean).sort((a, b) => b.updated - a.updated);
}
