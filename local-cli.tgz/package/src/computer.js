// Computer use: the agent sees the screen and moves the mouse and keyboard, for apps that are not a web page
// (Figma desktop, a simulator, system settings, an installer). No dependencies: macOS uses screencapture, sips and
// JavaScript for Automation (CoreGraphics events); Windows uses PowerShell (System.Drawing + user32); Linux (X11)
// uses xdotool and ImageMagick or scrot. Every action except looking at the screen asks the user first.
import { execFile, spawn } from 'node:child_process';
import { readFileSync, unlinkSync, mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const MAX_SIDE = 1366;          // screenshots are scaled down so the long side fits; coordinates use this picture
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const imageBlock = (buf) => ({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: buf.toString('base64') } });

function run(cmd, args, { input, timeout = 20000, env } = {}) {
  return new Promise((resolve, reject) => {
    const p = execFile(cmd, args, { timeout, maxBuffer: 64 << 20, encoding: 'buffer', windowsHide: true, ...(env ? { env } : {}) }, (err, stdout, stderr) => {
      if (err) {
        const msg = String(stderr || '').trim().split('\n').slice(-3).join(' ') || err.message;
        reject(Object.assign(new Error(err.code === 'ENOENT' ? `нет программы ${cmd}` : msg), { code: err.code }));
      } else resolve(stdout);
    });
    if (input != null) { p.stdin.on('error', () => {}); p.stdin.end(input); }
  });
}

/** Width and height of a PNG or JPEG. */
export function imageSize(buf) {
  if (buf.length > 24 && buf.readUInt32BE(0) === 0x89504e47) return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) };
  if (buf[0] === 0xff && buf[1] === 0xd8) {
    let i = 2;
    while (i + 9 < buf.length) {
      if (buf[i] !== 0xff) { i++; continue; }
      const m = buf[i + 1];
      if (m === 0xd8 || m === 0x01 || (m >= 0xd0 && m <= 0xd7)) { i += 2; continue; }
      const len = buf.readUInt16BE(i + 2);
      if ((m >= 0xc0 && m <= 0xc3) || (m >= 0xc5 && m <= 0xc7) || (m >= 0xc9 && m <= 0xcb) || (m >= 0xcd && m <= 0xcf)) return { width: buf.readUInt16BE(i + 7), height: buf.readUInt16BE(i + 5) };
      i += 2 + len;
    }
  }
  return null;
}

/** Picture size for a screen: the long side at most MAX_SIDE, never enlarged. */
export function fitSize(w, h, max = MAX_SIDE) {
  const k = Math.min(1, max / Math.max(w, h));
  return { width: Math.round(w * k), height: Math.round(h * k) };
}

// ── Keys ─────────────────────────────────────────────────────────────────────────────────────────────────────
const KEY_ALIAS = { return: 'enter', esc: 'escape', del: 'delete', bs: 'backspace', arrowup: 'up', arrowdown: 'down', arrowleft: 'left', arrowright: 'right',
  pgup: 'pageup', pgdn: 'pagedown', control: 'ctrl', command: 'cmd', meta: 'cmd', super: 'cmd', win: 'cmd', windows: 'cmd', option: 'alt', opt: 'alt', spacebar: 'space' };
const MOD_NAMES = new Set(['ctrl', 'alt', 'shift', 'cmd']);

/** «Ctrl+Shift+T» → { mods: ['ctrl','shift'], key: 't' }. `cmd` is ⌘ on macOS and the Windows key elsewhere. */
export function parseCombo(combo) {
  const parts = String(combo || '').split('+').map((x) => x.trim().toLowerCase()).filter(Boolean).map((x) => KEY_ALIAS[x] || x);
  if (!parts.length) throw new Error('Нужен key, например Enter или Ctrl+C');
  const key = parts.pop();
  for (const m of parts) if (!MOD_NAMES.has(m)) throw new Error(`Не знаю модификатор ${m}: есть Ctrl, Alt, Shift, Cmd`);
  return { mods: parts, key };
}

const X_KEYS = { enter: 'Return', escape: 'Escape', tab: 'Tab', backspace: 'BackSpace', delete: 'Delete', space: 'space', up: 'Up', down: 'Down', left: 'Left', right: 'Right',
  home: 'Home', end: 'End', pageup: 'Prior', pagedown: 'Next', insert: 'Insert', capslock: 'Caps_Lock', printscreen: 'Print', menu: 'Menu' };
const X_MODS = { ctrl: 'ctrl', alt: 'alt', shift: 'shift', cmd: 'super' };
/** xdotool key name: «ctrl+shift+t», «Return», «F5». */
export function xdotoolKey({ mods, key }) {
  const k = X_KEYS[key] || (/^f\d{1,2}$/.test(key) ? key.toUpperCase() : key.length === 1 ? key : null);
  if (!k) throw new Error(`Не знаю клавишу ${key}`);
  return [...mods.map((m) => X_MODS[m]), k].join('+');
}

// macOS virtual key codes (US layout positions; shortcuts work the same on other layouts).
const MAC_CODES = { a: 0, s: 1, d: 2, f: 3, h: 4, g: 5, z: 6, x: 7, c: 8, v: 9, b: 11, q: 12, w: 13, e: 14, r: 15, y: 16, t: 17, 1: 18, 2: 19, 3: 20, 4: 21, 6: 22,
  5: 23, '=': 24, 9: 25, 7: 26, '-': 27, 8: 28, 0: 29, ']': 30, o: 31, u: 32, '[': 33, i: 34, p: 35, l: 37, j: 38, "'": 39, k: 40, ';': 41, '\\': 42, ',': 43,
  '/': 44, n: 45, m: 46, '.': 47, '`': 50, enter: 36, tab: 48, space: 49, backspace: 51, escape: 53, delete: 117, home: 115, end: 119, pageup: 116, pagedown: 121,
  left: 123, right: 124, down: 125, up: 126, f1: 122, f2: 120, f3: 99, f4: 118, f5: 96, f6: 97, f7: 98, f8: 100, f9: 101, f10: 109, f11: 103, f12: 111 };
const MAC_FLAGS = { cmd: '$.kCGEventFlagMaskCommand', ctrl: '$.kCGEventFlagMaskControl', alt: '$.kCGEventFlagMaskAlternate', shift: '$.kCGEventFlagMaskShift' };

// Windows virtual-key codes.
const WIN_VK = { enter: 0x0d, escape: 0x1b, tab: 0x09, backspace: 0x08, delete: 0x2e, space: 0x20, up: 0x26, down: 0x28, left: 0x25, right: 0x27, home: 0x24, end: 0x23,
  pageup: 0x21, pagedown: 0x22, insert: 0x2d, printscreen: 0x2c, menu: 0x5d, ctrl: 0x11, alt: 0x12, shift: 0x10, cmd: 0x5b,
  '-': 0xbd, '=': 0xbb, '[': 0xdb, ']': 0xdd, ';': 0xba, "'": 0xde, ',': 0xbc, '.': 0xbe, '/': 0xbf, '\\': 0xdc, '`': 0xc0 };
function winVk(key) {
  if (WIN_VK[key]) return WIN_VK[key];
  if (/^f\d{1,2}$/.test(key)) return 0x6f + +key.slice(1);
  if (/^[a-z0-9]$/.test(key)) return key.toUpperCase().charCodeAt(0);
  throw new Error(`Не знаю клавишу ${key}`);
}

// ── Platforms ────────────────────────────────────────────────────────────────────────────────────────────────
// Each backend works in real screen coordinates: { size(), shot() → jpeg Buffer, move, click, down, up, scroll, type, key }.

function linuxBackend(env) {
  if (!env.DISPLAY) {
    throw new Error(env.WAYLAND_DISPLAY ? 'Управление экраном работает только в X11: в Wayland войдите в сеанс «Xorg» или запустите приложение через XWayland.'
      : 'Нет экрана (нет DISPLAY): управлять компьютером можно только в графическом сеансе.');
  }
  // xdotool reads typed text in the locale's encoding: without a UTF-8 locale Cyrillic fails («Invalid multi-byte sequence»).
  const xenv = { ...process.env, ...env, LC_ALL: /utf-?8/i.test(env.LC_ALL || env.LANG || '') ? (env.LC_ALL || env.LANG) : 'C.UTF-8' };
  const xdo = async (...a) => { try { return await run('xdotool', a, { env: xenv }); } catch (e) { if (e.code === 'ENOENT') throw new Error('Нужна программа xdotool: sudo apt install xdotool (или dnf/pacman install xdotool)'); throw e; } };
  return {
    async size() { const [w, h] = String(await xdo('getdisplaygeometry')).trim().split(/\s+/).map(Number); return { width: w, height: h }; },
    async shot(w, h) {
      const dir = mkdtempSync(join(tmpdir(), 'agent-shot-')), f = join(dir, 's.jpg');
      try {
        try { return await run('import', ['-silent', '-window', 'root', '-resize', `${w}x${h}!`, '-quality', '80', 'jpg:-']); } catch (e) { if (e.code !== 'ENOENT') throw e; }
        try { await run('scrot', ['-o', '-q', '80', f]); } catch (e) {
          if (e.code === 'ENOENT') throw new Error('Для снимка экрана нужен ImageMagick или scrot: sudo apt install imagemagick');
          throw e;
        }
        return readFileSync(f);
      } finally { try { unlinkSync(f); } catch { /* none */ } }
    },
    move: (x, y) => xdo('mousemove', String(x), String(y)),
    async click(x, y, button, count) { await xdo('mousemove', String(x), String(y)); await xdo('click', '--repeat', String(count), '--delay', '80', String({ left: 1, middle: 2, right: 3 }[button])); },
    down: (button) => xdo('mousedown', String({ left: 1, middle: 2, right: 3 }[button])),
    up: (button) => xdo('mouseup', String({ left: 1, middle: 2, right: 3 }[button])),
    async scroll(x, y, dx, dy) {
      await xdo('mousemove', String(x), String(y));
      if (dy) await xdo('click', '--repeat', String(Math.abs(dy)), '--delay', '20', dy > 0 ? '5' : '4');
      if (dx) await xdo('click', '--repeat', String(Math.abs(dx)), '--delay', '20', dx > 0 ? '7' : '6');
    },
    async type(text) {
      const t = String(text);
      // ASCII is typed key by key. Other letters (Cyrillic on an English layout) are mapped to a spare key by
      // xdotool, and older xdotool drops some of them, so such text is pasted through the clipboard when xclip or
      // xsel is installed (the old clipboard text is put back), else typed and hoped for.
      if (/^[\x20-\x7e\n]*$/.test(t)) {
        const lines = t.split('\n');
        for (let i = 0; i < lines.length; i++) { if (i) await xdo('key', 'Return'); if (lines[i]) await xdo('type', '--delay', '12', '--', lines[i]); }
        return;
      }
      const clip = [['xclip', ['-selection', 'clipboard'], ['-selection', 'clipboard', '-o']], ['xsel', ['--clipboard', '--input'], ['--clipboard', '--output']]];
      for (const [cmd, put, get] of clip) {
        const old = await run(cmd, get, { env: xenv, timeout: 3000 }).catch((e) => (e.code === 'ENOENT' ? undefined : null));
        if (old === undefined) continue;
        // xclip stays alive to serve the clipboard: it is not waited for.
        const p = spawn(cmd, put, { env: xenv, stdio: ['pipe', 'ignore', 'ignore'], detached: true }); p.on('error', () => {}); p.stdin.end(t); p.unref();
        await sleep(150);
        await xdo('key', '--clearmodifiers', 'ctrl+v');
        await sleep(250);
        if (old != null) { const q = spawn(cmd, put, { env: xenv, stdio: ['pipe', 'ignore', 'ignore'], detached: true }); q.on('error', () => {}); q.stdin.end(old); q.unref(); }
        return;
      }
      await xdo('type', '--delay', '30', '--', t);
    },
    key: (combo) => xdo('key', '--clearmodifiers', xdotoolKey(combo)),
    async cursor() { const o = String(await xdo('getmouselocation', '--shell')); return { x: +/X=(\d+)/.exec(o)[1], y: +/Y=(\d+)/.exec(o)[1] }; },
    open: (app) => { const p = spawn(app, [], { detached: true, stdio: 'ignore' }); p.on('error', () => {}); p.unref(); },
  };
}

function macBackend() {
  const jxa = async (body) => {
    try { return String(await run('osascript', ['-l', 'JavaScript', '-e', `ObjC.import('CoreGraphics');ObjC.import('AppKit');${body}`])).trim(); } catch (e) {
      if (/not allowed|1002|assistive|-25211|-1743/i.test(e.message)) throw new Error('macOS не разрешил управлять мышью и клавиатурой. Системные настройки → Конфиденциальность и безопасность → Универсальный доступ: включите свой терминал (или VS Code), затем повторите.');
      throw e;
    }
  };
  const post = (type, x, y, button, clicks = 1) => `{var e=$.CGEventCreateMouseEvent(null,${type},{x:${x},y:${y}},${button});$.CGEventSetIntegerValueField(e,$.kCGMouseEventClickState,${clicks});$.CGEventPost($.kCGHIDEventTap,e);}`;
  const BTN = { left: ['$.kCGEventLeftMouseDown', '$.kCGEventLeftMouseUp', '$.kCGMouseButtonLeft', '$.kCGEventLeftMouseDragged'],
    right: ['$.kCGEventRightMouseDown', '$.kCGEventRightMouseUp', '$.kCGMouseButtonRight', '$.kCGEventRightMouseDragged'],
    middle: ['$.kCGEventOtherMouseDown', '$.kCGEventOtherMouseUp', '$.kCGMouseButtonCenter', '$.kCGEventOtherMouseDragged'] };
  let held = null;
  const here = 'var p=$.CGEventGetLocation($.CGEventCreate(null));';
  return {
    async size() { const s = JSON.parse(await jxa('var f=$.NSScreen.mainScreen.frame;JSON.stringify({width:f.size.width,height:f.size.height})')); return s; },
    async shot(w, h) {
      const dir = mkdtempSync(join(tmpdir(), 'agent-shot-')), f = join(dir, 's.jpg');
      try {
        try { await run('screencapture', ['-x', '-m', '-t', 'jpg', f]); } catch (e) { throw new Error(`Снимок экрана не получился (${e.message}). Разрешите запись экрана: Системные настройки → Конфиденциальность и безопасность → Запись экрана → ваш терминал.`); }
        await run('sips', ['-z', String(h), String(w), '-s', 'formatOptions', '80', f]).catch(() => {});
        return readFileSync(f);
      } finally { try { unlinkSync(f); } catch { /* none */ } }
    },
    move: (x, y) => jxa(post(held ? BTN[held][3] : '$.kCGEventMouseMoved', x, y, held ? BTN[held][2] : '$.kCGMouseButtonLeft')),
    async click(x, y, button, count) {
      const b = BTN[button]; let s = post('$.kCGEventMouseMoved', x, y, b[2]);
      for (let i = 1; i <= count; i++) s += post(b[0], x, y, b[2], i) + post(b[1], x, y, b[2], i);
      await jxa(s);
    },
    async down(button) { held = button; await jxa(`${here}${post(BTN[button][0], 'p.x', 'p.y', BTN[button][2])}`); },
    async up(button) { held = null; await jxa(`${here}${post(BTN[button][1], 'p.x', 'p.y', BTN[button][2])}`); },
    async scroll(x, y, dx, dy) {
      // CGEventCreateScrollWheelEvent2 (macOS 13+) is not variadic, so JXA can call it. Positive dy = down.
      await jxa(`${post('$.kCGEventMouseMoved', x, y, '$.kCGMouseButtonLeft')}var e=$.CGEventCreateScrollWheelEvent2(null,$.kCGScrollEventUnitLine,2,${-dy * 3},${-dx * 3},0);$.CGEventPost($.kCGHIDEventTap,e);`);
    },
    async type(text) {
      // Plain ASCII is typed key by key (System Events). Other text (Cyrillic, emoji) is pasted: the clipboard is
      // saved, the text pasted with ⌘V, and the old clipboard text put back.
      const t = String(text);
      if (/^[\x20-\x7e\n]*$/.test(t)) {
        const lines = t.split('\n').map((l) => `keystroke ${JSON.stringify(l)}`);
        await run('osascript', ['-e', `tell application "System Events"\n${lines.join('\nkey code 36\n')}\nend tell`]);
        return;
      }
      const old = await run('pbpaste', []).catch(() => null);
      await run('pbcopy', [], { input: t });
      await jxa(`var d=$.CGEventCreateKeyboardEvent(null,9,true);$.CGEventSetFlags(d,$.kCGEventFlagMaskCommand);$.CGEventPost($.kCGHIDEventTap,d);var u=$.CGEventCreateKeyboardEvent(null,9,false);$.CGEventSetFlags(u,$.kCGEventFlagMaskCommand);$.CGEventPost($.kCGHIDEventTap,u);`);
      await sleep(300);
      if (old != null) await run('pbcopy', [], { input: old }).catch(() => {});
    },
    async key({ mods, key }) {
      const code = MAC_CODES[key];
      if (code == null) throw new Error(`Не знаю клавишу ${key}`);
      const flags = mods.map((m) => MAC_FLAGS[m]).join('|') || '0';
      await jxa(`var d=$.CGEventCreateKeyboardEvent(null,${code},true);$.CGEventSetFlags(d,${flags});$.CGEventPost($.kCGHIDEventTap,d);`
        + `var u=$.CGEventCreateKeyboardEvent(null,${code},false);$.CGEventSetFlags(u,${flags});$.CGEventPost($.kCGHIDEventTap,u);`);
    },
    async cursor() { const o = JSON.parse(await jxa(`${here}JSON.stringify({x:p.x,y:p.y})`)); return { x: Math.round(o.x), y: Math.round(o.y) }; },
    open: (app) => run('open', ['-a', app]),
  };
}

const WIN_PRELUDE = `$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms,System.Drawing
Add-Type @'
using System; using System.Runtime.InteropServices;
public static class U {
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, int dx, int dy, int d, UIntPtr e);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte s, uint f, UIntPtr e);
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
}
'@
[void][U]::SetProcessDPIAware()
`;
function winBackend() {
  // Not through stdin: «-Command -» runs line by line and silently drops the Add-Type here-string, so nothing prints
  // (seen on windows-latest). -EncodedCommand keeps the script whole and Unicode text intact; a script too long for
  // the command line goes to a temporary .ps1 with a BOM (Windows PowerShell reads a file without one as ANSI).
  const ps = (body) => {
    const script = WIN_PRELUDE + body, enc = Buffer.from(script, 'utf16le').toString('base64');
    const base = ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass'];
    if (enc.length < 30000) return run('powershell.exe', [...base, '-EncodedCommand', enc], { timeout: 30000 });
    const file = join(mkdtempSync(join(tmpdir(), 'agent-ps-')), 'run.ps1');
    writeFileSync(file, '\ufeff' + script, 'utf8');
    return run('powershell.exe', [...base, '-File', file], { timeout: 30000 }).finally(() => { try { unlinkSync(file); } catch { /* gone */ } });
  };
  const FLAGS = { left: [0x02, 0x04], right: [0x08, 0x10], middle: [0x20, 0x40] };
  const q = (s) => `'${String(s).replace(/'/g, "''")}'`;
  return {
    async size() { const o = String(await ps('$b=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds; "$($b.Width) $($b.Height)"')).trim().split(/\s+/).map(Number); return { width: o[0], height: o[1] }; },
    async shot(w, h) {
      const out = await ps(`$b=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds
$bmp=New-Object System.Drawing.Bitmap $b.Width,$b.Height; $g=[System.Drawing.Graphics]::FromImage($bmp); $g.CopyFromScreen($b.Location,[System.Drawing.Point]::Empty,$b.Size)
$s=New-Object System.Drawing.Bitmap ${w},${h}; $g2=[System.Drawing.Graphics]::FromImage($s); $g2.InterpolationMode='HighQualityBicubic'; $g2.DrawImage($bmp,0,0,${w},${h})
$ms=New-Object System.IO.MemoryStream; $enc=[System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders()|?{$_.MimeType -eq 'image/jpeg'}
$p=New-Object System.Drawing.Imaging.EncoderParameters 1; $p.Param[0]=New-Object System.Drawing.Imaging.EncoderParameter ([System.Drawing.Imaging.Encoder]::Quality),80L
$s.Save($ms,$enc,$p); [Console]::Out.Write([Convert]::ToBase64String($ms.ToArray()))`);
      return Buffer.from(String(out).trim(), 'base64');
    },
    move: (x, y) => ps(`[void][U]::SetCursorPos(${x},${y})`),
    click: (x, y, button, count) => ps(`[void][U]::SetCursorPos(${x},${y}); Start-Sleep -Milliseconds 40\n`
      + Array.from({ length: count }, () => `[U]::mouse_event(${FLAGS[button][0]},0,0,0,[UIntPtr]::Zero); [U]::mouse_event(${FLAGS[button][1]},0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 60`).join('\n')),
    down: (button) => ps(`[U]::mouse_event(${FLAGS[button][0]},0,0,0,[UIntPtr]::Zero)`),
    up: (button) => ps(`[U]::mouse_event(${FLAGS[button][1]},0,0,0,[UIntPtr]::Zero)`),
    scroll: (x, y, dx, dy) => ps(`[void][U]::SetCursorPos(${x},${y})\n${dy ? `[U]::mouse_event(0x0800,0,0,${-dy * 120},[UIntPtr]::Zero)\n` : ''}${dx ? `[U]::mouse_event(0x01000,0,0,${dx * 120},[UIntPtr]::Zero)` : ''}`),
    // SendKeys treats + ^ % ~ ( ) { } [ ] as commands: each is wrapped in braces so the text is typed as is.
    type: (text) => ps(`[System.Windows.Forms.SendKeys]::SendWait(${q(String(text).replace(/[+^%~(){}[\]]/g, '{$&}').replace(/\r?\n/g, '{ENTER}'))})`),
    key: ({ mods, key }) => {
      const vks = [...mods.map((m) => WIN_VK[m]), winVk(key)];
      return ps([...vks.map((v) => `[U]::keybd_event(${v},0,0,[UIntPtr]::Zero)`), ...vks.reverse().map((v) => `[U]::keybd_event(${v},0,2,[UIntPtr]::Zero)`)].join('\n'));
    },
    async cursor() { const o = String(await ps('$p=New-Object U+POINT; [void][U]::GetCursorPos([ref]$p); "$($p.X) $($p.Y)"')).trim().split(/\s+/).map(Number); return { x: o[0], y: o[1] }; },
    open: (app) => ps(`Start-Process ${q(app)}`),
  };
}

// ── The tool ─────────────────────────────────────────────────────────────────────────────────────────────────
let backendCache = null;
let view = null;                 // { sw, sh, iw, ih }: real screen size and the picture size the model sees

/** The backend for this computer (tests pass their own). */
export function getBackend(env = process.env, platform = process.platform) {
  if (env.__AGENT_COMPUTER_BACKEND) return env.__AGENT_COMPUTER_BACKEND;
  if (backendCache) return backendCache;
  backendCache = platform === 'darwin' ? macBackend() : platform === 'win32' ? winBackend() : linuxBackend(env);
  return backendCache;
}
export function resetComputer() { backendCache = null; view = null; }

async function ensureView(be) {
  if (view) return view;
  const s = await be.size();
  if (!s?.width || !s?.height) throw new Error('Не удалось узнать размер экрана');
  const f = fitSize(s.width, s.height);
  view = { sw: s.width, sh: s.height, iw: f.width, ih: f.height };
  return view;
}
/** Picture coordinates (what the model saw) → real screen coordinates. */
export function toScreen(v, x, y) {
  const n = (a, b) => { if (a == null || !Number.isFinite(+a)) throw new Error('Нужны x и y (точка на последнем скриншоте)'); return Math.round(Math.min(Math.max(+a, 0), b - 1)); };
  return { x: n(x * (v.sw / v.iw), v.sw), y: n(y * (v.sh / v.ih), v.sh) };
}
const fromScreen = (v, p) => ({ x: Math.round(p.x * (v.iw / v.sw)), y: Math.round(p.y * (v.ih / v.sh)) });

const ACTIONS = ['screenshot', 'click', 'double_click', 'right_click', 'move', 'drag', 'type', 'key', 'scroll', 'cursor', 'open_app', 'wait'];
const LOOK = new Set(['screenshot', 'cursor', 'wait']);

async function shot(be, v, note = '') {
  const buf = await be.shot(v.iw, v.ih);
  const real = imageSize(buf);
  // A backend that could not scale returns the full picture: remember its size so clicks still land right.
  if (real && (real.width !== v.iw || real.height !== v.ih)) { v.iw = real.width; v.ih = real.height; }
  return [{ type: 'text', text: `${note}Экран ${v.iw}×${v.ih} (координаты x,y для действий берите с этой картинки).` }, imageBlock(buf)];
}

export const COMPUTER_TOOL = {
  name: 'computer',
  description: 'Управление компьютером пользователя: снимок экрана, мышь и клавиатура. Для программ, которые не сайт (приложения, симулятор, настройки, установщик); '
    + 'для сайтов лучше инструмент browser. action: screenshot (снимок главного экрана), click / double_click / right_click (x, y), move (x, y), '
    + 'drag (x, y → to_x, to_y), type (text: ввести текст туда, где курсор ввода), key (Enter, Escape, Tab, Ctrl+C, Cmd+Space, Alt+Tab, F5…), '
    + 'scroll (x, y, dy: строк вниз, отрицательное вверх; dx вбок), cursor (где мышь), open_app (name: программа), wait (sec). '
    + 'Координаты берутся с последнего screenshot. Начни со screenshot, после каждого действия смотри новый screenshot (действия click, type, key, scroll, drag возвращают его сами). '
    + 'Пароли, коды и платёжные данные не вводи никогда: попроси пользователя ввести их самому. Каждое действие, кроме screenshot, cursor и wait, пользователь подтверждает.',
  input_schema: { type: 'object', properties: {
    action: { type: 'string', enum: ACTIONS },
    x: { type: 'number' }, y: { type: 'number' }, to_x: { type: 'number' }, to_y: { type: 'number' },
    button: { type: 'string', enum: ['left', 'right', 'middle'] }, text: { type: 'string' }, key: { type: 'string' },
    dx: { type: 'integer' }, dy: { type: 'integer' }, name: { type: 'string' }, sec: { type: 'number' } }, required: ['action'] },
  danger: (input = {}) => !LOOK.has(input.action),
  preview: (i = {}) => {
    const at = i.x != null ? ` ${Math.round(i.x)},${Math.round(i.y)}` : '';
    const to = i.to_x != null ? ` → ${Math.round(i.to_x)},${Math.round(i.to_y)}` : '';
    const what = i.action === 'type' ? ` «${String(i.text ?? '').slice(0, 60)}»` : i.action === 'key' ? ` ${i.key}` : i.action === 'open_app' ? ` ${i.name}` : i.action === 'scroll' ? ` dy=${i.dy || 0}${i.dx ? ` dx=${i.dx}` : ''}` : '';
    return `computer ${i.action}${at}${to}${what}`;
  },
  async run(input, ctx = {}) {
    const a = input.action, env = ctx.env || process.env;
    if (!ACTIONS.includes(a)) throw new Error(`Неизвестное действие ${a}. Есть: ${ACTIONS.join(', ')}`);
    const be = getBackend(env);
    const v = await ensureView(be);
    const after = async (text) => { await sleep(+env.KLINCH_COMPUTER_SETTLE_MS || 500); return shot(be, v, text + '\n'); };
    switch (a) {
      case 'screenshot': return shot(be, v);
      case 'cursor': { const p = fromScreen(v, await be.cursor()); return `Мышь в точке ${p.x},${p.y}`; }
      case 'wait': await sleep(Math.min(Math.max(+input.sec || 1, 0.1), 30) * 1000); return shot(be, v, 'Подождал.\n');
      case 'click': case 'double_click': case 'right_click': {
        const p = toScreen(v, input.x, input.y);
        const button = a === 'right_click' ? 'right' : input.button || 'left';
        await be.click(p.x, p.y, button, a === 'double_click' ? 2 : 1);
        return after(`Нажал ${button === 'right' ? 'правой кнопкой ' : ''}${a === 'double_click' ? 'дважды ' : ''}в ${Math.round(input.x)},${Math.round(input.y)}.`);
      }
      case 'move': { const p = toScreen(v, input.x, input.y); await be.move(p.x, p.y); return `Мышь в ${Math.round(input.x)},${Math.round(input.y)}`; }
      case 'drag': {
        const p1 = toScreen(v, input.x, input.y), p2 = toScreen(v, input.to_x, input.to_y), button = input.button || 'left';
        await be.move(p1.x, p1.y); await be.down(button);
        try {
          for (let i = 1; i <= 8; i++) { await be.move(Math.round(p1.x + (p2.x - p1.x) * i / 8), Math.round(p1.y + (p2.y - p1.y) * i / 8)); await sleep(25); }
        } finally { await be.up(button); }
        return after(`Перетащил ${Math.round(input.x)},${Math.round(input.y)} → ${Math.round(input.to_x)},${Math.round(input.to_y)}.`);
      }
      case 'type': {
        if (input.text == null || input.text === '') throw new Error('Нужен text');
        await be.type(String(input.text));
        return after('Ввёл текст.');
      }
      case 'key': { await be.key(parseCombo(input.key)); return after(`Нажал ${input.key}.`); }
      case 'scroll': {
        const p = input.x != null ? toScreen(v, input.x, input.y) : await be.cursor();
        const dy = Math.max(-50, Math.min(50, Math.trunc(+input.dy || 0))), dx = Math.max(-50, Math.min(50, Math.trunc(+input.dx || 0)));
        if (!dy && !dx) throw new Error('Нужен dy (строк вниз, отрицательное вверх) или dx');
        await be.scroll(p.x, p.y, dx, dy);
        return after('Прокрутил.');
      }
      case 'open_app': {
        if (!input.name) throw new Error('Нужно name: имя программы');
        await be.open(String(input.name));
        await sleep(1500);
        return shot(be, v, `Запустил ${input.name}.\n`);
      }
      default: throw new Error(`Неизвестное действие ${a}`);
    }
  },
};
