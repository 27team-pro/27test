// `klinch github …`: the PR review bot (bugs like Bugbot, plus Security Review) and the agent that answers a mention
// in a PR or an issue, for GitHub Actions. `klinch github install` writes the ready workflow into the repository.
//
//   klinch github review [--security] [--security-only] [--fail] [--dry-run] [N]   review a PR, post inline comments
//   klinch github respond [--dry-run]                                         answer the mention that started the run
//   klinch github install [--force]  |  klinch github workflow                write / print .github/workflows/<cmd>.yml
//
// The words of the brand (the command, the mention, the markers) come from CMD and NAME, so a white-label copy of
// the CLI (worker/brand.js rebrandCliFile) gets its own everywhere.
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { join, dirname } from 'node:path';
import { textOf, tokensOf } from './multi.js';

export const CMD = 'klinch';
export const NAME = 'Klinch';
export const MENTION = '@' + CMD;
const mark = (k) => `<!-- ${CMD}:${k} -->`;
const clip = (s, n) => { s = String(s || ''); return s.length > n ? `${s.slice(0, n)}\n… (обрезано, всего ${s.length} символов)` : s; };

/* ---------------- GitHub REST ---------------- */

export function githubApi({ token, api = 'https://api.github.com', fetch: f = globalThis.fetch }) {
  return async function gh(method, path, body, accept) {
    const r = await f(api + path, {
      method,
      headers: {
        ...(token ? { authorization: `Bearer ${token}` } : {}), accept: accept || 'application/vnd.github+json', 'x-github-api-version': '2022-11-28',
        'user-agent': `${CMD}-code`, ...(body ? { 'content-type': 'application/json' } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await r.text();
    if (!r.ok) { const e = new Error(`GitHub ${method} ${path}: ${r.status} ${text.slice(0, 300)}`); e.status = r.status; throw e; }
    if (accept && !accept.includes('json')) return text;
    return text ? JSON.parse(text) : null;
  };
}

/** Up to `pages` pages of a list endpoint. */
async function all(gh, path, pages = 5) {
  const out = [];
  for (let p = 1; p <= pages; p++) {
    const part = await gh('GET', `${path}${path.includes('?') ? '&' : '?'}per_page=100&page=${p}`);
    out.push(...(part || []));
    if (!part || part.length < 100) break;
  }
  return out;
}

/* ---------------- diff ---------------- */

/** path → Set of line numbers of the new file that the diff shows (added or context): only these take inline comments. */
export function diffLines(diff) {
  const map = new Map();
  let file = null, n = 0, oldLeft = 0, newLeft = 0;
  for (const l of String(diff || '').split('\n')) {
    if (oldLeft > 0 || newLeft > 0) {
      if (l.startsWith('\\')) continue;
      if (l.startsWith('+')) { file && map.get(file).add(n); n++; newLeft--; }
      else if (l.startsWith('-')) oldLeft--;
      else { file && map.get(file).add(n); n++; oldLeft--; newLeft--; }
      continue;
    }
    if (l.startsWith('+++ ')) {
      const p = l.slice(4).trim().replace(/\t.*$/, '');
      file = p === '/dev/null' ? null : p.replace(/^b\//, '');
      if (file && !map.has(file)) map.set(file, new Set());
      continue;
    }
    const h = /^@@ -\d+(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/.exec(l);
    if (h) { oldLeft = h[1] == null ? 1 : +h[1]; n = +h[2]; newLeft = h[3] == null ? 1 : +h[3]; }
  }
  return map;
}

/* ---------------- the reviewers ---------------- */

const FORMAT = `Ответ: только JSON в блоке \`\`\`json, без текста вокруг:
{"summary": "1–3 предложения: что делает PR и общий вывод", "findings": [{"path": "путь/от/корня", "line": 42, "start_line": 40, "severity": "high|medium|low", "title": "коротко, что не так", "body": "почему это ошибка и при каких данных она проявится; как исправить", "suggestion": "необязательно: точная замена строк start_line..line (или одной line) целиком"}]}
line — номер строки в НОВОЙ версии файла, и он должен быть среди строк diff (добавленные или контекст). start_line только для замечания на несколько строк. suggestion только если уверен в точной замене, с теми же отступами. Нет замечаний — "findings": [].
Пиши на языке описания PR (нет описания — по-русски).`;

export const BUG_REVIEWER = {
  name: 'bugbot',
  prompt: `Ты ${NAME} Bugbot: ревьюер pull request'ов. Ищи только реальные ошибки, которые сломают работу: логика, граничные случаи, null и пустые значения, гонки, неверные вызовы и импорты, забытые места (функцию поменяли, а вызывающих нет), потеря данных, сломанная обратная совместимость, утечки ресурсов.
Каждое замечание проверь по коду: прочитай нужные файлы, вызывающих и вызываемых (read_file, search). Не пиши о стиле, именах, форматировании, комментариях, документации и «добавьте тесты». Одно ложное замечание хуже пропущенной мелочи: если не уверен, не пиши.
${FORMAT}`,
};

export const SECURITY_REVIEWER = {
  name: 'security-review',
  prompt: `Ты ${NAME} Security Review: проверяешь pull request на уязвимости, которые реально можно использовать. Ищи: инъекции (SQL, команды, шаблоны, путь к файлу), обход входа и проверки прав, IDOR, SSRF, XSS, небезопасную десериализацию, секреты и ключи в коде, слабую криптографию и случайность, утечку личных данных и токенов в логи или ответы, небезопасные настройки по умолчанию, доверие к данным пользователя.
Для каждой находки проследи по коду путь данных от входа до опасного места (read_file, search) и опиши сценарий атаки. Не пиши: DoS и ограничения частоты, теоретические риски без пути атаки, «нет усиленной защиты», уязвимости в тестах и примерах, устаревшие зависимости, мелкие советы. Только находки, в которых уверен на 80% и больше; severity high — эксплуатируется напрямую.
${FORMAT}`,
};

export function reviewTask({ repo, pr, diff }) {
  return `Pull request #${pr.number} в ${repo}: ${pr.title || ''}
Ветка ${pr.head?.ref || '?'} → ${pr.base?.ref || '?'}. Автор: ${pr.user?.login || '?'}.
${pr.body ? `Описание:\n${clip(pr.body, 4000)}\n` : ''}
Код этой ветки лежит в текущей папке. Изменения:

\`\`\`diff
${clip(diff, 120000)}
\`\`\``;
}

const SEVERITY = { high: 'важно', medium: 'стоит поправить', low: 'мелочь' };
const normSeverity = (s) => (['high', 'medium', 'low'].includes(String(s).toLowerCase()) ? String(s).toLowerCase() : 'medium');

/** The reviewer's answer → { summary, findings }; an answer that is not JSON becomes the summary. */
export function parseFindings(text) {
  const t = String(text || '');
  const m = /```(?:json)?\s*([\s\S]*?)```/.exec(t);
  const raw = m ? m[1] : t.slice(t.indexOf('{'), t.lastIndexOf('}') + 1);
  try {
    const j = JSON.parse(raw);
    const findings = (Array.isArray(j.findings) ? j.findings : []).filter((f) => f && f.path && f.title && Number.isFinite(+f.line)).map((f) => ({
      path: String(f.path).replace(/^\.?\//, '').replace(/^b\//, ''), line: Math.floor(+f.line),
      start_line: Number.isFinite(+f.start_line) && +f.start_line > 0 && +f.start_line < +f.line ? Math.floor(+f.start_line) : null,
      severity: normSeverity(f.severity), title: String(f.title).trim(), body: String(f.body || '').trim(),
      suggestion: typeof f.suggestion === 'string' && f.suggestion.length ? f.suggestion.replace(/\n$/, '') : null,
    }));
    return { summary: String(j.summary || '').trim(), findings };
  } catch { return { summary: t.trim(), findings: [] }; }
}

export const fingerprint = (kind, f) => createHash('sha1').update(`${kind}\n${f.path}\n${f.title.toLowerCase().replace(/\s+/g, ' ')}`).digest('hex').slice(0, 12);

function commentBody(kind, f) {
  const tag = kind === 'security' ? `уязвимость, ${SEVERITY[f.severity]}` : SEVERITY[f.severity];
  return `**[${tag}] ${f.title}**\n\n${f.body}${f.suggestion != null ? `\n\n\`\`\`suggestion\n${f.suggestion}\n\`\`\`` : ''}\n\n${mark('f:' + fingerprint(kind, f))}`;
}

/** Findings → inline comments (lines the diff shows) and the rest for the summary; known findings are skipped. */
export function buildReview(kind, findings, lines, known = new Set()) {
  const comments = [], outside = [], fresh = [];
  for (const f of findings) {
    if (known.has(fingerprint(kind, f))) continue;
    fresh.push(f);
    const set = lines.get(f.path);
    const inDiff = set?.has(f.line) && (!f.start_line || [...Array(f.line - f.start_line + 1).keys()].every((i) => set.has(f.start_line + i)));
    if (inDiff) comments.push({ path: f.path, line: f.line, side: 'RIGHT', ...(f.start_line ? { start_line: f.start_line, start_side: 'RIGHT' } : {}), body: commentBody(kind, f) });
    else outside.push(f);
  }
  return { comments, outside, fresh };
}

const TITLES = { bugs: `${NAME} Bugbot`, security: `${NAME} Security Review` };

export function summaryBody(kind, { summary, findings, outside, posted, spent, runUrl }) {
  const head = `### ${TITLES[kind]}\n\n${summary || ''}`;
  const count = findings.length ? `Замечаний: ${findings.length}${posted ? `, в коде: ${posted}` : ''}.` : 'Замечаний нет.';
  const rest = outside.length ? `\n\n${outside.map((f) => `- **[${kind === 'security' ? 'уязвимость, ' : ''}${SEVERITY[f.severity]}] ${f.title}** \`${f.path}:${f.line}\`\n  ${f.body.replace(/\n/g, '\n  ')}`).join('\n')}` : '';
  const foot = [spent ? `${spent.toLocaleString('ru-RU')} токенов` : '', runUrl ? `[лог](${runUrl})` : ''].filter(Boolean).join(' · ');
  return `${head}\n\n${count}${rest}${foot ? `\n\n<sub>${foot}</sub>` : ''}\n\n${mark(kind)}`;
}

/* ---------------- the event ---------------- */

export function readEvent(env) {
  const path = env.GITHUB_EVENT_PATH;
  let payload = {};
  if (path) try { payload = JSON.parse(readFileSync(path, 'utf8')); } catch { /* no event file */ }
  return { name: env.GITHUB_EVENT_NAME || '', payload };
}

export function repoOf(env, payload, cwd) {
  if (payload?.repository?.full_name) return payload.repository.full_name;
  if (env.GITHUB_REPOSITORY) return env.GITHUB_REPOSITORY;
  try {
    const url = execFileSync('git', ['remote', 'get-url', 'origin'], { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    return /github\.com[:/]([^/]+\/[^/.]+?)(?:\.git)?$/.exec(url)?.[1] || null;
  } catch { return null; }
}

const TRUSTED = new Set(['OWNER', 'MEMBER', 'COLLABORATOR']);

/** What the mention asks for, or null when this event is not a mention for us (or from someone we don't serve). */
export function parseMention(name, p, { anyone = false } = {}) {
  let text = '', who = null, assoc = '', comment = null, isPr = false, number = null, thread = null;
  if (name === 'issue_comment') { comment = p.comment; text = p.comment?.body; who = p.comment?.user; assoc = p.comment?.author_association; isPr = !!p.issue?.pull_request; number = p.issue?.number; }
  else if (name === 'pull_request_review_comment') { comment = p.comment; text = p.comment?.body; who = p.comment?.user; assoc = p.comment?.author_association; isPr = true; number = p.pull_request?.number; thread = { path: p.comment?.path, line: p.comment?.line ?? p.comment?.original_line, hunk: p.comment?.diff_hunk }; }
  else if (name === 'pull_request_review') { text = p.review?.body; who = p.review?.user; assoc = p.review?.author_association; isPr = true; number = p.pull_request?.number; }
  else if (name === 'issues') { text = `${p.issue?.title || ''}\n${p.issue?.body || ''}`; who = p.issue?.user; assoc = p.issue?.author_association; number = p.issue?.number; }
  else return null;
  text = String(text || '');
  const re = new RegExp(`(^|[^\\w@/.-])${MENTION}(?![\\w-])`, 'i');
  if (!re.test(text) || !number) return null;
  if (who?.type === 'Bot' || text.includes(mark('reply'))) return null;
  if (!anyone && !TRUSTED.has(String(assoc).toUpperCase())) return { denied: true, who: who?.login, number, isPr };
  const ask = text.replace(new RegExp(`(^|[^\\w@/.-])${MENTION}(?![\\w-])`, 'gi'), '$1').trim();
  return { ask, who: who?.login, number, isPr, comment, thread, kind: name };
}

/** «review», «ревью», «проверь безопасность»… after the mention: a review instead of a task. */
export function reviewIntent(ask) {
  const a = String(ask || '').trim().toLowerCase();
  if (/^(security|security[- ]review|безопасность|проверь безопасность|аудит безопасности)([\s.!,]|$)/.test(a)) return 'security';
  if (/^(review|ревью|проверь( pr| пр| изменения)?|bugbot)([\s.!,]|$)/.test(a)) return /security|безопасн/.test(a) ? 'all' : 'bugs';
  return null;
}

export function taskPrompt({ repo, m, issue, pr, diff, history }) {
  const where = m.isPr ? `pull request #${m.number}` : `issue #${m.number}`;
  return `Тебя позвали в GitHub (${repo}, ${where}). Просит @${m.who}.
Заголовок: ${(pr || issue)?.title || ''}
${(pr || issue)?.body ? `Описание:\n${clip((pr || issue).body, 6000)}\n` : ''}${pr ? `Ветка ${pr.head?.ref} → ${pr.base?.ref}. Изменения PR:\n\`\`\`diff\n${clip(diff, 60000)}\n\`\`\`\n` : ''}${m.thread ? `Комментарий к ${m.thread.path}:${m.thread.line}, фрагмент:\n\`\`\`diff\n${clip(m.thread.hunk, 3000)}\n\`\`\`\n` : ''}${history ? `Последние комментарии:\n${history}\n` : ''}
Просьба: ${m.ask || 'посмотри и помоги'}

Код репозитория в текущей папке${pr ? ' (ветка этого PR)' : ''}. Сделай, что просят. Если нужны правки, внеси их в файлы и проверь (тесты, сборка). git commit и git push не запускай: изменения закоммитит и отправит обвязка. Если просят только ответить, ничего не меняй.
В конце напиши ответ для GitHub (Markdown, коротко): что сделано или ответ на вопрос.`;
}

/* ---------------- workflow template ---------------- */

export function workflowYaml() {
  return `# ${NAME}: ревью каждого PR (ошибки + безопасность) и агент по упоминанию ${MENTION} в PR и issue.
# Нужен секрет ${CMD.toUpperCase()}_API_KEY: Settings → Secrets and variables → Actions → New repository secret.
# Без --security ревью стоит примерно вдвое меньше.
name: ${NAME}

on:
  pull_request:
    types: [opened, synchronize, reopened, ready_for_review]
  issue_comment:
    types: [created]
  pull_request_review_comment:
    types: [created]
  pull_request_review:
    types: [submitted]
  issues:
    types: [opened]

permissions:
  contents: write
  pull-requests: write
  issues: write

jobs:
  review:
    if: github.event_name == 'pull_request' && !github.event.pull_request.draft
    runs-on: ubuntu-latest
    concurrency:
      group: ${CMD}-review-\${{ github.event.pull_request.number }}
      cancel-in-progress: true
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm install -g https://klinch.cloud/klinch-code.tgz
      - run: ${CMD} github review --security
        env:
          ${CMD.toUpperCase()}_API_KEY: \${{ secrets.${CMD.toUpperCase()}_API_KEY }}
          GITHUB_TOKEN: \${{ secrets.GITHUB_TOKEN }}

  respond:
    if: >-
      (github.event_name == 'issue_comment' && contains(github.event.comment.body, '${MENTION}')) ||
      (github.event_name == 'pull_request_review_comment' && contains(github.event.comment.body, '${MENTION}')) ||
      (github.event_name == 'pull_request_review' && contains(github.event.review.body, '${MENTION}')) ||
      (github.event_name == 'issues' && (contains(github.event.issue.body, '${MENTION}') || contains(github.event.issue.title, '${MENTION}')))
    runs-on: ubuntu-latest
    concurrency:
      group: ${CMD}-respond-\${{ github.event.issue.number || github.event.pull_request.number }}
      cancel-in-progress: false
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm install -g https://klinch.cloud/klinch-code.tgz
      - run: ${CMD} github respond
        env:
          ${CMD.toUpperCase()}_API_KEY: \${{ secrets.${CMD.toUpperCase()}_API_KEY }}
          GITHUB_TOKEN: \${{ secrets.GITHUB_TOKEN }}
`;
}

export function install(cwd, { force = false } = {}) {
  let top = cwd;
  try { top = execFileSync('git', ['rev-parse', '--show-toplevel'], { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim() || cwd; } catch { /* not a repo */ }
  const file = join(top, '.github', 'workflows', `${CMD}.yml`);
  if (existsSync(file) && !force) return { file, written: false };
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, workflowYaml());
  return { file, written: true };
}

/* ---------------- running ---------------- */

const sh = (cwd, cmd, args) => execFileSync(cmd, args, { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], maxBuffer: 64 << 20 }).trim();

async function prDiff(gh, repo, pr, cwd) {
  try { return await gh('GET', `/repos/${repo}/pulls/${pr.number}`, null, 'application/vnd.github.v3.diff'); }
  catch (e) {
    // Too big for the API (over 300 files or 20 000 lines): the checkout has the history (fetch-depth: 0).
    try { return sh(cwd, 'git', ['diff', `${pr.base.sha}...${pr.head.sha}`]); } catch { throw e; }
  }
}

/** Known findings of this kind on the PR (their markers), so a new push does not repeat them. */
async function knownFindings(gh, repo, n) {
  const known = new Set();
  const re = new RegExp(`<!-- ${CMD}:f:([0-9a-f]{12}) -->`, 'g');
  for (const c of await all(gh, `/repos/${repo}/pulls/${n}/comments`).catch(() => [])) for (const m of String(c.body || '').matchAll(re)) known.add(m[1]);
  return known;
}

async function upsertSticky(gh, repo, n, kind, body) {
  const old = (await all(gh, `/repos/${repo}/issues/${n}/comments`).catch(() => [])).find((c) => String(c.body || '').includes(mark(kind)));
  if (old) return gh('PATCH', `/repos/${repo}/issues/comments/${old.id}`, { body });
  return gh('POST', `/repos/${repo}/issues/${n}/comments`, { body });
}

/**
 * One review pass (kind 'bugs' or 'security') of a PR: the reviewer agent reads the diff and the code, inline comments
 * go into a GitHub review, the rest and the summary into one comment that each new push updates.
 * deps: { gh, repo, pr, diff, reviewer(role) → agent, log, runUrl, dryRun, write }
 */
export async function reviewPass(kind, d) {
  const role = kind === 'security' ? SECURITY_REVIEWER : BUG_REVIEWER;
  d.log(`${TITLES[kind]}: PR #${d.pr.number}`);
  const agent = d.reviewer(role);
  const answer = textOf(await agent.ask(reviewTask({ repo: d.repo, pr: d.pr, diff: d.diff })));
  const { summary, findings } = parseFindings(answer);
  const known = d.dryRun ? new Set() : await knownFindings(d.gh, d.repo, d.pr.number);
  const lines = diffLines(d.diff);
  const { comments, outside, fresh } = buildReview(kind, findings, lines, known);
  const spent = tokensOf(agent.totalUsage || {});
  let posted = comments.length, rest = outside;
  if (d.dryRun) {
    d.write(summaryBody(kind, { summary, findings, outside: [...outside], posted: 0, spent }) + '\n');
    for (const c of comments) d.write(`\n${c.path}:${c.line}\n${c.body}\n`);
    return { findings, fresh, comments };
  }
  if (comments.length) {
    try {
      await d.gh('POST', `/repos/${d.repo}/pulls/${d.pr.number}/reviews`, { commit_id: d.pr.head.sha, event: 'COMMENT', body: `${TITLES[kind]}: ${comments.length} замеч. в коде.`, comments });
    } catch (e) {
      // A line GitHub does not take (the diff moved on): everything goes into the summary instead.
      d.log(`Комментарии в коде не приняты (${e.status || e.message}), пишу их в сводку.`);
      posted = 0; rest = fresh;
    }
  }
  await upsertSticky(d.gh, d.repo, d.pr.number, kind, summaryBody(kind, { summary, findings, outside: rest, posted, spent, runUrl: d.runUrl }));
  d.log(`${TITLES[kind]}: ${findings.length} замеч., новых ${fresh.length}, в коде ${posted}.`);
  return { findings, fresh, comments: posted ? comments : [] };
}

/** A reply in the place of the mention (the review thread, or the PR / issue), updated when the work ends. */
async function startReply(gh, repo, m, text) {
  const body = `${text}\n\n${mark('reply')}`;
  if (m.kind === 'pull_request_review_comment' && m.comment?.id) {
    const c = await gh('POST', `/repos/${repo}/pulls/${m.number}/comments/${m.comment.id}/replies`, { body });
    return (t) => gh('PATCH', `/repos/${repo}/pulls/comments/${c.id}`, { body: `${t}\n\n${mark('reply')}` });
  }
  const c = await gh('POST', `/repos/${repo}/issues/${m.number}/comments`, { body });
  return (t) => gh('PATCH', `/repos/${repo}/issues/comments/${c.id}`, { body: `${t}\n\n${mark('reply')}` });
}

async function react(gh, repo, m) {
  const path = m.kind === 'issue_comment' ? `/repos/${repo}/issues/comments/${m.comment?.id}/reactions`
    : m.kind === 'pull_request_review_comment' ? `/repos/${repo}/pulls/comments/${m.comment?.id}/reactions`
    : m.kind === 'issues' ? `/repos/${repo}/issues/${m.number}/reactions` : null;
  if (path && (m.comment?.id || m.kind === 'issues')) await gh('POST', path, { content: 'eyes' }).catch(() => {});
}

const changed = (cwd) => sh(cwd, 'git', ['status', '--porcelain']).length > 0;

function commit(cwd, message, env) {
  const who = ['-c', `user.name=${NAME} Code`, '-c', `user.email=${env.GITHUB_ACTOR_ID ? `${env.GITHUB_ACTOR_ID}+${env.GITHUB_ACTOR}` : `${CMD}-code`}@users.noreply.github.com`];
  sh(cwd, 'git', ['add', '-A']);
  sh(cwd, 'git', [...who, 'commit', '-m', message]);
}

/**
 * The mention in a PR or an issue: the agent does what is asked in the checkout, its changes are committed and pushed
 * (into the PR's branch, or a new branch and PR for an issue), and the answer replaces the «working» comment.
 * deps: { gh, repo, event, agent, reviewer, cwd, env, log, runUrl, dryRun, write, anyone }
 */
export async function respond(d) {
  const m = parseMention(d.event.name, d.event.payload, { anyone: d.anyone });
  if (!m) { d.log(`В событии ${d.event.name || '(нет)'} нет упоминания ${MENTION}.`); return { skipped: true }; }
  if (m.denied) { d.log(`${MENTION} от @${m.who}: не участник репозитория, пропускаю.`); return { skipped: true, denied: true }; }
  const { gh, repo, cwd } = d;
  const pr = m.isPr ? await gh('GET', `/repos/${repo}/pulls/${m.number}`) : null;
  const issue = m.isPr ? null : (d.event.payload.issue || await gh('GET', `/repos/${repo}/issues/${m.number}`));
  if (d.dryRun) d.log(`Просьба @${m.who} в #${m.number}: ${m.ask}`);
  else await react(gh, repo, m);
  const reply = d.dryRun ? async (t) => d.write(t + '\n') : await startReply(gh, repo, m, `Работаю над этим…${d.runUrl ? ` [лог](${d.runUrl})` : ''}`);

  try {
    const intent = m.isPr ? reviewIntent(m.ask) : null;
    if (intent) {
      const diff = await prDiff(gh, repo, pr, cwd);
      const kinds = intent === 'all' ? ['bugs', 'security'] : [intent];
      const res = [];
      for (const k of kinds) res.push(await reviewPass(k, { ...d, pr, diff }));
      const n = res.reduce((s, r) => s + r.findings.length, 0);
      await reply(n ? `Ревью готово: замечаний ${n}, они в коде и в сводке выше.` : 'Ревью готово: замечаний нет.');
      return { review: kinds };
    }

    // The PR's own branch, so the changes land in it; a fork's branch can't take a push (the answer carries a patch).
    const fork = pr && pr.head?.repo?.full_name !== repo;
    let branch = null;
    if (pr) {
      try {
        sh(cwd, 'git', ['fetch', 'origin', fork ? `pull/${pr.number}/head` : pr.head.ref]);
        sh(cwd, 'git', ['checkout', '-B', fork ? `${CMD}/pr-${pr.number}` : pr.head.ref, 'FETCH_HEAD']);
        if (!fork) branch = pr.head.ref;
      } catch (e) { d.log(`Не удалось перейти на ветку PR: ${e.message}`); }
    }
    const diff = pr ? await prDiff(gh, repo, pr, cwd).catch(() => '') : '';
    const comments = await all(gh, `/repos/${repo}/issues/${m.number}/comments`, 2).catch(() => []);
    const history = comments.filter((c) => !String(c.body || '').includes(mark('reply'))).slice(-8)
      .map((c) => `@${c.user?.login}: ${clip(c.body, 1500)}`).join('\n\n');
    const msg = await d.agent.ask(taskPrompt({ repo, m, issue, pr, diff, history }));
    const answer = textOf(msg) || 'Готово.';
    const spent = tokensOf(d.agent.totalUsage || {});
    let extra = '';
    if (changed(cwd)) {
      const title = clip((m.ask || (pr || issue)?.title || 'правки').split('\n')[0], 72).split('\n')[0];
      if (d.dryRun) extra = `\n\nИзменения (не закоммичены, --dry-run):\n\`\`\`\n${sh(cwd, 'git', ['status', '--short'])}\n\`\`\``;
      else if (pr && !fork && branch) {
        commit(cwd, `${title}\n\nПо просьбе @${m.who} в #${m.number}`, d.env);
        sh(cwd, 'git', ['push', 'origin', `HEAD:${branch}`]);
        extra = `\n\nИзменения отправлены в ветку \`${branch}\`: ${sh(cwd, 'git', ['rev-parse', '--short', 'HEAD'])}.`;
      } else if (pr) {
        sh(cwd, 'git', ['add', '-A']);
        const patch = sh(cwd, 'git', ['diff', '--cached']);
        extra = `\n\nЭто PR из форка, отправить в его ветку я не могу. Патч:\n\`\`\`diff\n${clip(patch, 50000)}\n\`\`\``;
      } else {
        const name = `${CMD}/issue-${m.number}-${Date.now().toString(36)}`;
        sh(cwd, 'git', ['checkout', '-b', name]);
        commit(cwd, `${clip(issue?.title || title, 72).split('\n')[0]}\n\nFixes #${m.number}`, d.env);
        sh(cwd, 'git', ['push', 'origin', `HEAD:refs/heads/${name}`]);
        const base = d.event.payload.repository?.default_branch || 'main';
        const made = await gh('POST', `/repos/${repo}/pulls`, { title: issue?.title || title, head: name, base, body: `Fixes #${m.number}\n\n${answer}\n\n${mark('reply')}` });
        extra = `\n\nОткрыл PR: ${made.html_url}`;
      }
    }
    await reply(`${answer}${extra}${spent ? `\n\n<sub>${spent.toLocaleString('ru-RU')} токенов${d.runUrl ? ` · [лог](${d.runUrl})` : ''}</sub>` : ''}`);
    return { answer, pushed: !!extra };
  } catch (e) {
    await reply(`Не получилось: ${clip(e.message, 500)}${d.runUrl ? `\n\n[лог](${d.runUrl})` : ''}`).catch(() => {});
    throw e;
  }
}

/** `klinch github review`: the PR of the event (or number N), one or two passes. */
export async function review(d, { kinds, number }) {
  const n = number || d.event.payload.pull_request?.number || (d.event.payload.issue?.pull_request ? d.event.payload.issue.number : null);
  if (!n) throw new Error(`Нет PR: запустите в событии pull_request или передайте номер: ${CMD} github review 123`);
  const pr = d.event.payload.pull_request?.number === n && d.event.payload.pull_request.head?.sha ? d.event.payload.pull_request : await d.gh('GET', `/repos/${d.repo}/pulls/${n}`);
  const diff = await prDiff(d.gh, d.repo, pr, d.cwd);
  if (!diff.trim()) { d.log('Изменений нет.'); return []; }
  const res = [];
  for (const k of kinds) res.push(await reviewPass(k, { ...d, pr, diff }));
  return res;
}

export const runUrlOf = (env) => (env.GITHUB_RUN_ID && env.GITHUB_REPOSITORY ? `${env.GITHUB_SERVER_URL || 'https://github.com'}/${env.GITHUB_REPOSITORY}/actions/runs/${env.GITHUB_RUN_ID}` : null);
