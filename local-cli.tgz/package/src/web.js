// Web tools: search (Exa's public MCP server, DuckDuckGo when it refuses) and reading a page as text.
import { connect, resultToContent } from './mcp.js';
import { htmlToText, parseDuckDuckGo } from './webtext.js';

export { htmlToText, parseDuckDuckGo };

const OUT_MAX = 30000;
const UA = 'Mozilla/5.0 (compatible; KlinchCode/0.6.3; +https://klinch.app)';
const EXA_MCP = 'https://mcp.exa.ai/mcp';
const clip = (s, n = OUT_MAX) => (s.length > n ? s.slice(0, n) + `\n… (обрезано, всего ${s.length} символов)` : s);

export async function webSearch(query, n, { fetchImpl = fetch, env = process.env } = {}) {
  const q = String(query || '').trim().slice(0, 400);
  if (!q) throw new Error('Пустой запрос');
  const num = Math.min(Math.max(+n || 6, 1), 10);
  if (!env.KLINCH_NO_EXA) {
    try {
      const sess = await connect({ url: EXA_MCP, headers: env.EXA_API_KEY ? { 'x-api-key': env.EXA_API_KEY } : {} }, { fetchImpl, timeoutMs: 20000 });
      try {
        const text = resultToContent(await sess.callTool('web_search_exa', { query: q, numResults: num }, 30000));
        if (typeof text === 'string' && text.trim()) return clip(text);
      } finally { sess.close(); }
    } catch { /* Exa refused (limit, block) or is down: DuckDuckGo below */ }
  }
  const res = await fetchImpl('https://html.duckduckgo.com/html/', {
    method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded', 'user-agent': UA, accept: 'text/html' },
    body: new URLSearchParams({ q }).toString(), signal: AbortSignal.timeout(20000),
  });
  if (res.status !== 200) throw new Error(`Поиск сейчас недоступен (HTTP ${res.status}), попробуйте через минуту`);
  const hits = parseDuckDuckGo(await res.text(), num);
  if (!hits.length) return `Ничего не найдено по запросу «${q}».`;
  return hits.map((h, i) => `${i + 1}. ${h.title}\n${h.url}${h.snippet ? '\n' + h.snippet : ''}`).join('\n\n');
}

export async function webFetch(raw, { fetchImpl = fetch } = {}) {
  let u;
  try { u = new URL(String(raw || '').trim()); } catch { throw new Error('Некорректный адрес'); }
  if (!/^https?:$/.test(u.protocol)) throw new Error('Читаются только http и https страницы');
  const res = await fetchImpl(u.toString(), { headers: { 'user-agent': UA, accept: 'text/html,text/plain,application/json;q=0.9,*/*;q=0.5' }, signal: AbortSignal.timeout(30000), redirect: 'follow' });
  if (!res.ok) throw new Error(`Страница ответила HTTP ${res.status}`);
  const type = res.headers.get('content-type') || '';
  if (!/text|json|xml|javascript|markdown/.test(type)) return `Это не текст (${type || 'тип неизвестен'})`;
  const body = (await res.text()).slice(0, 3e6);
  return clip(/html/.test(type) ? htmlToText(body) : body);
}
